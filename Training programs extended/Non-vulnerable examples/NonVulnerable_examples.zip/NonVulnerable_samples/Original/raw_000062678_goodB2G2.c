static void goodB2G2()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    goodB2G2Static = 1; /* true */
    goodB2G2Sink(data);
}
