static void goodG2B()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67_structType myStruct;
    /* Initialize data */
    data = -1;
    /* FIX: Use a value greater than 0, but less than 10 to avoid attempting to
     * access an index of the array in the sink that is out-of-bounds */
    data = 7;
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67b_goodG2BSink(myStruct);
}
