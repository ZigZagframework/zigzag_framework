static void goodB2G2()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Set data to a random value */
    data = RAND32();
    goodB2G2Static = 1; /* true */
    goodB2G2Sink(data);
}
