void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_15_bad(void) 
{ 
  int data ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int i ;
  int *buffer ;
  void *tmp___2 ;

  {
  data = -1;
  switch (6) {
  case 6: 
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  switch (7) {
  case 7: 
  tmp___2 = malloc(10UL * sizeof(int ));
  buffer = (int *)tmp___2;
  i = 0;
  while (i < 10) {
    *(buffer + i) = 0;
    i ++;
  }
  if (data >= 0) {
    test_insert();
    *(buffer + data) = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(*(buffer + i));
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  free((void *)buffer);
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  return;
}
}
