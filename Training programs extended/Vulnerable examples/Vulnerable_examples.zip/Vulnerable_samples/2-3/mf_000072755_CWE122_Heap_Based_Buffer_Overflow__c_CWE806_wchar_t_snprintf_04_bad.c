void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_wchar_t_snprintf_04_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = malloc(100UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  if (STATIC_CONST_TRUE) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = wcslen((wchar_t const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___1, (char const   */* __restrict  */)L"%s",
           data);
  test_insert();
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
