void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memcpy_07_bad(void) 
{ 
  int64_t *data ;
  void *tmp ;
  int64_t source[100] ;
  unsigned int tmp___0 ;

  {
  data = (int64_t *)((void *)0);
  if (staticFive == 5) {
    tmp = malloc(50UL * sizeof(int64_t ));
    data = (int64_t *)tmp;
  }
  source[0] = (int64_t )0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 100U)) {
    source[tmp___0] = 0L;
    tmp___0 ++;
  }
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(int64_t ));
  test_insert();
  printLongLongLine(*(data + 0));
  free((void *)data);
  return;
}
}
