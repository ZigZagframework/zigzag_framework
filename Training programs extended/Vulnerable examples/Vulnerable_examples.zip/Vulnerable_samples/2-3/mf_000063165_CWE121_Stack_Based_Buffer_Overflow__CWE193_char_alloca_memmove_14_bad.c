void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_14_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  char source[11] ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  if (globalFive == 5) {
    data = dataBadBuffer;
    *(data + 0) = (char )'\000';
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  test_insert();
  tmp___1 = strlen((char const   *)(source));
  memmove((void *)data, (void const   *)(source), (tmp___1 + 1UL) * sizeof(char ));
  test_insert();
  printLine((char const   *)data);
  return;
}
}
