void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_53_bad(void) 
{ 
  int data ;

  {
  data = -1;
  data = 10;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_53b_badSink(data);
  return;
}
}
