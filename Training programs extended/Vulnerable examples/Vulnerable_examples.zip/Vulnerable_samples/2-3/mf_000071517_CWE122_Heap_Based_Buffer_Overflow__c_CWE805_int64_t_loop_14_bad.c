void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_loop_14_bad(void) 
{ 
  int64_t *data ;
  void *tmp ;
  int64_t source[100] ;
  unsigned int tmp___0 ;
  size_t i ;

  {
  data = (int64_t *)((void *)0);
  if (globalFive == 5) {
    tmp = malloc(50UL * sizeof(int64_t ));
    data = (int64_t *)tmp;
  }
  source[0] = (int64_t )0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 100U)) {
    source[tmp___0] = 0L;
    tmp___0 ++;
  }
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printLongLongLine(*(data + 0));
  free((void *)data);
  return;
}
}
