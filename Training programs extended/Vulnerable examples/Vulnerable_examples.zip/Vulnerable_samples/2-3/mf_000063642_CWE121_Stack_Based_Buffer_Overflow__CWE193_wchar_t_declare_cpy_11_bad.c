void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_cpy_11_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[10] ;
  int tmp ;
  wchar_t source[11] ;

  {
  tmp = globalReturnsTrue();
  if (tmp) {
    data = dataBadBuffer;
    *(data + 0) = 0;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  test_insert();
  wcscpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source));
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
