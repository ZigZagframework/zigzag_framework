void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_memmove_66_bad(void) 
{ 
  char *data ;
  char *dataArray[5] ;
  void *tmp ;

  {
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  dataArray[2] = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_memmove_66b_badSink(dataArray);
  return;
}
}
