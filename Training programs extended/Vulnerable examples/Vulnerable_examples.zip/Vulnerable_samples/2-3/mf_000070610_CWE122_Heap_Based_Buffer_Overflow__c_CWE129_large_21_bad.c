void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_21_bad(void) 
{ 
  int data ;

  {
  data = -1;
  data = 10;
  badStatic = 1;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_21_good_badSink_goodB2G1_goodB2G1Sink(0,
                                                                                             data,
                                                                                             16);
  return;
}
}
