void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_snprintf_06_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  if (STATIC_CONST_FIVE == 5) {
    tmp = malloc(50UL * sizeof(char ));
    data = (char *)tmp;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  snprintf((char */* __restrict  */)data, (size_t )100, (char const   */* __restrict  */)"%s",
           source);
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
