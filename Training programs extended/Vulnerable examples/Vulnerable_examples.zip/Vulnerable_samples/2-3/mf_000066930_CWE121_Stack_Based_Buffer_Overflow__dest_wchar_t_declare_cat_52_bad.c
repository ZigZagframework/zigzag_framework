void CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_52_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_52b_badSink(data);
  return;
}
}
