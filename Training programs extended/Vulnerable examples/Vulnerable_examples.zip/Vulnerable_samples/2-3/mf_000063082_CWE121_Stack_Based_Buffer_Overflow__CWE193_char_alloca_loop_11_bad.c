void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_11_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  int tmp___1 ;
  char source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  tmp = __builtin_alloca(10UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  tmp___1 = globalReturnsTrue();
  if (tmp___1) {
    data = dataBadBuffer;
    *(data + 0) = (char )'\000';
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  sourceLen = strlen((char const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printLine((char const   *)data);
  return;
}
}
