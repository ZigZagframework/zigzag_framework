void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_wchar_t_ncpy_64_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;

  {
  tmp = malloc(100UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE806_wchar_t_ncpy_64b_badSink((void *)(& data));
  return;
}
}
