void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_loop_04_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  data = (char *)((void *)0);
  if (STATIC_CONST_TRUE) {
    tmp = malloc(10UL * sizeof(char ));
    data = (char *)tmp;
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  sourceLen = strlen((char const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
