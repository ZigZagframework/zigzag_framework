void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_21_bad(void) 
{ 
  int data ;

  {
  data = -1;
  data = 10;
  badStatic = 1;
  _1_badSink_goodB2G1_goodB2G1Sink_goodG2B(0, data, 13);
  return;
}
}
