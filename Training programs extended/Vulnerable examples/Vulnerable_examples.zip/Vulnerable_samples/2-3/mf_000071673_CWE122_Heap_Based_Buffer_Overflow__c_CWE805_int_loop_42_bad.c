void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int_loop_42_bad(void) 
{ 
  int *data ;
  int source[100] ;
  unsigned int tmp ;
  size_t i ;

  {
  data = (int *)((void *)0);
  data = badSource(data);
  source[0] = 0;
  tmp = 1U;
  while (! (tmp >= 100U)) {
    source[tmp] = 0;
    tmp ++;
  }
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
