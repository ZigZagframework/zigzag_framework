void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_52_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_52b_badSink(data);
  return;
}
}
