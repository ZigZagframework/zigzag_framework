void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_15_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;

  {
  data = (int *)((void *)0);
  switch (6) {
  case 6: 
  tmp = __builtin_alloca(10UL);
  data = (int *)tmp;
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  memmove((void *)data, (void const   *)(source), 10UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  return;
}
}
