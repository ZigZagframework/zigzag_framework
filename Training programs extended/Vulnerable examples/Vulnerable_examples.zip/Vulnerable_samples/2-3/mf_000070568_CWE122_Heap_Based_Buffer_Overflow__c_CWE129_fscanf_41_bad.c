void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_41_bad(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  _1_badSink_goodB2G_goodG2B_goodG2BSink(0, data, 13);
  return;
}
}
