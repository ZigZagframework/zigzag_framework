void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_loop_11_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;
  int tmp___0 ;
  size_t i ;
  wchar_t source[100] ;

  {
  data = (wchar_t *)((void *)0);
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    tmp = malloc(50UL * sizeof(wchar_t ));
    data = (wchar_t *)tmp;
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  *(data + 99) = 0;
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
