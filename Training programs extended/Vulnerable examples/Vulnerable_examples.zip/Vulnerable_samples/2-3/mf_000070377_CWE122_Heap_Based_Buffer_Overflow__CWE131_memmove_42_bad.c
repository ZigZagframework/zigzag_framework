void CWE122_Heap_Based_Buffer_Overflow__CWE131_memmove_42_bad(void) 
{ 
  int *data ;
  int source[10] ;
  unsigned int tmp ;

  {
  data = (int *)((void *)0);
  data = badSource(data);
  source[0] = 0;
  tmp = 1U;
  while (! (tmp >= 10U)) {
    source[tmp] = 0;
    tmp ++;
  }
  test_insert();
  memmove((void *)data, (void const   *)(source), 10UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
