void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_declare_loop_11_bad(void) 
{ 
  int *data ;
  int dataBadBuffer[50] ;
  int tmp ;
  int source[100] ;
  unsigned int tmp___0 ;
  size_t i ;

  {
  tmp = globalReturnsTrue();
  if (tmp) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 100U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printIntLine(*(data + 0));
  return;
}
}
