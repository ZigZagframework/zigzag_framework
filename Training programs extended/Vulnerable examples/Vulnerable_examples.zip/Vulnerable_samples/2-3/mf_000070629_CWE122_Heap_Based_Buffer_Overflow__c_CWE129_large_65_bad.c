void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_65_bad(void) 
{ 
  int data ;
  void (*funcPtr)(int  ) ;

  {
  funcPtr = & CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_65b_badSink;
  data = -1;
  data = 10;
  (*funcPtr)(data);
  return;
}
}
