void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_67_bad(void) 
{ 
  char *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_67_structType myStruct ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(10UL * sizeof(char ));
  data = (char *)tmp;
  myStruct.structFirst = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_67b_badSink(myStruct);
  return;
}
}
