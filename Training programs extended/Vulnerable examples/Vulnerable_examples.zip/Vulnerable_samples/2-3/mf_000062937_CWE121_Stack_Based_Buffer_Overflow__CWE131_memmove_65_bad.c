void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_65_bad(void) 
{ 
  int *data ;
  void (*funcPtr)(int * ) ;
  void *tmp ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_65b_badSink;
  data = (int *)((void *)0);
  tmp = __builtin_alloca(10UL);
  data = (int *)tmp;
  (*funcPtr)(data);
  return;
}
}
