void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_loop_22_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t i ;
  size_t dataLen ;

  {
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_loop_22_badGlobal = 1;
  data = CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_loop_22_badSource(data);
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  dataLen = strlen((char const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data + i);
    test_insert();
    i ++;
  }
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
