void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memcpy_52_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memcpy_52b_badSink(data);
  return;
}
}
