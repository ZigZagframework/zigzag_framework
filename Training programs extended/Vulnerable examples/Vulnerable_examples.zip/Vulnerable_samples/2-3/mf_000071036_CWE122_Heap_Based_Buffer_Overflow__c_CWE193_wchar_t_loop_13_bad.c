void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_loop_13_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;
  wchar_t source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  data = (wchar_t *)((void *)0);
  if (GLOBAL_CONST_FIVE == 5) {
    tmp = malloc(10UL * sizeof(wchar_t ));
    data = (wchar_t *)tmp;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  sourceLen = wcslen((wchar_t const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
