void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_17_bad(void) 
{ 
  int i ;
  int j ;
  int data ;
  int i___0 ;
  int *buffer ;
  void *tmp ;

  {
  data = -1;
  i = 0;
  while (i < 1) {
    fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d",
           & data);
    i ++;
  }
  j = 0;
  while (j < 1) {
    tmp = malloc(10UL * sizeof(int ));
    buffer = (int *)tmp;
    i___0 = 0;
    while (i___0 < 10) {
      *(buffer + i___0) = 0;
      i___0 ++;
    }
    if (data >= 0) {
      test_insert();
      *(buffer + data) = 1;
      test_insert();
      i___0 = 0;
      while (i___0 < 10) {
        printIntLine(*(buffer + i___0));
        i___0 ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer);
    j ++;
  }
  return;
}
}
