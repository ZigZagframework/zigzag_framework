void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_05_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;
  wchar_t source[11] ;
  size_t tmp___0 ;

  {
  data = (wchar_t *)((void *)0);
  if (staticTrue) {
    tmp = malloc(10UL * sizeof(wchar_t ));
    data = (wchar_t *)tmp;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  test_insert();
  tmp___0 = wcslen((wchar_t const   *)(source));
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          tmp___0 + 1UL);
  test_insert();
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
