void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_04_bad(void) 
{ 
  int data ;
  int i ;
  int *buffer ;
  void *tmp ;

  {
  data = -1;
  if (STATIC_CONST_TRUE) {
    data = 10;
  }
  if (STATIC_CONST_TRUE) {
    tmp = malloc(10UL * sizeof(int ));
    buffer = (int *)tmp;
    i = 0;
    while (i < 10) {
      *(buffer + i) = 0;
      i ++;
    }
    if (data >= 0) {
      test_insert();
      *(buffer + data) = 1;
      test_insert();
      i = 0;
      while (i < 10) {
        printIntLine(*(buffer + i));
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer);
  }
  return;
}
}
