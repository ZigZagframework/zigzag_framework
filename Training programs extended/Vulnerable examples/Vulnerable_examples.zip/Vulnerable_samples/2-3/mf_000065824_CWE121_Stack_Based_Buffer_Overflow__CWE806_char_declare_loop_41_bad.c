void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_loop_41_bad(void) 
{ 
  char *data ;
  char dataBuffer[100] ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_loop_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_loop_41_good_goodG2B(0,
                                                                                                                                                          data,
                                                                                                                                                          11);
  return;
}
}
