void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_loop_22_bad(void) 
{ 
  char *data ;
  size_t i ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_loop_22_badGlobal = 1;
  data = CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_loop_22_badSource(data);
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
