void CWE121_Stack_Based_Buffer_Overflow__CWE135_22_bad(void) 
{ 
  void *data ;

  {
  data = (void *)0;
  data = (void *)L"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  CWE121_Stack_Based_Buffer_Overflow__CWE135_22_badGlobal = 1;
  CWE121_Stack_Based_Buffer_Overflow__CWE135_22_badSink(data);
  return;
}
}
