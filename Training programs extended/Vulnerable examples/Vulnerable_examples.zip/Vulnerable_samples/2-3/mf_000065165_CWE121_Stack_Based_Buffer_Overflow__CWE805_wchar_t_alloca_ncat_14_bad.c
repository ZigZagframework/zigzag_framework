void CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_alloca_ncat_14_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;
  wchar_t source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  if (globalFive == 5) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcsncat((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          (size_t )100);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
