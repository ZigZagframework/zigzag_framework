void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_declare_memmove_04_bad(void) 
{ 
  int *data ;
  int dataBadBuffer[50] ;
  int source[100] ;
  unsigned int tmp ;

  {
  if (STATIC_CONST_TRUE) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = 0;
  tmp = 1U;
  while (! (tmp >= 100U)) {
    source[tmp] = 0;
    tmp ++;
  }
  test_insert();
  memmove((void *)data, (void const   *)(source), 100UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  return;
}
}
