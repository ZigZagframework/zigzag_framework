void CWE122_Heap_Based_Buffer_Overflow__c_dest_char_cat_45_bad(void) 
{ 
  char *data ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(50UL * sizeof(char ));
  data = (char *)tmp;
  *(data + 0) = (char )'\000';
  CWE122_Heap_Based_Buffer_Overflow__c_dest_char_cat_45_badData = data;
  badSink();
  return;
}
}
