void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memmove_45_bad(void) 
{ 
  int64_t *data ;
  void *tmp ;

  {
  data = (int64_t *)((void *)0);
  tmp = malloc(50UL * sizeof(int64_t ));
  data = (int64_t *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memmove_45_badData = data;
  _1_badSink_goodG2B_goodG2BSink(0, 6);
  return;
}
}
