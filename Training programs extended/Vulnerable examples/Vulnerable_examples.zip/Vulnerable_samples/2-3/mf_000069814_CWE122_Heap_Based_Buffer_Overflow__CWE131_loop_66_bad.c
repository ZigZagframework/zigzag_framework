void CWE122_Heap_Based_Buffer_Overflow__CWE131_loop_66_bad(void) 
{ 
  int *data ;
  int *dataArray[5] ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = malloc((size_t )10);
  data = (int *)tmp;
  dataArray[2] = data;
  CWE122_Heap_Based_Buffer_Overflow__CWE131_loop_66b_badSink(dataArray);
  return;
}
}
