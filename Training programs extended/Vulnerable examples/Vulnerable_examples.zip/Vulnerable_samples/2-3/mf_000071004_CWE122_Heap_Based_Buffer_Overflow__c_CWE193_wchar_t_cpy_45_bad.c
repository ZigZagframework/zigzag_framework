void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_cpy_45_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;

  {
  data = (wchar_t *)((void *)0);
  tmp = malloc(10UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_cpy_45_badData = data;
  badSink();
  return;
}
}
