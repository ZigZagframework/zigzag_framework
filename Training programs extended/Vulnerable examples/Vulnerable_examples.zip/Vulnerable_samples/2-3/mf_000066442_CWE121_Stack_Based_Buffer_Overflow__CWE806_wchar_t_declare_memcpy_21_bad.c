void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_memcpy_21_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  wchar_t dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  badStatic = 1;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_memcpy_21_good_badSource_goodG2B2Source(& data,
                                                                                                        data,
                                                                                                        4);
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  test_insert();
  tmp___0 = wcslen((wchar_t const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___0 * sizeof(wchar_t ));
  test_insert();
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
