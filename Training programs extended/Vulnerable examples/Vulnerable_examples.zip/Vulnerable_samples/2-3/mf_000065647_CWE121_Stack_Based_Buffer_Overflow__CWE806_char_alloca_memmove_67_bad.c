void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_67_bad(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_67_structType myStruct ;
  char *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_67b_badSink(myStruct);
  return;
}
}
