void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_loop_15_bad(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;
  size_t i ;
  size_t dataLen ;

  {
  data = dataBuffer;
  switch (6) {
  case 6: 
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  dataLen = strlen((char const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data + i);
    test_insert();
    i ++;
  }
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
