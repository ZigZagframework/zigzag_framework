void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memmove_67_bad(void) 
{ 
  int64_t *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memmove_67_structType myStruct ;
  void *tmp ;

  {
  data = (int64_t *)((void *)0);
  tmp = malloc(50UL * sizeof(int64_t ));
  data = (int64_t *)tmp;
  myStruct.structFirst = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int64_t_memmove_67b_badSink(myStruct);
  return;
}
}
