void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_41_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;

  {
  data = dataBuffer;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  _1_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_41_badSink_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_41_good_goodG2B(0,
                                                                                                                                                        data,
                                                                                                                                                        6);
  return;
}
}
