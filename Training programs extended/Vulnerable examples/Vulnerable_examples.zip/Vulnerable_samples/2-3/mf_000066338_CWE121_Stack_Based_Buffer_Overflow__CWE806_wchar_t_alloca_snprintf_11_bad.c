void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_snprintf_11_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  int tmp___0 ;
  wchar_t dest[50] ;
  unsigned int tmp___1 ;
  size_t tmp___2 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 50U)) {
    dest[tmp___1] = 0;
    tmp___1 ++;
  }
  test_insert();
  tmp___2 = wcslen((wchar_t const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___2, (char const   */* __restrict  */)L"%s",
           data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
