void CWE122_Heap_Based_Buffer_Overflow__c_dest_wchar_t_cpy_41_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;

  {
  data = (wchar_t *)((void *)0);
  tmp = malloc(50UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  *(data + 0) = 0;
  CWE122_Heap_Based_Buffer_Overflow__c_dest_wchar_t_cpy_41_badSink(data);
  return;
}
}
