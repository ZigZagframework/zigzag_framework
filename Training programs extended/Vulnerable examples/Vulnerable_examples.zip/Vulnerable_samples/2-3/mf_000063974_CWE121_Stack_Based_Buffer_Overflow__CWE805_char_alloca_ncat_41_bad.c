void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_41_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = (char )'\000';
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_41_good_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_41_goodG2BSink(0,
                                                                                                                                                                                                                           data,
                                                                                                                                                                                                                           1);
  return;
}
}
