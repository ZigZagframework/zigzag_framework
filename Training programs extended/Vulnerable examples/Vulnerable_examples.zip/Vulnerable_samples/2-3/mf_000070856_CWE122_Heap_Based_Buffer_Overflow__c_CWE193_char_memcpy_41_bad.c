void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_41_bad(void) 
{ 
  char *data ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(10UL * sizeof(char ));
  data = (char *)tmp;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_41_badSink_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_41_goodG2BSink_goodG2B(0,
                                                                                                                                                       data,
                                                                                                                                                       1);
  return;
}
}
