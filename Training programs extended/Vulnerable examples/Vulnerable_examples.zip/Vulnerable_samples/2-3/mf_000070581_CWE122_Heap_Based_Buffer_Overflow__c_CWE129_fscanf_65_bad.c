void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_65_bad(void) 
{ 
  int data ;
  void (*funcPtr)(int  ) ;

  {
  funcPtr = & CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_65b_badSink;
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  (*funcPtr)(data);
  return;
}
}
