void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_11_bad(void) 
{ 
  char *data ;
  void *tmp ;
  int tmp___0 ;
  char source[11] ;
  size_t tmp___1 ;

  {
  data = (char *)((void *)0);
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    tmp = malloc(10UL * sizeof(char ));
    data = (char *)tmp;
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  test_insert();
  tmp___1 = strlen((char const   *)(source));
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         (tmp___1 + 1UL) * sizeof(char ));
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
