void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67_bad(void) 
{ 
  int data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67_structType myStruct ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  data = -1;
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67b_badSink(myStruct);
  return;
}
}
