void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_04_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;
  char source[100] ;

  {
  if (STATIC_CONST_TRUE) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(char ));
  test_insert();
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
