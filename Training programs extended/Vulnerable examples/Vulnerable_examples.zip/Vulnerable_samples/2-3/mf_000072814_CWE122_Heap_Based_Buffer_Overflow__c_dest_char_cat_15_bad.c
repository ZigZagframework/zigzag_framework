void CWE122_Heap_Based_Buffer_Overflow__c_dest_char_cat_15_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  switch (6) {
  case 6: 
  tmp = malloc(50UL * sizeof(char ));
  data = (char *)tmp;
  *(data + 0) = (char )'\000';
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  strcat((char */* __restrict  */)data, (char const   */* __restrict  */)(source));
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
