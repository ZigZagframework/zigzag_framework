void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_snprintf_21_bad(void) 
{ 
  char *data ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  badStatic = 1;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_snprintf_21_good_badSource_goodG2B1Source_goodG2B2Source(& data,
                                                                                                               data,
                                                                                                               4);
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  snprintf((char */* __restrict  */)data, (size_t )100, (char const   */* __restrict  */)"%s",
           source);
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
