void CWE121_Stack_Based_Buffer_Overflow__CWE131_memcpy_16_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;

  {
  data = (int *)((void *)0);
  while (1) {
    tmp = __builtin_alloca(10UL);
    data = (int *)tmp;
    break;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         10UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  return;
}
}
