void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int_memmove_41_bad(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = malloc(50UL * sizeof(int ));
  data = (int *)tmp;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int_memmove_41_badSink_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int_memmove_41_goodG2BSink_goodG2B(0,
                                                                                                                                                       data,
                                                                                                                                                       6);
  return;
}
}
