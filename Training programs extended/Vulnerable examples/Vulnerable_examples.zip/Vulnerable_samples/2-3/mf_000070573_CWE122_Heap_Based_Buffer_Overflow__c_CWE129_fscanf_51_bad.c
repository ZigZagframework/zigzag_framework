void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_51_bad(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_51b_badSink(data);
  return;
}
}
