void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_loop_34_bad(void) 
{ 
  wchar_t *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_loop_34_unionType myUnion ;
  wchar_t dataBuffer[100] ;
  wchar_t *data___0 ;
  wchar_t dest[50] ;
  unsigned int tmp ;
  size_t i ;
  size_t dataLen ;

  {
  data = dataBuffer;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  myUnion.unionFirst = data;
  data___0 = myUnion.unionSecond;
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  dataLen = wcslen((wchar_t const   *)data___0);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data___0 + i);
    test_insert();
    i ++;
  }
  dest[49] = 0;
  printWLine((wchar_t const   *)data___0);
  return;
}
}
