void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_05_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char source[11] ;

  {
  data = (char *)((void *)0);
  if (staticTrue) {
    tmp = malloc(10UL * sizeof(char ));
    data = (char *)tmp;
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  test_insert();
  strcpy((char */* __restrict  */)data, (char const   */* __restrict  */)(source));
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
