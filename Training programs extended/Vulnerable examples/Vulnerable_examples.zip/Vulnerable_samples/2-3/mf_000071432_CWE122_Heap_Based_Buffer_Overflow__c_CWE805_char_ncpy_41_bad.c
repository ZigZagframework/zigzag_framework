void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_ncpy_41_bad(void) 
{ 
  char *data ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(50UL * sizeof(char ));
  data = (char *)tmp;
  *(data + 0) = (char )'\000';
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_ncpy_41_badSink_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_ncpy_41_goodG2BSink_goodG2B(0,
                                                                                                                                                   data,
                                                                                                                                                   1);
  return;
}
}
