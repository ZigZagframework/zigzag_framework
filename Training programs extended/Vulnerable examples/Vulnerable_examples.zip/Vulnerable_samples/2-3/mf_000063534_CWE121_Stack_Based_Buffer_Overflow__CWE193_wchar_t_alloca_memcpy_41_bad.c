void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memcpy_41_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  data = dataBadBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memcpy_41_badSink(data);
  return;
}
}
