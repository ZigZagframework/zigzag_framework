void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_loop_54_bad(void) 
{ 
  char *data ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(10UL * sizeof(char ));
  data = (char *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_loop_54b_badSink(data);
  return;
}
}
