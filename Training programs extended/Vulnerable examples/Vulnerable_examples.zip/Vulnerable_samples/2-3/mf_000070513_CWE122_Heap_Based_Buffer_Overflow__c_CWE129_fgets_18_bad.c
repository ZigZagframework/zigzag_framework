void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_18_bad(void) 
{ 
  int data ;
  char inputBuffer[3UL * sizeof(data) + 2UL] ;
  unsigned int tmp ;
  char *tmp___0 ;
  int i ;
  int *buffer ;
  void *tmp___1 ;

  {
  data = -1;
  goto source;
  source: 
  inputBuffer[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 14U)) {
    inputBuffer[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = fgets((char */* __restrict  */)(inputBuffer), (int )(3UL * sizeof(data) + 2UL),
                  (FILE */* __restrict  */)stdin);
  if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
    data = atoi((char const   *)(inputBuffer));
  } else {
    printLine("fgets() failed.");
  }
  goto sink;
  sink: 
  tmp___1 = malloc(10UL * sizeof(int ));
  buffer = (int *)tmp___1;
  i = 0;
  while (i < 10) {
    *(buffer + i) = 0;
    i ++;
  }
  if (data >= 0) {
    test_insert();
    *(buffer + data) = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(*(buffer + i));
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  free((void *)buffer);
  return;
}
}
