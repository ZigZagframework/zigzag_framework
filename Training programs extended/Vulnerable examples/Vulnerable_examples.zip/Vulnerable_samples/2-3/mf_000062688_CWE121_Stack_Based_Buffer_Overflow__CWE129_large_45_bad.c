void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_45_bad(void) 
{ 
  int data ;

  {
  data = -1;
  data = 10;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_large_45_badData = data;
  _1_badSink_goodB2G_goodG2B_goodG2BSink(0, 12);
  return;
}
}
