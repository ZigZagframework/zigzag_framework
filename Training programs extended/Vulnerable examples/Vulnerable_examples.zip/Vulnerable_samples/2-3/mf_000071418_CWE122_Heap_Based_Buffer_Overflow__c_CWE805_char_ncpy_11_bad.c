void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_ncpy_11_bad(void) 
{ 
  char *data ;
  void *tmp ;
  int tmp___0 ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    tmp = malloc(50UL * sizeof(char ));
    data = (char *)tmp;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  strncpy((char */* __restrict  */)data, (char const   */* __restrict  */)(source),
          (size_t )99);
  test_insert();
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
