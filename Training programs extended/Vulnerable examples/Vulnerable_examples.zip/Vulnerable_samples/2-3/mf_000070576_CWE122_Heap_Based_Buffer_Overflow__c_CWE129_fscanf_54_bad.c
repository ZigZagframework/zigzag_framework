void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_54_bad(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_54b_badSink(data);
  return;
}
}
