void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_wchar_t_ncat_34_bad(void) 
{ 
  wchar_t *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE806_wchar_t_ncat_34_unionType myUnion ;
  void *tmp ;
  wchar_t *data___0 ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = malloc(100UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  myUnion.unionFirst = data;
  data___0 = myUnion.unionSecond;
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = wcslen((wchar_t const   *)data___0);
  wcsncat((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data___0,
          tmp___1);
  test_insert();
  dest[49] = 0;
  printWLine((wchar_t const   *)data___0);
  free((void *)data___0);
  return;
}
}
