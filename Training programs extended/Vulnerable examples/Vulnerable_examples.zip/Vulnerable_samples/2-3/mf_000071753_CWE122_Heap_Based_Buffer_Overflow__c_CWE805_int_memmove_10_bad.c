void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_int_memmove_10_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int source[100] ;
  unsigned int tmp___0 ;

  {
  data = (int *)((void *)0);
  if (globalTrue) {
    tmp = malloc(50UL * sizeof(int ));
    data = (int *)tmp;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 100U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  memmove((void *)data, (void const   *)(source), 100UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
