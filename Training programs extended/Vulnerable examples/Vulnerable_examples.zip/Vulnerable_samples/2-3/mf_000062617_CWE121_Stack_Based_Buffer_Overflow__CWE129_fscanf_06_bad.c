void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_06_bad(void) 
{ 
  int data ;
  int i ;
  int buffer[10] ;
  unsigned int tmp ;

  {
  data = -1;
  if (STATIC_CONST_FIVE == 5) {
    fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d",
           & data);
  }
  if (STATIC_CONST_FIVE == 5) {
    buffer[0] = 0;
    tmp = 1U;
    while (! (tmp >= 10U)) {
      buffer[tmp] = 0;
      tmp ++;
    }
    if (data >= 0) {
      test_insert();
      buffer[data] = 1;
      test_insert();
      i = 0;
      while (i < 10) {
        printIntLine(buffer[i]);
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
  }
  return;
}
}
