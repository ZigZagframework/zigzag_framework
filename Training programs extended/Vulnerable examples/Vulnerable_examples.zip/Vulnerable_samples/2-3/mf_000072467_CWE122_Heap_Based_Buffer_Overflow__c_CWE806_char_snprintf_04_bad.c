void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_04_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  if (STATIC_CONST_TRUE) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = strlen((char const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___1, (char const   */* __restrict  */)"%s",
           data);
  test_insert();
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
