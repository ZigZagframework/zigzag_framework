void CWE122_Heap_Based_Buffer_Overflow__c_dest_wchar_t_cpy_22_bad(void) 
{ 
  wchar_t *data ;
  wchar_t source[100] ;

  {
  data = (wchar_t *)((void *)0);
  CWE122_Heap_Based_Buffer_Overflow__c_dest_wchar_t_cpy_22_badGlobal = 1;
  data = CWE122_Heap_Based_Buffer_Overflow__c_dest_wchar_t_cpy_22_badSource(data);
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcscpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source));
  test_insert();
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
