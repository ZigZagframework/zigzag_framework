void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_memcpy_42_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  data = badSource(data);
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = strlen((char const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___1 * sizeof(char ));
  test_insert();
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
