void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_loop_10_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[10] ;
  char source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  if (globalTrue) {
    data = dataBadBuffer;
    *(data + 0) = (char )'\000';
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  sourceLen = strlen((char const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printLine((char const   *)data);
  return;
}
}
