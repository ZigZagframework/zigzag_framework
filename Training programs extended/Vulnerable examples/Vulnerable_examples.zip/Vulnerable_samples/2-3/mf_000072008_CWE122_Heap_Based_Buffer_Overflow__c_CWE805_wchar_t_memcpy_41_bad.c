void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_memcpy_41_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;

  {
  data = (wchar_t *)((void *)0);
  tmp = malloc(50UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  *(data + 0) = 0;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_memcpy_41_badSink_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_memcpy_41_goodG2BSink_goodG2B(0,
                                                                                                                                                             data,
                                                                                                                                                             1);
  return;
}
}
