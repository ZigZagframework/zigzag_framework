void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_memcpy_15_bad(void) 
{ 
  char *data ;
  void *tmp ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  switch (6) {
  case 6: 
  tmp = malloc(50UL * sizeof(char ));
  data = (char *)tmp;
  *(data + 0) = (char )'\000';
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(char ));
  test_insert();
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
