void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_18_bad(void) 
{ 
  int data ;
  int i ;
  int *buffer ;
  void *tmp ;

  {
  data = -1;
  goto source;
  source: 
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  goto sink;
  sink: 
  tmp = malloc(10UL * sizeof(int ));
  buffer = (int *)tmp;
  i = 0;
  while (i < 10) {
    *(buffer + i) = 0;
    i ++;
  }
  if (data >= 0) {
    test_insert();
    *(buffer + data) = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(*(buffer + i));
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  free((void *)buffer);
  return;
}
}
