void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_41_bad(void) 
{ 
  int data ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  data = -1;
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  badSink(data);
  return;
}
}
