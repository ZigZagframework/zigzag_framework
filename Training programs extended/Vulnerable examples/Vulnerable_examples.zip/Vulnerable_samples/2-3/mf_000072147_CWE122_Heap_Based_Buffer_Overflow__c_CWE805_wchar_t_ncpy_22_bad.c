void CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_ncpy_22_bad(void) 
{ 
  wchar_t *data ;
  wchar_t source[100] ;

  {
  data = (wchar_t *)((void *)0);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_ncpy_22_badGlobal = 1;
  data = CWE122_Heap_Based_Buffer_Overflow__c_CWE805_wchar_t_ncpy_22_badSource(data);
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          (size_t )99);
  test_insert();
  *(data + 99) = 0;
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
