void CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_41_bad(void) 
{ 
  char *data ;
  void *tmp ;

  {
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  CWE122_Heap_Based_Buffer_Overflow__c_CWE806_char_snprintf_41_badSink(data);
  return;
}
}
