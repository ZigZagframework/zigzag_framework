void CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_11_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int tmp___0 ;
  int source[10] ;
  unsigned int tmp___1 ;
  size_t i ;

  {
  data = (int *)((void *)0);
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    tmp = __builtin_alloca(10UL);
    data = (int *)tmp;
  }
  source[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 10U)) {
    source[tmp___1] = 0;
    tmp___1 ++;
  }
  i = (size_t )0;
  while (i < 10UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printIntLine(*(data + 0));
  return;
}
}
