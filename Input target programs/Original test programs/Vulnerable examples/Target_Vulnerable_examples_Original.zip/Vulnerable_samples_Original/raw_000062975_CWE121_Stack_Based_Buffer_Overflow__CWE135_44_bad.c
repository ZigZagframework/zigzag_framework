void CWE121_Stack_Based_Buffer_Overflow__CWE135_44_bad()
{
    void * data;
    /* define a function pointer */
    void (*funcPtr) (void *) = badSink;
    data = NULL;
    /* POTENTIAL FLAW: Set data to point to a wide string */
    data = (void *)WIDE_STRING;
    /* use the function pointer */
    funcPtr(data);
}
