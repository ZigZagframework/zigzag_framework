static void goodG2B2()
{
    void * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {
        /* FIX: Set data to point to a char string */
        data = (void *)CHAR_STRING;
    }
    if(GLOBAL_CONST_TRUE)
    {
        {
            /* POTENTIAL FLAW: treating pointer as a char* when it may point to a wide string */
            size_t dataLen = strlen((char *)data);
            void * dest = (void *)calloc(dataLen+1, 1);
            memcpy(dest, data, (dataLen+1));
            printLine((char *)dest);
            free(dest);
        }
    }
}
