static void goodG2B()
{
    char * data;
    char dataBadBuffer[10];
    char dataGoodBuffer[10+1];
    /* FIX: Set a pointer to a buffer that leaves room for a NULL terminator when performing
     * string copies in the sinks  */
    data = dataGoodBuffer;
    data[0] = '\0'; /* null terminate */
    CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_68_goodG2BData = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_68b_goodG2BSink();
}
