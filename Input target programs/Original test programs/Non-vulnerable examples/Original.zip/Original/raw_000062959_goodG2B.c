static void goodG2B()
{
    void * data;
    data = NULL;
    if(globalReturnsTrueOrFalse())
    {
        /* FIX: Set data to point to a char string */
        data = (void *)CHAR_STRING;
    }
    else
    {
        /* FIX: Set data to point to a char string */
        data = (void *)CHAR_STRING;
    }
    if(globalReturnsTrueOrFalse())
    {
        {
            /* POTENTIAL FLAW: treating pointer as a char* when it may point to a wide string */
            size_t dataLen = strlen((char *)data);
            void * dest = (void *)calloc(dataLen+1, 1);
            memcpy(dest, data, (dataLen+1));
            printLine((char *)dest);
            free(dest);
        }
    }
    else
    {
        {
            /* POTENTIAL FLAW: treating pointer as a char* when it may point to a wide string */
            size_t dataLen = strlen((char *)data);
            void * dest = (void *)calloc(dataLen+1, 1);
            memcpy(dest, data, (dataLen+1));
            printLine((char *)dest);
            free(dest);
        }
    }
}
