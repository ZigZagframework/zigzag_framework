static void goodG2B()
{
    int * data;
    data = NULL;
    /* FIX: Allocate memory using sizeof(int) */
    data = (int *)ALLOCA(10*sizeof(int));
    CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_63b_goodG2BSink(&data);
}
