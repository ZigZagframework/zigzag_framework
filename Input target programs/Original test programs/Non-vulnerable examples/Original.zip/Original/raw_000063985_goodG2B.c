static void goodG2B()
{
    char * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_67_structType myStruct;
    char * dataBadBuffer = (char *)ALLOCA(50*sizeof(char));
    char * dataGoodBuffer = (char *)ALLOCA(100*sizeof(char));
    /* FIX: Set a pointer to a "large" buffer, thus avoiding buffer overflows in the sinks. */
    data = dataGoodBuffer;
    data[0] = '\0'; /* null terminate */
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_ncat_67b_goodG2BSink(myStruct);
}
