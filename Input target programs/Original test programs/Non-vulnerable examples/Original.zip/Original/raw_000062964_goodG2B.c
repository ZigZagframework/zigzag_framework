static void goodG2B()
{
    int h,j;
    void * data;
    data = NULL;
    for(h = 0; h < 1; h++)
    {
        /* FIX: Set data to point to a char string */
        data = (void *)CHAR_STRING;
    }
    for(j = 0; j < 1; j++)
    {
        {
            /* POTENTIAL FLAW: treating pointer as a char* when it may point to a wide string */
            size_t dataLen = strlen((char *)data);
            void * dest = (void *)calloc(dataLen+1, 1);
            memcpy(dest, data, (dataLen+1));
            printLine((char *)dest);
            free(dest);
        }
    }
}
