static void goodG2B()
{
    char * data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67_structType myStruct;
    char dataBadBuffer[50];
    char dataGoodBuffer[100];
    /* FIX: Set a pointer to a "large" buffer, thus avoiding buffer overflows in the sinks. */
    data = dataGoodBuffer;
    data[0] = '\0'; /* null terminate */
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67b_goodG2BSink(myStruct);
}
