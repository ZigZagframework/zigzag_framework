static void goodB2G()
{
    void * data;
    void (*funcPtr) (void *) = goodB2GSink;
    data = NULL;
    /* POTENTIAL FLAW: Set data to point to a wide string */
    data = (void *)WIDE_STRING;
    funcPtr(data);
}
