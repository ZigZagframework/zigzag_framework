static void goodG2B()
{
    int * data;
    int * dataArray[5];
    int dataBadBuffer[50];
    int dataGoodBuffer[100];
    /* FIX: Set a pointer to a "large" buffer, thus avoiding buffer overflows in the sinks. */
    data = dataGoodBuffer;
    dataArray[2] = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE805_int_declare_memmove_66b_goodG2BSink(dataArray);
}
