static void goodG2B()
{
    void * data;
    void (*funcPtr) (void *) = goodG2BSink;
    data = NULL;
    /* FIX: Set data to point to a char string */
    data = (void *)CHAR_STRING;
    funcPtr(data);
}
