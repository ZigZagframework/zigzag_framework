void CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_41_bad(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = __builtin_alloca(10UL);
  data = (int *)tmp;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_41_good_goodG2B(0,
                                                                                                                                data,
                                                                                                                                11);
  return;
}
}
