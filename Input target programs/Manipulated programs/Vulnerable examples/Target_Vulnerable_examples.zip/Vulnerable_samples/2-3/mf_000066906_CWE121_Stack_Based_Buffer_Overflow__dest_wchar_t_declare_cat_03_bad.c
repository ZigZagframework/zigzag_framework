void CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_03_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[50] ;
  wchar_t source[100] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = 0;
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcscat((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source));
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
