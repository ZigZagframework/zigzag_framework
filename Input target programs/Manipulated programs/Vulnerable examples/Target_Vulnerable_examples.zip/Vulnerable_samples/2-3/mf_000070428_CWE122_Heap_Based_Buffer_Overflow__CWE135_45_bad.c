void CWE122_Heap_Based_Buffer_Overflow__CWE135_45_bad(void) 
{ 
  void *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;

  {
  data = (void *)0;
  tmp = malloc(50UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  wmemset(dataBadBuffer, 65, (size_t )49);
  *(dataBadBuffer + 49) = 0;
  data = (void *)dataBadBuffer;
  CWE122_Heap_Based_Buffer_Overflow__CWE135_45_badData = data;
  _1_badSink_goodB2G_goodG2B_goodG2BSink(0, 1);
  return;
}
}
