void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_32_bad(void) 
{ 
  int data ;
  int *dataPtr1 ;
  int *dataPtr2 ;
  int data___0 ;
  char inputBuffer[3UL * sizeof(data___0) + 2UL] ;
  unsigned int tmp ;
  char *tmp___0 ;
  int data___1 ;
  int i ;
  int buffer[10] ;
  unsigned int tmp___1 ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  data = -1;
  data___0 = *dataPtr1;
  inputBuffer[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 14U)) {
    inputBuffer[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = fgets((char */* __restrict  */)(inputBuffer), (int )(3UL * sizeof(data___0) + 2UL),
                  (FILE */* __restrict  */)stdin);
  if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
    data___0 = atoi((char const   *)(inputBuffer));
  } else {
    printLine("fgets() failed.");
  }
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  buffer[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 10U)) {
    buffer[tmp___1] = 0;
    tmp___1 ++;
  }
  if (data___1 >= 0) {
    test_insert();
    buffer[data___1] = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(buffer[i]);
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  return;
}
}
