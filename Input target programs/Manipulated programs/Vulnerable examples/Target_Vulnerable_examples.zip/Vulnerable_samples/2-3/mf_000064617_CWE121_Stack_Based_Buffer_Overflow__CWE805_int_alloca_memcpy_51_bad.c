void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_memcpy_51_bad(void) 
{ 
  int *data ;
  int *dataBadBuffer ;
  void *tmp ;
  int *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int ));
  dataBadBuffer = (int *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int ));
  dataGoodBuffer = (int *)tmp___0;
  data = dataBadBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_memcpy_51b_badSink(data);
  return;
}
}
