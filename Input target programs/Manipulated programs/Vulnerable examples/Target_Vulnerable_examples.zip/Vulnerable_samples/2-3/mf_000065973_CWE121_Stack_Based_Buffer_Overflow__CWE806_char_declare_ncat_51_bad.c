void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_51_bad(void) 
{ 
  char *data ;
  char dataBuffer[100] ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_51b_badSink(data);
  return;
}
}
