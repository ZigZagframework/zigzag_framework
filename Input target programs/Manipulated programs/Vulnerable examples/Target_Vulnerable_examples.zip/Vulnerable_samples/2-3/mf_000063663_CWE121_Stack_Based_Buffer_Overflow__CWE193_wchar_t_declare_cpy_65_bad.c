void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_cpy_65_bad(void) 
{ 
  wchar_t *data ;
  void (*funcPtr)(wchar_t * ) ;
  wchar_t dataBadBuffer[10] ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_cpy_65b_badSink;
  data = dataBadBuffer;
  *(data + 0) = 0;
  (*funcPtr)(data);
  return;
}
}
