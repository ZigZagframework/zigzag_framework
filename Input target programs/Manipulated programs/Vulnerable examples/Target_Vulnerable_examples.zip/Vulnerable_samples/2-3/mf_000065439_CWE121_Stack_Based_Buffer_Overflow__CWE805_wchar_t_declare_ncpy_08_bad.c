void CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_ncpy_08_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[50] ;
  int tmp ;
  wchar_t source[100] ;

  {
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_ncpy_08_good_goodG2B2_staticReturnsTrue(& tmp,
                                                                                                        7);
  if (tmp) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          (size_t )99);
  test_insert();
  *(data + 99) = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
