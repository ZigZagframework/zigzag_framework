void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_bad(void) 
{ 
  int data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_structType myStruct ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67b_badSink(myStruct);
  return;
}
}
