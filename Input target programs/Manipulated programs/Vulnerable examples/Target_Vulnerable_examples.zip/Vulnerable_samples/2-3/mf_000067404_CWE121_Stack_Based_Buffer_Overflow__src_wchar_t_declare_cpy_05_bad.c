void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_05_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  wchar_t dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  if (staticTrue) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  test_insert();
  wcscpy((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
