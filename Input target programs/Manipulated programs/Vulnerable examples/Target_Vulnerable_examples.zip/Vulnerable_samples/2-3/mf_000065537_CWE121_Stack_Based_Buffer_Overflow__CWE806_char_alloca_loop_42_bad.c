void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_loop_42_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t i ;
  size_t dataLen ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  data = badSource(data);
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  dataLen = strlen((char const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data + i);
    test_insert();
    i ++;
  }
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
