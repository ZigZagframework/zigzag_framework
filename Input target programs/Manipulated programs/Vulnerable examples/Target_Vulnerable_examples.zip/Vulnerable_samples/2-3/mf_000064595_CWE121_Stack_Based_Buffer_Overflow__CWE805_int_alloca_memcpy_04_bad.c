void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_memcpy_04_bad(void) 
{ 
  int *data ;
  int *dataBadBuffer ;
  void *tmp ;
  int *dataGoodBuffer ;
  void *tmp___0 ;
  int source[100] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int ));
  dataBadBuffer = (int *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int ));
  dataGoodBuffer = (int *)tmp___0;
  if (STATIC_CONST_TRUE) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 100U)) {
    source[tmp___1] = 0;
    tmp___1 ++;
  }
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  return;
}
}
