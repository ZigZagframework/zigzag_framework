void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_53_bad(void) 
{ 
  int64_t *data ;
  int64_t dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_53b_badSink(data);
  return;
}
}
