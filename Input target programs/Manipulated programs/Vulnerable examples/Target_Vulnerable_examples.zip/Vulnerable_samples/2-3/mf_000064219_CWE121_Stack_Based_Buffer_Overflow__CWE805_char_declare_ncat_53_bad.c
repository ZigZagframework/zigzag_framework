void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncat_53_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncat_53b_badSink(data);
  return;
}
}
