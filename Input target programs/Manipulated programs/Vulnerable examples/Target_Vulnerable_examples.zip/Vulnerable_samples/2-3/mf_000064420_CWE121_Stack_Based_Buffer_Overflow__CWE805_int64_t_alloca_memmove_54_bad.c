void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_alloca_memmove_54_bad(void) 
{ 
  int64_t *data ;
  int64_t *dataBadBuffer ;
  void *tmp ;
  int64_t *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int64_t ));
  dataBadBuffer = (int64_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int64_t ));
  dataGoodBuffer = (int64_t *)tmp___0;
  data = dataBadBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_alloca_memmove_54b_badSink(data);
  return;
}
}
