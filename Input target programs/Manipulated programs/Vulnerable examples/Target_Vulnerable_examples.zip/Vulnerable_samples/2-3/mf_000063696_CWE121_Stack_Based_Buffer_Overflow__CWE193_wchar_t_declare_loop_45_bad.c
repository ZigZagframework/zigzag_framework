void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_45_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[10] ;

  {
  data = dataBadBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_45_badData = data;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_45_good_badSink_goodG2B(0,
                                                                                             8);
  return;
}
}
