void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_42_bad(void) 
{ 
  int data ;
  int i ;
  int buffer[10] ;
  unsigned int tmp ;

  {
  data = -1;
  data = badSource(data);
  buffer[0] = 0;
  tmp = 1U;
  while (! (tmp >= 10U)) {
    buffer[tmp] = 0;
    tmp ++;
  }
  if (data >= 0) {
    test_insert();
    buffer[data] = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(buffer[i]);
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  return;
}
}
