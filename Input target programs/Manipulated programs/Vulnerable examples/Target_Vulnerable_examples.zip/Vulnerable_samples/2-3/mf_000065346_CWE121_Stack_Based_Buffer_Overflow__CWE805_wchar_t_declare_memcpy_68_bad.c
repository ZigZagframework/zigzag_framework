void CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memcpy_68_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memcpy_68_badData = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memcpy_68b_badSink();
  return;
}
}
