void CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_declare_memmove_41_bad(void) 
{ 
  twoIntsStruct *data ;
  twoIntsStruct dataBadBuffer[50] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_declare_memmove_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_declare_memmove_41_good_goodG2B(0,
                                                                                                                                                                    data,
                                                                                                                                                                    6);
  return;
}
}
