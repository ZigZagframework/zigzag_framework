void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memcpy_13_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  char source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  if (GLOBAL_CONST_FIVE == 5) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(char ));
  test_insert();
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
