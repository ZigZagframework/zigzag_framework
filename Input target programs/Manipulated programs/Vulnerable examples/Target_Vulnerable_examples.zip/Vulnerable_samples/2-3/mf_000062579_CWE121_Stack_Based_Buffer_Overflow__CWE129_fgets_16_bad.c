void CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_16_bad(void) 
{ 
  int data ;
  char inputBuffer[3UL * sizeof(data) + 2UL] ;
  unsigned int tmp ;
  char *tmp___0 ;
  int i ;
  int buffer[10] ;
  unsigned int tmp___1 ;

  {
  data = -1;
  while (1) {
    inputBuffer[0] = (char )'\000';
    tmp = 1U;
    while (! (tmp >= 14U)) {
      inputBuffer[tmp] = (char)0;
      tmp ++;
    }
    tmp___0 = fgets((char */* __restrict  */)(inputBuffer), (int )(3UL * sizeof(data) + 2UL),
                    (FILE */* __restrict  */)stdin);
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      data = atoi((char const   *)(inputBuffer));
    } else {
      printLine("fgets() failed.");
    }
    break;
  }
  while (1) {
    buffer[0] = 0;
    tmp___1 = 1U;
    while (! (tmp___1 >= 10U)) {
      buffer[tmp___1] = 0;
      tmp___1 ++;
    }
    if (data >= 0) {
      test_insert();
      buffer[data] = 1;
      test_insert();
      i = 0;
      while (i < 10) {
        printIntLine(buffer[i]);
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    break;
  }
  return;
}
}
