void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memmove_41_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[10] ;

  {
  data = dataBadBuffer;
  *(data + 0) = 0;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memmove_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memmove_41_goodG2BSink_goodG2B(0,
                                                                                                                                                                             data,
                                                                                                                                                                             1);
  return;
}
}
