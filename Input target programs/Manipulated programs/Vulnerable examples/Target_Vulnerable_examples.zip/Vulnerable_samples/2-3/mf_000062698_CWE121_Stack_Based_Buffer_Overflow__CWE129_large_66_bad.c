void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_66_bad(void) 
{ 
  int data ;
  int dataArray[5] ;

  {
  data = -1;
  data = 10;
  dataArray[2] = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE129_large_66b_badSink(dataArray);
  return;
}
}
