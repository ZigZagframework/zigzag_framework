void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_32_bad(void) 
{ 
  char *data ;
  char **dataPtr1 ;
  char **dataPtr2 ;
  char *dataBuffer ;
  void *tmp ;
  char *data___0 ;
  char *data___1 ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  data___0 = *dataPtr1;
  memset((void *)data___0, 'A', (size_t )99);
  *(data___0 + 99) = (char )'\000';
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = strlen((char const   *)data___1);
  memmove((void *)(dest), (void const   *)data___1, tmp___1 * sizeof(char ));
  test_insert();
  dest[49] = (char )'\000';
  printLine((char const   *)data___1);
  return;
}
}
