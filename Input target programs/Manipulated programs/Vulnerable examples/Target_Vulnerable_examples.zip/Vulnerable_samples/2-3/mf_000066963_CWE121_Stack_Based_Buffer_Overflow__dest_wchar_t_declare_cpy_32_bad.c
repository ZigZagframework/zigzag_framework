void CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cpy_32_bad(void) 
{ 
  wchar_t *data ;
  wchar_t **dataPtr1 ;
  wchar_t **dataPtr2 ;
  wchar_t dataBadBuffer[50] ;
  wchar_t *data___0 ;
  wchar_t *data___1 ;
  wchar_t source[100] ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  data___0 = *dataPtr1;
  test_insert();
  data___0 = dataBadBuffer;
  test_insert();
  *(data___0 + 0) = 0;
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcscpy((wchar_t */* __restrict  */)data___1, (wchar_t const   */* __restrict  */)(source));
  test_insert();
  printWLine((wchar_t const   *)data___1);
  return;
}
}
