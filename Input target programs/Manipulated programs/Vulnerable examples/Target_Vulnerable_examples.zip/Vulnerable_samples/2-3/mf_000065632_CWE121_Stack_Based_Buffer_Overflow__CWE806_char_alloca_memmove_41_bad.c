void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_41_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memmove_41_good_goodG2B(0,
                                                                                                                                                              data,
                                                                                                                                                              6);
  return;
}
}
