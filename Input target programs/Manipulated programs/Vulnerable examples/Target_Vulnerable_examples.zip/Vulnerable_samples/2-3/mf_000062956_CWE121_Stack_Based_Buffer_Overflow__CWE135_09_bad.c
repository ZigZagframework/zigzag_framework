void CWE121_Stack_Based_Buffer_Overflow__CWE135_09_bad(void) 
{ 
  void *data ;
  size_t dataLen ;
  size_t tmp ;
  void *dest ;
  void *tmp___0 ;

  {
  data = (void *)0;
  if (GLOBAL_CONST_TRUE) {
    data = (void *)L"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  }
  if (GLOBAL_CONST_TRUE) {
    test_insert();
    tmp = strlen((char const   *)((char *)data));
    dataLen = tmp;
    test_insert();
    tmp___0 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___0;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
  }
  return;
}
}
