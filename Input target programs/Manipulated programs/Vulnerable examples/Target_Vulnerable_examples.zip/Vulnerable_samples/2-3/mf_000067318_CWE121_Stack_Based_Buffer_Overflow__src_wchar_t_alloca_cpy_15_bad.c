void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_15_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  switch (6) {
  case 6: 
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  wcscpy((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
