void CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_45_bad(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = __builtin_alloca(10UL);
  data = (int *)tmp;
  CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_45_badData = data;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_45_good_badSink_goodG2B(0, 13);
  return;
}
}
