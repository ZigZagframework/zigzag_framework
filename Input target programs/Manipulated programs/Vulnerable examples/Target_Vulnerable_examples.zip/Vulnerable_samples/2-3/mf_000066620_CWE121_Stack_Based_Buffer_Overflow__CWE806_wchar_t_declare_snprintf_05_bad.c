void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_snprintf_05_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  wchar_t dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  if (staticTrue) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  test_insert();
  tmp___0 = wcslen((wchar_t const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___0, (char const   */* __restrict  */)L"%s",
           data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
