void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_badGlobal = 1;
  data = CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_badSource(data);
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = wcslen((wchar_t const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___1 * sizeof(wchar_t ));
  test_insert();
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
