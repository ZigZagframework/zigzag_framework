void CWE122_Heap_Based_Buffer_Overflow__CWE131_memcpy_41_bad(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = malloc((size_t )10);
  data = (int *)tmp;
  _1_CWE122_Heap_Based_Buffer_Overflow__CWE131_memcpy_41_badSink_CWE122_Heap_Based_Buffer_Overflow__CWE131_memcpy_41_goodG2BSink_goodG2B(0,
                                                                                                                                         data,
                                                                                                                                         6);
  return;
}
}
