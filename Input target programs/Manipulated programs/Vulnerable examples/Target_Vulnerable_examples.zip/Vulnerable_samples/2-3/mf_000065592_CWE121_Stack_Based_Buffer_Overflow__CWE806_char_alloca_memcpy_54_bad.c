void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memcpy_54_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_memcpy_54b_badSink(data);
  return;
}
}
