void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_04_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  wchar_t dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  if (STATIC_CONST_TRUE) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  test_insert();
  wcscat((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
