void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_18_bad(void) 
{ 
  int data ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int i ;
  int buffer[10] ;
  unsigned int tmp___2 ;

  {
  data = -1;
  goto source;
  source: 
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  goto sink;
  sink: 
  buffer[0] = 0;
  tmp___2 = 1U;
  while (! (tmp___2 >= 10U)) {
    buffer[tmp___2] = 0;
    tmp___2 ++;
  }
  if (data >= 0) {
    test_insert();
    buffer[data] = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(buffer[i]);
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  return;
}
}
