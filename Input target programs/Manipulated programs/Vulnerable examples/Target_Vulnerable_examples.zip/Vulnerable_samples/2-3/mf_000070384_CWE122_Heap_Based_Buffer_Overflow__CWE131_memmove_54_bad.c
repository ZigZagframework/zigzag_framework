void CWE122_Heap_Based_Buffer_Overflow__CWE131_memmove_54_bad(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = malloc((size_t )10);
  data = (int *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__CWE131_memmove_54b_badSink(data);
  return;
}
}
