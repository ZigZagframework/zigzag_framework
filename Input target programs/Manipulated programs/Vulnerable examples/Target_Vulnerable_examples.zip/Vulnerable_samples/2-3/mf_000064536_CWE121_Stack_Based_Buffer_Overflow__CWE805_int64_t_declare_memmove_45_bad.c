void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memmove_45_bad(void) 
{ 
  int64_t *data ;
  int64_t dataBadBuffer[50] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memmove_45_badData = data;
  _1_badSink_goodG2B_goodG2BSink(0, 6);
  return;
}
}
