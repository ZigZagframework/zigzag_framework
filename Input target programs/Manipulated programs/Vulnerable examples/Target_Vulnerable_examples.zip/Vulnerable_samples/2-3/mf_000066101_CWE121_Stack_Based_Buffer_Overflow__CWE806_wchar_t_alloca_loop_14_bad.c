void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_loop_14_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t i ;
  size_t dataLen ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  if (globalFive == 5) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  dataLen = wcslen((wchar_t const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data + i);
    test_insert();
    i ++;
  }
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
