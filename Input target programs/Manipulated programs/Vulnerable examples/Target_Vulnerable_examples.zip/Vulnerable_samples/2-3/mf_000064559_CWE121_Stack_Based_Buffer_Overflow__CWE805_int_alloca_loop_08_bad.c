void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_loop_08_bad(void) 
{ 
  int *data ;
  int *dataBadBuffer ;
  void *tmp ;
  int *dataGoodBuffer ;
  void *tmp___0 ;
  int tmp___1 ;
  int source[100] ;
  unsigned int tmp___2 ;
  size_t i ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int ));
  dataBadBuffer = (int *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int ));
  dataGoodBuffer = (int *)tmp___0;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_loop_08_good_goodG2B2_staticReturnsFalse_staticReturnsTrue(& tmp___1,
                                                                                                                      18);
  if (tmp___1) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = 0;
  tmp___2 = 1U;
  while (! (tmp___2 >= 100U)) {
    source[tmp___2] = 0;
    tmp___2 ++;
  }
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printIntLine(*(data + 0));
  return;
}
}
