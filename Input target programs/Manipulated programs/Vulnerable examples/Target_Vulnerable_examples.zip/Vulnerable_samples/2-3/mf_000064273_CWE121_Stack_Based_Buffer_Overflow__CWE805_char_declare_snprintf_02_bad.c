void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_snprintf_02_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;
  char source[100] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = (char )'\000';
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  test_insert();
  snprintf((char */* __restrict  */)data, (size_t )100, (char const   */* __restrict  */)"%s",
           source);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
