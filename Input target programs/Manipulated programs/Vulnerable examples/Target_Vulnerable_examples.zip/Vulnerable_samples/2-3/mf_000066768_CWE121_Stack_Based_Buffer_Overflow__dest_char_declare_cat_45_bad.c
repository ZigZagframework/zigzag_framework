void CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_45_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_45_badData = data;
  _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_45_good_badSink_goodG2B(0,
                                                                                       3);
  return;
}
}
