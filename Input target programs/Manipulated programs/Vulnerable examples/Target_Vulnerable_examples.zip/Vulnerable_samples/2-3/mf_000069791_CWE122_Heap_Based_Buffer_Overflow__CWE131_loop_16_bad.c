void CWE122_Heap_Based_Buffer_Overflow__CWE131_loop_16_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;
  size_t i ;

  {
  data = (int *)((void *)0);
  while (1) {
    tmp = malloc((size_t )10);
    data = (int *)tmp;
    break;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  i = (size_t )0;
  while (i < 10UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
