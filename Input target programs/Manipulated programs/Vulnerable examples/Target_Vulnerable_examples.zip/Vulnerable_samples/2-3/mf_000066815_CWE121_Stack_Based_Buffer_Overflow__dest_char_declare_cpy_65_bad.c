void CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cpy_65_bad(void) 
{ 
  char *data ;
  void (*funcPtr)(char * ) ;
  char dataBadBuffer[50] ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cpy_65b_badSink;
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  (*funcPtr)(data);
  return;
}
}
