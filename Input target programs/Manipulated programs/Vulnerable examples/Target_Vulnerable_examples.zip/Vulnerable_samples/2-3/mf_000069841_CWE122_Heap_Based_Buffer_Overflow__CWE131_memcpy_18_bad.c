void CWE122_Heap_Based_Buffer_Overflow__CWE131_memcpy_18_bad(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;

  {
  data = (int *)((void *)0);
  goto source;
  source: 
  tmp = malloc((size_t )10);
  data = (int *)tmp;
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         10UL * sizeof(int ));
  test_insert();
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
