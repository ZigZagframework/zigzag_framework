void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_52_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;

  {
  data = dataBuffer;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_52b_badSink(data);
  return;
}
}
