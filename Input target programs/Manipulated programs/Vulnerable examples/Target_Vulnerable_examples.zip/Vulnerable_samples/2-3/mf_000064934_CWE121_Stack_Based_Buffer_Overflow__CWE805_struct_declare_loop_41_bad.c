void CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_declare_loop_41_bad(void) 
{ 
  twoIntsStruct *data ;
  twoIntsStruct dataBadBuffer[50] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  CWE121_Stack_Based_Buffer_Overflow__CWE805_struct_declare_loop_41_badSink(data);
  return;
}
}
