void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memmove_10_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[10] ;
  wchar_t source[11] ;
  size_t tmp ;

  {
  if (globalTrue) {
    data = dataBadBuffer;
    *(data + 0) = 0;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  test_insert();
  tmp = wcslen((wchar_t const   *)(source));
  memmove((void *)data, (void const   *)(source), (tmp + 1UL) * sizeof(wchar_t ));
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
