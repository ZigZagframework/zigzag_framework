void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67_bad(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67_structType myStruct ;
  char dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67b_badSink(myStruct);
  return;
}
}
