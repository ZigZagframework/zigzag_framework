void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_15_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  switch (6) {
  case 6: 
  memset((void *)data, 'A', (size_t )99);
  *(data + 99) = (char )'\000';
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  strcpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
