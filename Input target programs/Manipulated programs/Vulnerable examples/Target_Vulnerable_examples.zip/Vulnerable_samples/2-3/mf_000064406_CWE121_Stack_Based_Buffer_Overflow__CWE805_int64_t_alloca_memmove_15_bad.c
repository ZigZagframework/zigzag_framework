void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_alloca_memmove_15_bad(void) 
{ 
  int64_t *data ;
  int64_t *dataBadBuffer ;
  void *tmp ;
  int64_t *dataGoodBuffer ;
  void *tmp___0 ;
  int64_t source[100] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int64_t ));
  dataBadBuffer = (int64_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int64_t ));
  dataGoodBuffer = (int64_t *)tmp___0;
  switch (6) {
  case 6: 
  test_insert();
  data = dataBadBuffer;
  test_insert();
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  source[0] = (int64_t )0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 100U)) {
    source[tmp___1] = 0L;
    tmp___1 ++;
  }
  test_insert();
  memmove((void *)data, (void const   *)(source), 100UL * sizeof(int64_t ));
  test_insert();
  printLongLongLine(*(data + 0));
  return;
}
}
