void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_04_bad(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  if (STATIC_CONST_TRUE) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  test_insert();
  strcpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
