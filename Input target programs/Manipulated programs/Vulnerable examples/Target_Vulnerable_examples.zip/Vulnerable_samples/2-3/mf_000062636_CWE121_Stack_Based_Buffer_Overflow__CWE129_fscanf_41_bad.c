void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_41_bad(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_41_good_badSink_goodG2B_goodG2BSink(0,
                                                                                           data,
                                                                                           14);
  return;
}
}
