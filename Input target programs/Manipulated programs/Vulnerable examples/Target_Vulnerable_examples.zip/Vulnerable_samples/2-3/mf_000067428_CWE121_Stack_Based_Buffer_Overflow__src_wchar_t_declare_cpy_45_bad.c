void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_45_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;

  {
  data = dataBuffer;
  wmemset(data, 65, (size_t )99);
  *(data + 99) = 0;
  CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_45_badData = data;
  _1_badSink_goodG2B_goodG2BSink(0, 6);
  return;
}
}
