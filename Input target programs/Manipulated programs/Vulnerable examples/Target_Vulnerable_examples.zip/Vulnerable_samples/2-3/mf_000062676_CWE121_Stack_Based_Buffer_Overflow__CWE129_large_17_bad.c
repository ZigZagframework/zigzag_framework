void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_17_bad(void) 
{ 
  int i ;
  int j ;
  int data ;
  int i___0 ;
  int buffer[10] ;
  unsigned int tmp ;

  {
  data = -1;
  i = 0;
  while (i < 1) {
    data = 10;
    i ++;
  }
  j = 0;
  while (j < 1) {
    buffer[0] = 0;
    tmp = 1U;
    while (! (tmp >= 10U)) {
      buffer[tmp] = 0;
      tmp ++;
    }
    if (data >= 0) {
      test_insert();
      buffer[data] = 1;
      test_insert();
      i___0 = 0;
      while (i___0 < 10) {
        printIntLine(buffer[i___0]);
        i___0 ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    j ++;
  }
  return;
}
}
