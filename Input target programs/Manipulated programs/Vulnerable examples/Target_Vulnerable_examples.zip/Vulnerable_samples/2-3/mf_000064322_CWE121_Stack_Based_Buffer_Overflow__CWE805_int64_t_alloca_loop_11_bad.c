void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_alloca_loop_11_bad(void) 
{ 
  int64_t *data ;
  int64_t *dataBadBuffer ;
  void *tmp ;
  int64_t *dataGoodBuffer ;
  void *tmp___0 ;
  int tmp___1 ;
  int64_t source[100] ;
  unsigned int tmp___2 ;
  size_t i ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int64_t ));
  dataBadBuffer = (int64_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int64_t ));
  dataGoodBuffer = (int64_t *)tmp___0;
  tmp___1 = globalReturnsTrue();
  if (tmp___1) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = (int64_t )0;
  tmp___2 = 1U;
  while (! (tmp___2 >= 100U)) {
    source[tmp___2] = 0L;
    tmp___2 ++;
  }
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  printLongLongLine(*(data + 0));
  return;
}
}
