void CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_loop_45_bad(void) 
{ 
  int *data ;
  int *dataBadBuffer ;
  void *tmp ;
  int *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int ));
  dataBadBuffer = (int *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int ));
  dataGoodBuffer = (int *)tmp___0;
  test_insert();
  data = dataBadBuffer;
  test_insert();
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_loop_45_badData = data;
  badSink();
  return;
}
}
