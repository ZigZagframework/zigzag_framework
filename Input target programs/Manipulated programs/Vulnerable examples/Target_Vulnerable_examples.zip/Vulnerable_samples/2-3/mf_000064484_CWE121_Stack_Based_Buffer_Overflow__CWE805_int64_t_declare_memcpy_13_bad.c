void CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_13_bad(void) 
{ 
  int64_t *data ;
  int64_t dataBadBuffer[50] ;
  int64_t source[100] ;
  unsigned int tmp ;

  {
  if (GLOBAL_CONST_FIVE == 5) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
  }
  source[0] = (int64_t )0;
  tmp = 1U;
  while (! (tmp >= 100U)) {
    source[tmp] = 0L;
    tmp ++;
  }
  test_insert();
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(int64_t ));
  test_insert();
  printLongLongLine(*(data + 0));
  return;
}
}
