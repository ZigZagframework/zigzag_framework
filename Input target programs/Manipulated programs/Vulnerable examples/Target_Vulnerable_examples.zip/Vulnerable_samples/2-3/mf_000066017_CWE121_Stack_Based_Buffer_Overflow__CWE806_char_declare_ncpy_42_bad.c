void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_42_bad(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  data = badSource(data);
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  test_insert();
  tmp___0 = strlen((char const   *)data);
  strncpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data,
          tmp___0);
  test_insert();
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
