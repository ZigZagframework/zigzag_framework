void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_52_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[10] ;

  {
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_52b_badSink(data);
  return;
}
}
