void CWE121_Stack_Based_Buffer_Overflow__CWE135_45_bad(void) 
{ 
  void *data ;

  {
  data = (void *)0;
  data = (void *)L"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  CWE121_Stack_Based_Buffer_Overflow__CWE135_45_badData = data;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE135_45_good_badSink_goodG2B_goodG2BSink(0,
                                                                                    3);
  return;
}
}
