void CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cpy_41_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = (char )'\000';
  _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cpy_41_badSink_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cpy_41_good_goodG2B(0,
                                                                                                                                                    data,
                                                                                                                                                    1);
  return;
}
}
