void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_ncpy_41_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[10] ;

  {
  data = dataBadBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_ncpy_41_badSink(data);
  return;
}
}
