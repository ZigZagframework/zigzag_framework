void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cat_04_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  if (STATIC_CONST_TRUE) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  strcat((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
