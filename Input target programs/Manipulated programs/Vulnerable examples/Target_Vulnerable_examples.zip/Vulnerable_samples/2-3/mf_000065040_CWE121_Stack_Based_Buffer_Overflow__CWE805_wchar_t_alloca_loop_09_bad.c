void CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_alloca_loop_09_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;
  size_t i ;
  wchar_t source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  if (GLOBAL_CONST_TRUE) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  *(data + 99) = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
