void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncpy_52_bad(void) 
{ 
  char *data ;
  char dataBadBuffer[50] ;

  {
  data = dataBadBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncpy_52b_badSink(data);
  return;
}
}
