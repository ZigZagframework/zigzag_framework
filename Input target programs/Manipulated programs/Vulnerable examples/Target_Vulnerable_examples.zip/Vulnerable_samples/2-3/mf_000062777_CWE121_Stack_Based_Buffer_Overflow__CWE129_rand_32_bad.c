void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_32_bad(void) 
{ 
  int data ;
  int *dataPtr1 ;
  int *dataPtr2 ;
  int data___0 ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int data___1 ;
  int i ;
  int buffer[10] ;
  unsigned int tmp___2 ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  data = -1;
  data___0 = *dataPtr1;
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data___0 = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  buffer[0] = 0;
  tmp___2 = 1U;
  while (! (tmp___2 >= 10U)) {
    buffer[tmp___2] = 0;
    tmp___2 ++;
  }
  if (data___1 >= 0) {
    test_insert();
    buffer[data___1] = 1;
    test_insert();
    i = 0;
    while (i < 10) {
      printIntLine(buffer[i]);
      i ++;
    }
  } else {
    printLine("ERROR: Array index is negative.");
  }
  return;
}
}
