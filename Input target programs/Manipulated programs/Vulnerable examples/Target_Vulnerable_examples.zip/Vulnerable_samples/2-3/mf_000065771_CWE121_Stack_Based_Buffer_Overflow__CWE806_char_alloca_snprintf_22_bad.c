void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_snprintf_22_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_snprintf_22_badGlobal = 1;
  data = CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_snprintf_22_badSource(data);
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  test_insert();
  tmp___1 = strlen((char const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___1, (char const   */* __restrict  */)"%s",
           data);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
