void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_loop_11_bad(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  int tmp___1 ;
  size_t i ;
  char source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  tmp___1 = globalReturnsTrue();
  if (tmp___1) {
    test_insert();
    data = dataBadBuffer;
    test_insert();
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  i = (size_t )0;
  while (i < 100UL) {
    test_insert();
    *(data + i) = source[i];
    test_insert();
    i ++;
  }
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
