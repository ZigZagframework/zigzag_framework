void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  int tmp___0 ;
  char dest[50] ;
  unsigned int tmp___1 ;
  size_t tmp___2 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_good_goodG2B2_staticReturnsTrue(& tmp___0,
                                                                                                    12);
  if (tmp___0) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___1 = 1U;
  while (! (tmp___1 >= 50U)) {
    dest[tmp___1] = (char)0;
    tmp___1 ++;
  }
  test_insert();
  tmp___2 = strlen((char const   *)data);
  strncat((char */* __restrict  */)(dest), (char const   */* __restrict  */)data,
          tmp___2);
  test_insert();
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
