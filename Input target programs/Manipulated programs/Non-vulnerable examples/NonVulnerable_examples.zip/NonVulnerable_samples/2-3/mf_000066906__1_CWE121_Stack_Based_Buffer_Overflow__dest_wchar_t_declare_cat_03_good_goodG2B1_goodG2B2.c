void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_03_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                               int whichBlock__4 ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_03_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                               int whichBlock__4 ) 
{ 
  wchar_t *data__0 ;
  wchar_t dataGoodBuffer__1[100] ;
  wchar_t source__2[100] ;
  wchar_t source__3[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_03_good_goodG2B1_goodG2B2(0,
                                                                                              3);
    _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_03_good_goodG2B1_goodG2B2(0,
                                                                                              5);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    data__0 = *((wchar_t (*)[100])(dataGoodBuffer__1));
    *(data__0 + 0) = 0;
    wmemset(*((wchar_t (*)[100])(source__2)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__2)))[99] = 0;
    wcscat((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[100])(source__2))));
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 5: 
    *((wchar_t **)(source__2)) = *((wchar_t (*)[100])(dataGoodBuffer__1));
    *(*((wchar_t **)(source__2)) + 0) = 0;
    wmemset(*((wchar_t (*)[100])(source__3)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__3)))[99] = 0;
    wcscat((wchar_t */* __restrict  */)*((wchar_t **)(source__2)), (wchar_t const   */* __restrict  */)(*((wchar_t (*)[100])(source__3))));
    printWLine((wchar_t const   *)*((wchar_t **)(source__2)));
    {
    next = 4;
    }
    break;
    case 4: ;
    return;
    break;
    }
  }
}
}
