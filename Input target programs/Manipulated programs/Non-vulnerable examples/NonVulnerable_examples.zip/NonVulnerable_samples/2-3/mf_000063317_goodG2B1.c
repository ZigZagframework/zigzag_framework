static void goodG2B1(void) 
{ 
  char *data ;
  char dataGoodBuffer[11] ;
  char source[11] ;
  size_t tmp ;

  {
  if (STATIC_CONST_FIVE != 5) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  tmp = strlen((char const   *)(source));
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         (tmp + 1UL) * sizeof(char ));
  printLine((char const   *)data);
  return;
}
}
