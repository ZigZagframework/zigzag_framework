static void goodG2B1(void) 
{ 
  int data ;
  int i ;
  int *buffer ;
  void *tmp ;

  {
  data = -1;
  if (globalFive != 5) {
    printLine("Benign, fixed string");
  } else {
    data = 7;
  }
  if (globalFive == 5) {
    tmp = malloc(10UL * sizeof(int ));
    buffer = (int *)tmp;
    i = 0;
    while (i < 10) {
      *(buffer + i) = 0;
      i ++;
    }
    if (data >= 0) {
      *(buffer + data) = 1;
      i = 0;
      while (i < 10) {
        printIntLine(*(buffer + i));
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer);
  }
  return;
}
}
