void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBadBuffer__1 ;
  void *tmp__2 ;
  wchar_t *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  wchar_t source__5[100] ;
  wchar_t source__6[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 5: 
    tmp__2 = __builtin_alloca(50UL * sizeof(wchar_t ));
    dataBadBuffer__1 = (wchar_t *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataGoodBuffer__3 = (wchar_t *)tmp___0__4;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (globalFalse) {
      {
      next = 3;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 3: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 2: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = 0;
    {
    next = 1;
    }
    break;
    case 1: 
    wmemset(*((wchar_t (*)[100])(source__5)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__5)))[99] = 0;
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((wchar_t (*)[100])(source__5))),
           100UL * sizeof(wchar_t ));
    *(data__0 + 99) = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 10: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(wchar_t ));
    *((wchar_t **)(& tmp___0__4)) = (wchar_t *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(wchar_t ));
    *((wchar_t **)(source__5)) = (wchar_t *)*((void **)(& dataBadBuffer__1));
    {
    next = 9;
    }
    break;
    case 9: ;
    if (globalTrue) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    *((wchar_t **)(& tmp__2)) = *((wchar_t **)(source__5));
    *(*((wchar_t **)(& tmp__2)) + 0) = 0;
    {
    next = 7;
    }
    break;
    case 7: 
    wmemset(*((wchar_t (*)[100])(source__6)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__6)))[99] = 0;
    memcpy((void */* __restrict  */)*((wchar_t **)(& tmp__2)), (void const   */* __restrict  */)(*((wchar_t (*)[100])(source__6))),
           100UL * sizeof(wchar_t ));
    *(*((wchar_t **)(& tmp__2)) + 99) = 0;
    printWLine((wchar_t const   *)*((wchar_t **)(& tmp__2)));
    {
    next = 6;
    }
    break;
    case 6: ;
    return;
    break;
    }
  }
}
}
