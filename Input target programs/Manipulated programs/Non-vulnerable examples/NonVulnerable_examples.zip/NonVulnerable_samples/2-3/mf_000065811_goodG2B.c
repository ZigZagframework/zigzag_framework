static void goodG2B(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  int tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t i ;
  size_t dataLen ;

  {
  data = dataBuffer;
  tmp = globalReturnsTrueOrFalse();
  if (tmp) {
    memset((void *)data, 'A', (size_t )49);
    *(data + 49) = (char )'\000';
  } else {
    memset((void *)data, 'A', (size_t )49);
    *(data + 49) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  dataLen = strlen((char const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    dest[i] = *(data + i);
    i ++;
  }
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
