void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__4 ) 
{ 
  char *data__0 ;
  void *tmp__1 ;
  char source__2[11] ;
  char source__3[11] ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 5: 
    data__0 = (char *)((void *)0);
    {
    next = 4;
    }
    break;
    case 4: ;
    if (GLOBAL_CONST_FALSE) {
      {
      next = 3;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 3: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 2: 
    tmp__1 = malloc(11UL * sizeof(char ));
    data__0 = (char *)tmp__1;
    {
    next = 1;
    }
    break;
    case 1: 
    (*((char (*)[11])(source__2)))[0] = (char )'A';
    (*((char (*)[11])(source__2)))[1] = (char )'A';
    (*((char (*)[11])(source__2)))[2] = (char )'A';
    (*((char (*)[11])(source__2)))[3] = (char )'A';
    (*((char (*)[11])(source__2)))[4] = (char )'A';
    (*((char (*)[11])(source__2)))[5] = (char )'A';
    (*((char (*)[11])(source__2)))[6] = (char )'A';
    (*((char (*)[11])(source__2)))[7] = (char )'A';
    (*((char (*)[11])(source__2)))[8] = (char )'A';
    (*((char (*)[11])(source__2)))[9] = (char )'A';
    (*((char (*)[11])(source__2)))[10] = (char )'\000';
    strcpy((char */* __restrict  */)data__0, (char const   */* __restrict  */)(*((char (*)[11])(source__2))));
    printLine((char const   *)data__0);
    free((void *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 10: 
    *((char **)(source__2)) = (char *)((void *)0);
    {
    next = 9;
    }
    break;
    case 9: ;
    if (GLOBAL_CONST_TRUE) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    *((void **)(& data__0)) = malloc(11UL * sizeof(char ));
    *((char **)(source__2)) = (char *)*((void **)(& data__0));
    {
    next = 7;
    }
    break;
    case 7: 
    (*((char (*)[11])(source__3)))[0] = (char )'A';
    (*((char (*)[11])(source__3)))[1] = (char )'A';
    (*((char (*)[11])(source__3)))[2] = (char )'A';
    (*((char (*)[11])(source__3)))[3] = (char )'A';
    (*((char (*)[11])(source__3)))[4] = (char )'A';
    (*((char (*)[11])(source__3)))[5] = (char )'A';
    (*((char (*)[11])(source__3)))[6] = (char )'A';
    (*((char (*)[11])(source__3)))[7] = (char )'A';
    (*((char (*)[11])(source__3)))[8] = (char )'A';
    (*((char (*)[11])(source__3)))[9] = (char )'A';
    (*((char (*)[11])(source__3)))[10] = (char )'\000';
    strcpy((char */* __restrict  */)*((char **)(source__2)), (char const   */* __restrict  */)(*((char (*)[11])(source__3))));
    printLine((char const   *)*((char **)(source__2)));
    free((void *)*((char **)(source__2)));
    {
    next = 6;
    }
    break;
    case 6: ;
    return;
    break;
    }
  }
}
}
