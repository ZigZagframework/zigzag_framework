void _1_CWE122_Heap_Based_Buffer_Overflow__CWE135_13_good_goodB2G1_goodB2G2(void *tigressRetVal ,
                                                                            int whichBlock__7 ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_13_bad(void) 
{ 
  void *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  size_t dataLen ;
  size_t tmp___0 ;
  void *dest ;
  void *tmp___1 ;

  {
  data = (void *)0;
  if (GLOBAL_CONST_FIVE == 5) {
    tmp = malloc(50UL * sizeof(wchar_t ));
    dataBadBuffer = (wchar_t *)tmp;
    wmemset(dataBadBuffer, 65, (size_t )49);
    *(dataBadBuffer + 49) = 0;
    data = (void *)dataBadBuffer;
  }
  if (GLOBAL_CONST_FIVE == 5) {
    test_insert();
    tmp___0 = strlen((char const   *)((char *)data));
    dataLen = tmp___0;
    test_insert();
    tmp___1 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___1;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
  }
  return;
}
}
