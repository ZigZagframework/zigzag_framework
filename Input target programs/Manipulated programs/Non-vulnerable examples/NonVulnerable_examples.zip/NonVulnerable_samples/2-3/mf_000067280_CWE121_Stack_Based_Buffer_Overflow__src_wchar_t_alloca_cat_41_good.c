void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_41_good(void) 
{ 


  {
  _1_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_41_bad_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_41_badSink_goodG2B(0,
                                                                                                                                                     0,
                                                                                                                                                     10);
  return;
}
}
