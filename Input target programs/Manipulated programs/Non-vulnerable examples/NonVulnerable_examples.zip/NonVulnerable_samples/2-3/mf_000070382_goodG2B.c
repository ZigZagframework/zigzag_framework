static void goodG2B(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = malloc(10UL * sizeof(int ));
  data = (int *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__CWE131_memmove_52b_goodG2BSink(data);
  return;
}
}
