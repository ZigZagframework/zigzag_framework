static void goodG2B(void) 
{ 
  void *data ;
  char *dataGoodBuffer ;
  void *tmp ;

  {
  data = (void *)0;
  tmp = malloc(50UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp;
  memset((void *)dataGoodBuffer, 'A', (size_t )49);
  *(dataGoodBuffer + 49) = (char )'\000';
  data = (void *)dataGoodBuffer;
  CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BGlobal = 1;
  CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BSink(data);
  return;
}
}
