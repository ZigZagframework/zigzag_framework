static void goodG2B1(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  goodG2B1Static = 0;
  data = goodG2B1Source(data);
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = strlen((char const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___0 * sizeof(char ));
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
