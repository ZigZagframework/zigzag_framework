static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataArray[5] ;
  void *tmp ;

  {
  data = (wchar_t *)((void *)0);
  tmp = malloc(11UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  dataArray[2] = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_memmove_66b_goodG2BSink(dataArray);
  return;
}
}
