static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  wmemset(data, 65, (size_t )49);
  *(data + 49) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_ncat_68_goodG2BData = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_ncat_68b_goodG2BSink();
  return;
}
}
