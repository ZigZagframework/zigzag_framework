static void goodG2B(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  char source[11] ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  tmp___1 = strlen((char const   *)(source));
  strncpy((char */* __restrict  */)data, (char const   */* __restrict  */)(source),
          tmp___1 + 1UL);
  printLine((char const   *)data);
  return;
}
}
