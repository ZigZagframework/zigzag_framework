void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBadBuffer__1 ;
  void *tmp__2 ;
  wchar_t *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  wchar_t source__5[100] ;
  wchar_t source__6[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 1: 
    tmp__2 = __builtin_alloca(50UL * sizeof(wchar_t ));
    dataBadBuffer__1 = (wchar_t *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataGoodBuffer__3 = (wchar_t *)tmp___0__4;
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = 0;
    wmemset(*((wchar_t (*)[100])(source__5)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__5)))[99] = 0;
    memmove((void *)data__0, (void const   *)(*((wchar_t (*)[100])(source__5))), 100UL * sizeof(wchar_t ));
    *(data__0 + 99) = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(wchar_t ));
    *((wchar_t **)(& tmp___0__4)) = (wchar_t *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(wchar_t ));
    *((wchar_t **)(source__5)) = (wchar_t *)*((void **)(& dataBadBuffer__1));
    *((wchar_t **)(& tmp__2)) = *((wchar_t **)(source__5));
    *(*((wchar_t **)(& tmp__2)) + 0) = 0;
    wmemset(*((wchar_t (*)[100])(source__6)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__6)))[99] = 0;
    memmove((void *)*((wchar_t **)(& tmp__2)), (void const   *)(*((wchar_t (*)[100])(source__6))),
            100UL * sizeof(wchar_t ));
    *(*((wchar_t **)(& tmp__2)) + 99) = 0;
    printWLine((wchar_t const   *)*((wchar_t **)(& tmp__2)));
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
