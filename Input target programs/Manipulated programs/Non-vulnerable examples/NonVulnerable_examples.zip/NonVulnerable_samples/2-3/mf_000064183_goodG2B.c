static void goodG2B(void) 
{ 
  char *data ;
  void (*funcPtr)(char * ) ;
  char dataGoodBuffer[100] ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memmove_65b_goodG2BSink;
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  (*funcPtr)(data);
  return;
}
}
