static void goodG2B(void) 
{ 
  int *data ;
  void *tmp ;

  {
  data = (int *)((void *)0);
  tmp = __builtin_alloca(10UL * sizeof(int ));
  data = (int *)tmp;
  CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_51b_goodG2BSink(data);
  return;
}
}
