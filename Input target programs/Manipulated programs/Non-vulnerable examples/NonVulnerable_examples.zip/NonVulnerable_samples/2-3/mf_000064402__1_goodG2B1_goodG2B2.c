void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__9 ) 
{ 
  int64_t *data__0 ;
  int64_t *dataBadBuffer__1 ;
  void *tmp__2 ;
  int64_t *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  int tmp___1__5 ;
  int64_t source__6[100] ;
  unsigned int tmp___2__7 ;
  int64_t source__8[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__9;
  }
  while (1) {
    switch (next) {
    case 10: 
    tmp__2 = __builtin_alloca(50UL * sizeof(int64_t ));
    dataBadBuffer__1 = (int64_t *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(int64_t ));
    dataGoodBuffer__3 = (int64_t *)tmp___0__4;
    tmp___1__5 = globalReturnsFalse();
    {
    next = 9;
    }
    break;
    case 9: ;
    if (tmp___1__5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    data__0 = dataGoodBuffer__3;
    {
    next = 6;
    }
    break;
    case 6: 
    (*((int64_t (*)[100])(source__6)))[0] = (int64_t )0;
    tmp___2__7 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___2__7 >= 100U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((int64_t (*)[100])(source__6)))[tmp___2__7] = 0L;
    tmp___2__7 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    memmove((void *)data__0, (void const   *)(*((int64_t (*)[100])(source__6))), 100UL * sizeof(int64_t ));
    printLongLongLine(*(data__0 + 0));
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(int64_t ));
    *((int64_t **)(& tmp___0__4)) = (int64_t *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(int64_t ));
    *((int64_t **)(source__6)) = (int64_t *)*((void **)(& dataBadBuffer__1));
    *((int *)(& dataGoodBuffer__3)) = globalReturnsTrue();
    {
    next = 19;
    }
    break;
    case 19: ;
    if (*((int *)(& dataGoodBuffer__3))) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    *((int64_t **)(& tmp__2)) = *((int64_t **)(source__6));
    {
    next = 17;
    }
    break;
    case 17: 
    (*((int64_t (*)[100])(source__8)))[0] = (int64_t )0;
    *((unsigned int *)(& tmp___1__5)) = 1U;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (*((unsigned int *)(& tmp___1__5)) >= 100U) {
      {
      next = 12;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 13: 
    (*((int64_t (*)[100])(source__8)))[*((unsigned int *)(& tmp___1__5))] = 0L;
    (*((unsigned int *)(& tmp___1__5))) ++;
    {
    next = 15;
    }
    break;
    case 12: 
    memmove((void *)*((int64_t **)(& tmp__2)), (void const   *)(*((int64_t (*)[100])(source__8))),
            100UL * sizeof(int64_t ));
    printLongLongLine(*(*((int64_t **)(& tmp__2)) + 0));
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
