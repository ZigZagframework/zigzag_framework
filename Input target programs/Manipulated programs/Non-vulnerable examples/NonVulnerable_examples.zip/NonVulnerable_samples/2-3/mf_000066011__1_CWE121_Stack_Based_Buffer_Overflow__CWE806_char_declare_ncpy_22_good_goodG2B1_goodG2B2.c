void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_22_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                               int whichBlock__5 ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_22_bad(void) ;
extern char *CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_22_goodG2B1Source(char *data ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
int CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_22_goodG2B1Global ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern int unlink(char const   *filename ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
