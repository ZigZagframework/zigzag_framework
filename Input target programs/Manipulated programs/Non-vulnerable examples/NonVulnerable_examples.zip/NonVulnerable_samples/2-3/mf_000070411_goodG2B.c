static void goodG2B(void) 
{ 
  void *data ;
  char *dataGoodBuffer ;
  void *tmp ;
  char *dataGoodBuffer___0 ;
  void *tmp___0 ;
  int tmp___1 ;
  size_t dataLen ;
  size_t tmp___2 ;
  void *dest ;
  void *tmp___3 ;
  size_t dataLen___0 ;
  size_t tmp___4 ;
  void *dest___0 ;
  void *tmp___5 ;
  int tmp___6 ;

  {
  data = (void *)0;
  tmp___1 = globalReturnsTrueOrFalse();
  if (tmp___1) {
    tmp = malloc(50UL * sizeof(char ));
    dataGoodBuffer = (char *)tmp;
    memset((void *)dataGoodBuffer, 'A', (size_t )49);
    *(dataGoodBuffer + 49) = (char )'\000';
    data = (void *)dataGoodBuffer;
  } else {
    tmp___0 = malloc(50UL * sizeof(char ));
    dataGoodBuffer___0 = (char *)tmp___0;
    memset((void *)dataGoodBuffer___0, 'A', (size_t )49);
    *(dataGoodBuffer___0 + 49) = (char )'\000';
    data = (void *)dataGoodBuffer___0;
  }
  tmp___6 = globalReturnsTrueOrFalse();
  if (tmp___6) {
    tmp___2 = strlen((char const   *)((char *)data));
    dataLen = tmp___2;
    tmp___3 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___3;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
  } else {
    tmp___4 = strlen((char const   *)((char *)data));
    dataLen___0 = tmp___4;
    tmp___5 = calloc(dataLen___0 + 1UL, (size_t )1);
    dest___0 = tmp___5;
    memcpy((void */* __restrict  */)dest___0, (void const   */* __restrict  */)data,
           dataLen___0 + 1UL);
    printLine((char const   *)((char *)dest___0));
    free(dest___0);
  }
  return;
}
}
