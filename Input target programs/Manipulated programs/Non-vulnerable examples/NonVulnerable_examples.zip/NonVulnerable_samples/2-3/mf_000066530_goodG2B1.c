static void goodG2B1(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  int tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  data = dataBuffer;
  tmp = globalReturnsFalse();
  if (tmp) {
    printLine("Benign, fixed string");
  } else {
    wmemset(data, 65, (size_t )49);
    *(data + 49) = 0;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  tmp___1 = wcslen((wchar_t const   *)data);
  wcsncat((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data,
          tmp___1);
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
