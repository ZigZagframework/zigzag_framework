static void goodG2B(void) 
{ 
  char *data ;
  char dataGoodBuffer[100] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memmove_51b_goodG2BSink(data);
  return;
}
}
