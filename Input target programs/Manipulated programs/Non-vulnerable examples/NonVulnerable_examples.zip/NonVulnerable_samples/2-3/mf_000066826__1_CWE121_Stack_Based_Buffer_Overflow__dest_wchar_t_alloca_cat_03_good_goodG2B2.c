void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cat_03_good_goodG2B2(void *tigressRetVal ,
                                                                                     int whichBlock__6 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cat_03_good_goodG2B2(void *tigressRetVal ,
                                                                                     int whichBlock__6 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBadBuffer__1 ;
  void *tmp__2 ;
  wchar_t *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  wchar_t source__5[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__6;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cat_03_good_goodG2B2(0,
                                                                                    3);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    tmp__2 = __builtin_alloca(50UL * sizeof(wchar_t ));
    dataBadBuffer__1 = (wchar_t *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataGoodBuffer__3 = (wchar_t *)tmp___0__4;
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = 0;
    wmemset(*((wchar_t (*)[100])(source__5)), 67, (size_t )99);
    (*((wchar_t (*)[100])(source__5)))[99] = 0;
    wcscat((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[100])(source__5))));
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
