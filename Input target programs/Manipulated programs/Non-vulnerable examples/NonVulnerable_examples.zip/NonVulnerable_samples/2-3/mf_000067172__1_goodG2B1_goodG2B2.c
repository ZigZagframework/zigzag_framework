void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  char *data__0 ;
  char dataBuffer__1[100] ;
  char dest__2[50] ;
  unsigned int tmp__3 ;
  char dest__4[50] ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 10: 
    data__0 = *((char (*)[100])(dataBuffer__1));
    {
    next = 9;
    }
    break;
    case 9: ;
    if (GLOBAL_CONST_FIVE != 5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    {
    next = 6;
    }
    break;
    case 6: 
    (*((char (*)[50])(dest__2)))[0] = (char )'\000';
    tmp__3 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp__3 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((char (*)[50])(dest__2)))[tmp__3] = (char)0;
    tmp__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    strcat((char */* __restrict  */)(*((char (*)[50])(dest__2))), (char const   */* __restrict  */)data__0);
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    *((char **)(dest__2)) = *((char (*)[100])(dataBuffer__1));
    {
    next = 19;
    }
    break;
    case 19: ;
    if (GLOBAL_CONST_FIVE == 5) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    memset((void *)*((char **)(dest__2)), 'A', (size_t )49);
    *(*((char **)(dest__2)) + 49) = (char )'\000';
    {
    next = 17;
    }
    break;
    case 17: 
    (*((char (*)[50])(dest__4)))[0] = (char )'\000';
    *((unsigned int *)(& data__0)) = 1U;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (*((unsigned int *)(& data__0)) >= 50U) {
      {
      next = 12;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 13: 
    (*((char (*)[50])(dest__4)))[*((unsigned int *)(& data__0))] = (char)0;
    (*((unsigned int *)(& data__0))) ++;
    {
    next = 15;
    }
    break;
    case 12: 
    strcat((char */* __restrict  */)(*((char (*)[50])(dest__4))), (char const   */* __restrict  */)*((char **)(dest__2)));
    printLine((char const   *)*((char **)(dest__2)));
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
