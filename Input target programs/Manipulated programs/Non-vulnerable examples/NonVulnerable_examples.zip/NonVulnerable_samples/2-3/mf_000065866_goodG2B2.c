static void goodG2B2(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  goodG2B2Static = 1;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_memcpy_21_bad_badSource_goodG2B2Source(& data,
                                                                                                    data,
                                                                                                    12);
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = strlen((char const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___0 * sizeof(char ));
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
