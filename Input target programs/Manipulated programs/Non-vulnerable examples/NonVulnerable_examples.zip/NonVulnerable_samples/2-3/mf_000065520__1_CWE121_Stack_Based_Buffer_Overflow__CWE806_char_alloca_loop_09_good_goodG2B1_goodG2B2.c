void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_loop_09_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__8 ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_loop_09_bad(void) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_loop_09_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;
  size_t i ;
  size_t dataLen ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  if (GLOBAL_CONST_TRUE) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  dataLen = strlen((char const   *)data);
  i = (size_t )0;
  while (i < dataLen) {
    test_insert();
    dest[i] = *(data + i);
    test_insert();
    i ++;
  }
  dest[49] = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
