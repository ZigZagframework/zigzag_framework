void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  int64_t *data__0 ;
  int64_t dataGoodBuffer__1[100] ;
  int64_t source__2[100] ;
  unsigned int tmp__3 ;
  int64_t source__4[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 11: ;
    switch (5) {
    case 6: 
    {
    next = 10;
    }
    break;
    default: 
    {
    next = 8;
    }
    break;
    }
    break;
    case 10: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 8: 
    data__0 = *((int64_t (*)[100])(dataGoodBuffer__1));
    {
    next = 6;
    }
    break;
    case 6: 
    (*((int64_t (*)[100])(source__2)))[0] = (int64_t )0;
    tmp__3 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp__3 >= 100U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((int64_t (*)[100])(source__2)))[tmp__3] = 0L;
    tmp__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    memmove((void *)data__0, (void const   *)(*((int64_t (*)[100])(source__2))), 100UL * sizeof(int64_t ));
    printLongLongLine(*(data__0 + 0));
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 22: 
    (*((int64_t (*)[100])(source__4)))[0] = (int64_t )0;
    *((unsigned int *)(& data__0)) = 1U;
    {
    next = 20;
    }
    break;
    case 20: ;
    if (*((unsigned int *)(& data__0)) >= 100U) {
      {
      next = 17;
      }
    } else {
      {
      next = 18;
      }
    }
    break;
    case 18: 
    (*((int64_t (*)[100])(source__4)))[*((unsigned int *)(& data__0))] = 0L;
    (*((unsigned int *)(& data__0))) ++;
    {
    next = 20;
    }
    break;
    case 17: 
    memmove((void *)*((int64_t **)(source__2)), (void const   *)(*((int64_t (*)[100])(source__4))),
            100UL * sizeof(int64_t ));
    printLongLongLine(*(*((int64_t **)(source__2)) + 0));
    {
    next = 16;
    }
    break;
    case 16: ;
    return;
    break;
    case 15: ;
    switch (6) {
    case 6: 
    {
    next = 14;
    }
    break;
    default: 
    {
    next = 12;
    }
    break;
    }
    break;
    case 14: 
    *((int64_t **)(source__2)) = *((int64_t (*)[100])(dataGoodBuffer__1));
    {
    next = 22;
    }
    break;
    case 12: 
    printLine("Benign, fixed string");
    {
    next = 22;
    }
    break;
    }
  }
}
}
