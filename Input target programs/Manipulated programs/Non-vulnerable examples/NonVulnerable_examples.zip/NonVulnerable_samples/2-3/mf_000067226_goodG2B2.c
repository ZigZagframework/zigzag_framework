static void goodG2B2(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  goodG2B2Static = 1;
  _1_CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_21_bad_CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_21_good_badSource_goodG2B2Source(& data,
                                                                                                                                                               data,
                                                                                                                                                               14);
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  strcpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  printLine((char const   *)data);
  return;
}
}
