static void goodG2B(void) 
{ 
  int h ;
  wchar_t *data ;
  wchar_t dataGoodBuffer[11] ;
  wchar_t source[11] ;
  size_t tmp ;

  {
  h = 0;
  while (h < 1) {
    data = dataGoodBuffer;
    *(data + 0) = 0;
    h ++;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  tmp = wcslen((wchar_t const   *)(source));
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          tmp + 1UL);
  printWLine((wchar_t const   *)data);
  return;
}
}
