void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memcpy_13_good_goodG2B2(void *tigressRetVal ,
                                                                                       int whichBlock__6 ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void main(void) 
{ 


  {
  megaInit();
}
}
