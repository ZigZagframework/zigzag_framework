static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;
  wchar_t *dataCopy ;
  wchar_t *data___0 ;
  wchar_t source[11] ;

  {
  tmp = __builtin_alloca(10UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  data = dataGoodBuffer;
  *(data + 0) = 0;
  dataCopy = data;
  data___0 = dataCopy;
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  wcscpy((wchar_t */* __restrict  */)data___0, (wchar_t const   */* __restrict  */)(source));
  printWLine((wchar_t const   *)data___0);
  return;
}
}
