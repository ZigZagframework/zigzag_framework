static void goodG2B1(void) 
{ 
  char *data ;
  char source[11] ;
  size_t tmp ;

  {
  data = (char *)((void *)0);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_22_goodG2B1Global = 0;
  data = CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_22_goodG2B1Source(data);
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  tmp = strlen((char const   *)(source));
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         (tmp + 1UL) * sizeof(char ));
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
