void _1_CWE122_Heap_Based_Buffer_Overflow__CWE135_03_good_goodB2G1_goodB2G2(void *tigressRetVal ,
                                                                            int whichBlock__7 ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_03_bad(void) ;
typedef unsigned long size_t;
extern  __attribute__((__nothrow__)) void *( __attribute__((__leaf__)) calloc)(size_t __nmemb ,
                                                                               size_t __size )  __attribute__((__malloc__)) ;
extern int fseek(struct _IO_FILE *stream , long offs , int whence ) ;
extern int fclose(void *stream ) ;
extern int close(int filedes ) ;
static void goodG2B2(void) ;
static void goodG2B1(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern int unlink(char const   *filename ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
