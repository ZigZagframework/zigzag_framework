void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_cpy_02_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                int whichBlock__7 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int printf(char const   *format  , ...) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_cpy_02_bad(void) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern double log(double x ) ;
void main(void) ;
void megaInit(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern unsigned long strlen(char const   *s ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern void free(void *ptr ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
void test_insert(void) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
