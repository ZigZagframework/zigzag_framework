void _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_02_good_goodG2B2(void *tigressRetVal ,
                                                                                   int whichBlock__3 ) ;
extern int raise(int sig ) ;
extern void abort() ;
typedef unsigned long size_t;
extern int atoi(char const   *s ) ;
extern void *malloc(unsigned long size ) ;
extern int getpagesize() ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern void printLine(char const   *line ) ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2), __leaf__)) strcat)(char * __restrict  __dest ,
                                                                                                 char const   * __restrict  __src ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_02_good_goodG2B2(void *tigressRetVal ,
                                                                                   int whichBlock__3 ) 
{ 
  char *data__0 ;
  char dataGoodBuffer__1[100] ;
  char source__2[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__3;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_02_good_goodG2B2(0,
                                                                                  3);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    data__0 = *((char (*)[100])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    memset((void *)(*((char (*)[100])(source__2))), 'C', (size_t )99);
    (*((char (*)[100])(source__2)))[99] = (char )'\000';
    strcat((char */* __restrict  */)data__0, (char const   */* __restrict  */)(*((char (*)[100])(source__2))));
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
