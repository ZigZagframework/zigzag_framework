void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_06_good_goodG2B2(void *tigressRetVal ,
                                                                                        int whichBlock__4 ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1), __leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_06_bad(void) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
void STATIC_CONST_FIVE_i$nit(void) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_06_good_goodG2B2(void *tigressRetVal ,
                                                                                        int whichBlock__4 ) 
{ 
  char *data__0 ;
  char dataGoodBuffer__1[11] ;
  char source__2[11] ;
  size_t tmp__3 ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_memcpy_06_good_goodG2B2(0,
                                                                                       5);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 5: ;
    if (STATIC_CONST_FIVE == 5) {
      {
      next = 4;
      }
    } else {
      {
      next = 3;
      }
    }
    break;
    case 4: 
    data__0 = *((char (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    {
    next = 3;
    }
    break;
    case 3: 
    (*((char (*)[11])(source__2)))[0] = (char )'A';
    (*((char (*)[11])(source__2)))[1] = (char )'A';
    (*((char (*)[11])(source__2)))[2] = (char )'A';
    (*((char (*)[11])(source__2)))[3] = (char )'A';
    (*((char (*)[11])(source__2)))[4] = (char )'A';
    (*((char (*)[11])(source__2)))[5] = (char )'A';
    (*((char (*)[11])(source__2)))[6] = (char )'A';
    (*((char (*)[11])(source__2)))[7] = (char )'A';
    (*((char (*)[11])(source__2)))[8] = (char )'A';
    (*((char (*)[11])(source__2)))[9] = (char )'A';
    (*((char (*)[11])(source__2)))[10] = (char )'\000';
    tmp__3 = strlen((char const   *)(*((char (*)[11])(source__2))));
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((char (*)[11])(source__2))),
           (tmp__3 + 1UL) * sizeof(char ));
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
