void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memcpy_07_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                    int whichBlock__5 ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void megaInit(void) 
{ 


  {
  staticFive_i$nit();
}
}
