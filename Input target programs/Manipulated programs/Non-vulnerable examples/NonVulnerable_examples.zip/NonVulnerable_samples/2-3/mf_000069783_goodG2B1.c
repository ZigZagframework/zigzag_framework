static void goodG2B1(void) 
{ 
  int *data ;
  void *tmp ;
  int tmp___0 ;
  int source[10] ;
  unsigned int tmp___1 ;
  size_t i ;

  {
  data = (int *)((void *)0);
  tmp___0 = staticReturnsFalse();
  if (tmp___0) {
    printLine("Benign, fixed string");
  } else {
    tmp = malloc(10UL * sizeof(int ));
    data = (int *)tmp;
  }
  source[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 10U)) {
    source[tmp___1] = 0;
    tmp___1 ++;
  }
  i = (size_t )0;
  while (i < 10UL) {
    *(data + i) = source[i];
    i ++;
  }
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
