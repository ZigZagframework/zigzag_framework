void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_03_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__4 ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern int printf(char const   *format  , ...) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern double log(double x ) ;
void main(void) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1), __leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
void test_insert(void) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
