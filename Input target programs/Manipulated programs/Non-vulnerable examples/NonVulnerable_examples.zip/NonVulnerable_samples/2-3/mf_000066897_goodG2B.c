static void goodG2B(void) 
{ 
  wchar_t *data ;
  CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cpy_67_structType myStruct ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  data = dataGoodBuffer;
  *(data + 0) = 0;
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cpy_67b_goodG2BSink(myStruct);
  return;
}
}
