static void goodB2G2(void) 
{ 
  void *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  size_t dataLen ;
  size_t tmp___0 ;
  void *dest ;
  void *tmp___1 ;

  {
  data = (void *)0;
  if (globalFive == 5) {
    tmp = malloc(50UL * sizeof(wchar_t ));
    dataBadBuffer = (wchar_t *)tmp;
    wmemset(dataBadBuffer, 65, (size_t )49);
    *(dataBadBuffer + 49) = 0;
    data = (void *)dataBadBuffer;
  }
  if (globalFive == 5) {
    tmp___0 = wcslen((wchar_t const   *)((wchar_t *)data));
    dataLen = tmp___0;
    tmp___1 = calloc(dataLen + 1UL, sizeof(wchar_t ));
    dest = tmp___1;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, (dataLen + 1UL) * sizeof(wchar_t ));
    printWLine((wchar_t const   *)((wchar_t *)dest));
    free(dest);
  }
  return;
}
}
