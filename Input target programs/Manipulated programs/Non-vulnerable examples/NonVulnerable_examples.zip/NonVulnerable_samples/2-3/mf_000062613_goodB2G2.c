static void goodB2G2(void) 
{ 
  int data ;
  int i ;
  int buffer[10] ;
  unsigned int tmp ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  buffer[0] = 0;
  tmp = 1U;
  while (! (tmp >= 10U)) {
    buffer[tmp] = 0;
    tmp ++;
  }
  if (data >= 0) {
    if (data < 10) {
      buffer[data] = 1;
      i = 0;
      while (i < 10) {
        printIntLine(buffer[i]);
        i ++;
      }
    } else {
      printLine("ERROR: Array index is out-of-bounds");
    }
  } else {
    printLine("ERROR: Array index is out-of-bounds");
  }
  return;
}
}
