static void goodG2B(void) 
{ 
  int64_t *data ;
  int64_t dataGoodBuffer[100] ;
  int64_t source[100] ;
  unsigned int tmp ;

  {
  while (1) {
    data = dataGoodBuffer;
    break;
  }
  source[0] = (int64_t )0;
  tmp = 1U;
  while (! (tmp >= 100U)) {
    source[tmp] = 0L;
    tmp ++;
  }
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(int64_t ));
  printLongLongLine(*(data + 0));
  return;
}
}
