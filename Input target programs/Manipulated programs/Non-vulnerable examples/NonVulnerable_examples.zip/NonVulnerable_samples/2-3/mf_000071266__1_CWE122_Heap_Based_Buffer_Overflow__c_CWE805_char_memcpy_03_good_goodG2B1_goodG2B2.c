void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_memcpy_03_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__4 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern int printf(char const   *format  , ...) ;
extern double log(double x ) ;
void main(void) ;
extern unsigned long strlen(char const   *s ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
void test_insert(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
