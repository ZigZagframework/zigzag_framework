static void goodG2B(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_67_structType myStruct ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_67b_goodG2BSink(myStruct);
  return;
}
}
