void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_06_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                    int whichBlock__7 ) ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
void STATIC_CONST_FIVE_i$nit(void) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memmove)(void *__dest ,
                                                                                                  void const   *__src ,
                                                                                                  size_t __n ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_06_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                    int whichBlock__7 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBuffer__1 ;
  void *tmp__2 ;
  wchar_t dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  wchar_t dest__6[50] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_06_good_goodG2B1_goodG2B2(0,
                                                                                                   12);
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_06_good_goodG2B1_goodG2B2(0,
                                                                                                   19);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 12: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataBuffer__1 = (wchar_t *)tmp__2;
    data__0 = dataBuffer__1;
    {
    next = 11;
    }
    break;
    case 11: ;
    if (STATIC_CONST_FIVE != 5) {
      {
      next = 10;
      }
    } else {
      {
      next = 9;
      }
    }
    break;
    case 10: 
    printLine("Benign, fixed string");
    {
    next = 8;
    }
    break;
    case 9: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 8;
    }
    break;
    case 8: 
    (*((wchar_t (*)[50])(dest__3)))[0] = 0;
    tmp___0__4 = 1U;
    {
    next = 6;
    }
    break;
    case 6: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 3;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 4: 
    (*((wchar_t (*)[50])(dest__3)))[tmp___0__4] = 0;
    tmp___0__4 ++;
    {
    next = 6;
    }
    break;
    case 3: 
    tmp___1__5 = wcslen((wchar_t const   *)data__0);
    memmove((void *)(*((wchar_t (*)[50])(dest__3))), (void const   *)data__0, tmp___1__5 * sizeof(wchar_t ));
    (*((wchar_t (*)[50])(dest__3)))[49] = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 22: 
    (*((wchar_t (*)[50])(dest__6)))[*((unsigned int *)(& tmp___1__5))] = 0;
    (*((unsigned int *)(& tmp___1__5))) ++;
    {
    next = 14;
    }
    break;
    case 21: 
    *((size_t *)(& dataBuffer__1)) = wcslen((wchar_t const   *)*((wchar_t **)(dest__3)));
    memmove((void *)(*((wchar_t (*)[50])(dest__6))), (void const   *)*((wchar_t **)(dest__3)),
            *((size_t *)(& dataBuffer__1)) * sizeof(wchar_t ));
    (*((wchar_t (*)[50])(dest__6)))[49] = 0;
    printWLine((wchar_t const   *)*((wchar_t **)(dest__3)));
    {
    next = 20;
    }
    break;
    case 20: ;
    return;
    break;
    case 19: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__2;
    *((wchar_t **)(dest__3)) = data__0;
    {
    next = 18;
    }
    break;
    case 18: ;
    if (STATIC_CONST_FIVE == 5) {
      {
      next = 17;
      }
    } else {
      {
      next = 16;
      }
    }
    break;
    case 17: 
    wmemset(*((wchar_t **)(dest__3)), 65, (size_t )49);
    *(*((wchar_t **)(dest__3)) + 49) = 0;
    {
    next = 16;
    }
    break;
    case 16: 
    (*((wchar_t (*)[50])(dest__6)))[0] = 0;
    *((unsigned int *)(& tmp___1__5)) = 1U;
    {
    next = 14;
    }
    break;
    case 14: ;
    if (*((unsigned int *)(& tmp___1__5)) >= 50U) {
      {
      next = 21;
      }
    } else {
      {
      next = 22;
      }
    }
    break;
    }
  }
}
}
