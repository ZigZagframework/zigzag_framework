void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memmove_52_good_goodG2B(void *tigressRetVal ,
                                                                                           int whichBlock__2 ) ;
extern int close(int filedes ) ;
extern void exit(int status ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern long clock(void) ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern int raise(int sig ) ;
extern int unlink(char const   *filename ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int rand() ;
extern int strcmp(char const   *a , char const   *b ) ;
extern unsigned long strtoul(char const   *str , char const   *endptr , int base ) ;
extern int getpagesize() ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern int printf(char const   *format  , ...) ;
extern double log(double x ) ;
void main(void) ;
void megaInit(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern unsigned long strlen(char const   *s ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern void free(void *ptr ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memmove_52_bad(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
