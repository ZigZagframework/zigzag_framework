void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_memcpy_42_good(void) 
{ 


  {
  _1_goodG2B_goodG2BSource(0, 0, 1);
  return;
}
}
