void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__8 ) 
{ 
  int *data__0 ;
  int *dataBadBuffer__1 ;
  void *tmp__2 ;
  int *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  int source__5[100] ;
  unsigned int tmp___1__6 ;
  int source__7[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__8;
  }
  while (1) {
    switch (next) {
    case 10: 
    tmp__2 = __builtin_alloca(50UL * sizeof(int ));
    dataBadBuffer__1 = (int *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(int ));
    dataGoodBuffer__3 = (int *)tmp___0__4;
    {
    next = 9;
    }
    break;
    case 9: ;
    if (STATIC_CONST_FALSE) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    data__0 = dataGoodBuffer__3;
    {
    next = 6;
    }
    break;
    case 6: 
    (*((int (*)[100])(source__5)))[0] = 0;
    tmp___1__6 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___1__6 >= 100U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((int (*)[100])(source__5)))[tmp___1__6] = 0;
    tmp___1__6 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((int (*)[100])(source__5))),
           100UL * sizeof(int ));
    printIntLine(*(data__0 + 0));
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(int ));
    *((int **)(& tmp___0__4)) = (int *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(int ));
    *((int **)(source__5)) = (int *)*((void **)(& dataBadBuffer__1));
    {
    next = 19;
    }
    break;
    case 19: ;
    if (STATIC_CONST_TRUE) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    *((int **)(& tmp__2)) = *((int **)(source__5));
    {
    next = 17;
    }
    break;
    case 17: 
    (*((int (*)[100])(source__7)))[0] = 0;
    tmp___1__6 = 1U;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (tmp___1__6 >= 100U) {
      {
      next = 12;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 13: 
    (*((int (*)[100])(source__7)))[tmp___1__6] = 0;
    tmp___1__6 ++;
    {
    next = 15;
    }
    break;
    case 12: 
    memcpy((void */* __restrict  */)*((int **)(& tmp__2)), (void const   */* __restrict  */)(*((int (*)[100])(source__7))),
           100UL * sizeof(int ));
    printIntLine(*(*((int **)(& tmp__2)) + 0));
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
