void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_15_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                 int whichBlock__8 ) ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_15_bad(void) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_15_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                 int whichBlock__8 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBadBuffer__1 ;
  void *tmp__2 ;
  wchar_t *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  wchar_t source__5[11] ;
  size_t tmp___1__6 ;
  wchar_t source__7[11] ;
  unsigned long next ;

  {
  {
  next = whichBlock__8;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_15_good_goodG2B1_goodG2B2(0,
                                                                                                9);
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_ncpy_15_good_goodG2B1_goodG2B2(0,
                                                                                                17);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 9: 
    tmp__2 = __builtin_alloca(10UL * sizeof(wchar_t ));
    dataBadBuffer__1 = (wchar_t *)tmp__2;
    tmp___0__4 = __builtin_alloca(11UL * sizeof(wchar_t ));
    dataGoodBuffer__3 = (wchar_t *)tmp___0__4;
    {
    next = 8;
    }
    break;
    case 8: ;
    switch (5) {
    case 6: 
    {
    next = 7;
    }
    break;
    default: 
    {
    next = 5;
    }
    break;
    }
    break;
    case 7: 
    printLine("Benign, fixed string");
    {
    next = 3;
    }
    break;
    case 5: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = 0;
    {
    next = 3;
    }
    break;
    case 3: 
    (*((wchar_t (*)[11])(source__5)))[0] = 65;
    (*((wchar_t (*)[11])(source__5)))[1] = 65;
    (*((wchar_t (*)[11])(source__5)))[2] = 65;
    (*((wchar_t (*)[11])(source__5)))[3] = 65;
    (*((wchar_t (*)[11])(source__5)))[4] = 65;
    (*((wchar_t (*)[11])(source__5)))[5] = 65;
    (*((wchar_t (*)[11])(source__5)))[6] = 65;
    (*((wchar_t (*)[11])(source__5)))[7] = 65;
    (*((wchar_t (*)[11])(source__5)))[8] = 65;
    (*((wchar_t (*)[11])(source__5)))[9] = 65;
    (*((wchar_t (*)[11])(source__5)))[10] = 0;
    tmp___1__6 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__5))));
    wcsncpy((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__5))),
            tmp___1__6 + 1UL);
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 17: 
    tmp___0__4 = __builtin_alloca(10UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp___0__4;
    *((void **)(& tmp___1__6)) = __builtin_alloca(11UL * sizeof(wchar_t ));
    *((wchar_t **)(source__5)) = (wchar_t *)*((void **)(& tmp___1__6));
    {
    next = 16;
    }
    break;
    case 16: ;
    switch (6) {
    case 6: 
    {
    next = 15;
    }
    break;
    default: 
    {
    next = 13;
    }
    break;
    }
    break;
    case 15: 
    dataGoodBuffer__3 = *((wchar_t **)(source__5));
    *(dataGoodBuffer__3 + 0) = 0;
    {
    next = 11;
    }
    break;
    case 13: 
    printLine("Benign, fixed string");
    {
    next = 11;
    }
    break;
    case 11: 
    (*((wchar_t (*)[11])(source__7)))[0] = 65;
    (*((wchar_t (*)[11])(source__7)))[1] = 65;
    (*((wchar_t (*)[11])(source__7)))[2] = 65;
    (*((wchar_t (*)[11])(source__7)))[3] = 65;
    (*((wchar_t (*)[11])(source__7)))[4] = 65;
    (*((wchar_t (*)[11])(source__7)))[5] = 65;
    (*((wchar_t (*)[11])(source__7)))[6] = 65;
    (*((wchar_t (*)[11])(source__7)))[7] = 65;
    (*((wchar_t (*)[11])(source__7)))[8] = 65;
    (*((wchar_t (*)[11])(source__7)))[9] = 65;
    (*((wchar_t (*)[11])(source__7)))[10] = 0;
    *((size_t *)(& tmp__2)) = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__7))));
    wcsncpy((wchar_t */* __restrict  */)dataGoodBuffer__3, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__7))),
            *((size_t *)(& tmp__2)) + 1UL);
    printWLine((wchar_t const   *)dataGoodBuffer__3);
    {
    next = 10;
    }
    break;
    case 10: ;
    return;
    break;
    }
  }
}
}
