static void goodG2B(void) 
{ 
  int64_t *data ;
  int64_t dataGoodBuffer[100] ;

  {
  data = dataGoodBuffer;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memmove_51b_goodG2BSink(data);
  return;
}
}
