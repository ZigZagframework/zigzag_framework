static void goodG2B1(void) 
{ 
  char *data ;
  char dataGoodBuffer[100] ;
  size_t i ;
  char source[100] ;

  {
  if (GLOBAL_CONST_FIVE != 5) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  i = (size_t )0;
  while (i < 100UL) {
    *(data + i) = source[i];
    i ++;
  }
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
