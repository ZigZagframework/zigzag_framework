void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_06_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                           int whichBlock__4 ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
void STATIC_CONST_FIVE_i$nit(void) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_06_bad(void) 
{ 
  wchar_t *data ;
  void *tmp ;
  wchar_t source[11] ;
  size_t tmp___0 ;

  {
  data = (wchar_t *)((void *)0);
  if (STATIC_CONST_FIVE == 5) {
    tmp = malloc(10UL * sizeof(wchar_t ));
    data = (wchar_t *)tmp;
  }
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  test_insert();
  tmp___0 = wcslen((wchar_t const   *)(source));
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          tmp___0 + 1UL);
  test_insert();
  printWLine((wchar_t const   *)data);
  free((void *)data);
  return;
}
}
