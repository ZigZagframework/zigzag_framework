static void goodG2B1(void) 
{ 
  char *data ;
  void *tmp ;
  char source[100] ;

  {
  data = (char *)((void *)0);
  if (STATIC_CONST_FIVE != 5) {
    printLine("Benign, fixed string");
  } else {
    tmp = malloc(100UL * sizeof(char ));
    data = (char *)tmp;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(char ));
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
