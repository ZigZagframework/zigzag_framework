static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t dataGoodBuffer[11] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = 0;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_memcpy_52b_goodG2BSink(data);
  return;
}
}
