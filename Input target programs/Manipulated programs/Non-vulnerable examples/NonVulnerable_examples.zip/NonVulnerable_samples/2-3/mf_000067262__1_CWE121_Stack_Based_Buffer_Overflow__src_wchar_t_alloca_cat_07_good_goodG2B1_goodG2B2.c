void _1_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_07_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                             int whichBlock__5 ) ;
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_07_bad(void) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_07_bad(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  if (staticFive == 5) {
    wmemset(data, 65, (size_t )99);
    *(data + 99) = 0;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  test_insert();
  wcscat((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
