static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t dataGoodBuffer[11] ;
  wchar_t *dataCopy ;
  wchar_t *data___0 ;
  wchar_t source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  data = dataGoodBuffer;
  *(data + 0) = 0;
  dataCopy = data;
  data___0 = dataCopy;
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  sourceLen = wcslen((wchar_t const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    *(data___0 + i) = source[i];
    i ++;
  }
  printWLine((wchar_t const   *)data___0);
  return;
}
}
