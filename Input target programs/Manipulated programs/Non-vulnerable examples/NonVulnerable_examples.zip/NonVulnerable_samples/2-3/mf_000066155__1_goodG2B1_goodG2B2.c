void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBuffer__1 ;
  void *tmp__2 ;
  wchar_t dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  wchar_t dest__6[50] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 6: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataBuffer__1 = (wchar_t *)tmp__2;
    data__0 = dataBuffer__1;
    CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_goodG2B1Global = 0;
    data__0 = CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_goodG2B1Source(data__0);
    (*((wchar_t (*)[50])(dest__3)))[0] = 0;
    tmp___0__4 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((wchar_t (*)[50])(dest__3)))[tmp___0__4] = 0;
    tmp___0__4 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    tmp___1__5 = wcslen((wchar_t const   *)data__0);
    memcpy((void */* __restrict  */)(*((wchar_t (*)[50])(dest__3))), (void const   */* __restrict  */)data__0,
           tmp___1__5 * sizeof(wchar_t ));
    (*((wchar_t (*)[50])(dest__3)))[49] = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 13: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__2;
    *((wchar_t **)(dest__3)) = data__0;
    CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_goodG2B2Global = 1;
    *((wchar_t **)(dest__3)) = CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_22_goodG2B2Source(*((wchar_t **)(dest__3)));
    (*((wchar_t (*)[50])(dest__6)))[0] = 0;
    *((unsigned int *)(& tmp___1__5)) = 1U;
    {
    next = 11;
    }
    break;
    case 11: ;
    if (*((unsigned int *)(& tmp___1__5)) >= 50U) {
      {
      next = 8;
      }
    } else {
      {
      next = 9;
      }
    }
    break;
    case 9: 
    (*((wchar_t (*)[50])(dest__6)))[*((unsigned int *)(& tmp___1__5))] = 0;
    (*((unsigned int *)(& tmp___1__5))) ++;
    {
    next = 11;
    }
    break;
    case 8: 
    *((size_t *)(& dataBuffer__1)) = wcslen((wchar_t const   *)*((wchar_t **)(dest__3)));
    memcpy((void */* __restrict  */)(*((wchar_t (*)[50])(dest__6))), (void const   */* __restrict  */)*((wchar_t **)(dest__3)),
           *((size_t *)(& dataBuffer__1)) * sizeof(wchar_t ));
    (*((wchar_t (*)[50])(dest__6)))[49] = 0;
    printWLine((wchar_t const   *)*((wchar_t **)(dest__3)));
    {
    next = 7;
    }
    break;
    case 7: ;
    return;
    break;
    }
  }
}
}
