static void goodG2B(void) 
{ 
  int h ;
  int j ;
  void *data ;
  size_t dataLen ;
  size_t tmp ;
  void *dest ;
  void *tmp___0 ;

  {
  data = (void *)0;
  h = 0;
  while (h < 1) {
    data = (void *)"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    h ++;
  }
  j = 0;
  while (j < 1) {
    tmp = strlen((char const   *)((char *)data));
    dataLen = tmp;
    tmp___0 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___0;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
    j ++;
  }
  return;
}
}
