static void goodG2B(void) 
{ 
  char *data ;
  char dataBuffer[100] ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_68_goodG2BData = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_68b_goodG2BSink();
  return;
}
}
