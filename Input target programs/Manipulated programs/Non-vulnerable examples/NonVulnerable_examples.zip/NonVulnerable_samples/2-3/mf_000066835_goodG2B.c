static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;
  int tmp___1 ;
  wchar_t source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  tmp___1 = globalReturnsTrueOrFalse();
  if (tmp___1) {
    data = dataGoodBuffer;
    *(data + 0) = 0;
  } else {
    data = dataGoodBuffer;
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  wcscat((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source));
  printWLine((wchar_t const   *)data);
  return;
}
}
