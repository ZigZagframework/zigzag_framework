void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_loop_08_good_goodG2B2_staticReturnsTrue(void *tigressRetVal ,
                                                                                                        int whichBlock__5 ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
