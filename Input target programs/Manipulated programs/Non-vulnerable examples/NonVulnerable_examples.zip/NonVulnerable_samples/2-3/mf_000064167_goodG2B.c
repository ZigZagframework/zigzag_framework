static void goodG2B(void) 
{ 
  char *data ;
  char dataGoodBuffer[100] ;
  char source[100] ;

  {
  while (1) {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
    break;
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  memmove((void *)data, (void const   *)(source), 100UL * sizeof(char ));
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
