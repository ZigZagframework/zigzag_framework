void CWE121_Stack_Based_Buffer_Overflow__CWE135_42_good(void) 
{ 


  {
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE135_42_bad_goodB2G_goodG2B_goodG2BSource(0,
                                                                                     0,
                                                                                     3);
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE135_42_bad_goodB2G_goodG2B_goodG2BSource(0,
                                                                                     0,
                                                                                     5);
  return;
}
}
