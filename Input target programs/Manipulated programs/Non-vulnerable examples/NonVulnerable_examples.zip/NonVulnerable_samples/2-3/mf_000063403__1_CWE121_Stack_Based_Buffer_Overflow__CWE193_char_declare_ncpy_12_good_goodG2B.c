void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_12_good_goodG2B(void *tigressRetVal ,
                                                                                     int whichBlock__5 ) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2), __leaf__)) strncpy)(char * __restrict  __dest ,
                                                                                                  char const   * __restrict  __src ,
                                                                                                  size_t __n ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_12_bad(void) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern int globalReturnsTrueOrFalse() ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_12_good_goodG2B(void *tigressRetVal ,
                                                                                     int whichBlock__5 ) 
{ 
  char *data__0 ;
  char dataGoodBuffer__1[11] ;
  int tmp__2 ;
  char source__3[11] ;
  size_t tmp___0__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_ncpy_12_good_goodG2B(0,
                                                                                    7);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 7: 
    tmp__2 = globalReturnsTrueOrFalse();
    {
    next = 6;
    }
    break;
    case 6: ;
    if (tmp__2) {
      {
      next = 5;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 5: 
    data__0 = *((char (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    {
    next = 3;
    }
    break;
    case 4: 
    data__0 = *((char (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    {
    next = 3;
    }
    break;
    case 3: 
    (*((char (*)[11])(source__3)))[0] = (char )'A';
    (*((char (*)[11])(source__3)))[1] = (char )'A';
    (*((char (*)[11])(source__3)))[2] = (char )'A';
    (*((char (*)[11])(source__3)))[3] = (char )'A';
    (*((char (*)[11])(source__3)))[4] = (char )'A';
    (*((char (*)[11])(source__3)))[5] = (char )'A';
    (*((char (*)[11])(source__3)))[6] = (char )'A';
    (*((char (*)[11])(source__3)))[7] = (char )'A';
    (*((char (*)[11])(source__3)))[8] = (char )'A';
    (*((char (*)[11])(source__3)))[9] = (char )'A';
    (*((char (*)[11])(source__3)))[10] = (char )'\000';
    tmp___0__4 = strlen((char const   *)(*((char (*)[11])(source__3))));
    strncpy((char */* __restrict  */)data__0, (char const   */* __restrict  */)(*((char (*)[11])(source__3))),
            tmp___0__4 + 1UL);
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
