static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBadBuffer ;
  void *tmp ;
  wchar_t *dataGoodBuffer ;
  void *tmp___0 ;
  wchar_t source[11] ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(10UL * sizeof(wchar_t ));
  dataBadBuffer = (wchar_t *)tmp;
  tmp___0 = __builtin_alloca(11UL * sizeof(wchar_t ));
  dataGoodBuffer = (wchar_t *)tmp___0;
  goto source;
  source: 
  data = dataGoodBuffer;
  *(data + 0) = 0;
  source[0] = 65;
  source[1] = 65;
  source[2] = 65;
  source[3] = 65;
  source[4] = 65;
  source[5] = 65;
  source[6] = 65;
  source[7] = 65;
  source[8] = 65;
  source[9] = 65;
  source[10] = 0;
  tmp___1 = wcslen((wchar_t const   *)(source));
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          tmp___1 + 1UL);
  printWLine((wchar_t const   *)data);
  return;
}
}
