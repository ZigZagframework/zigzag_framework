void CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memmove_41_good(void) 
{ 


  {
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memmove_41_badSink_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_alloca_memmove_41_goodG2BSink_goodG2B(0,
                                                                                                                                                                           0,
                                                                                                                                                                           5);
  return;
}
}
