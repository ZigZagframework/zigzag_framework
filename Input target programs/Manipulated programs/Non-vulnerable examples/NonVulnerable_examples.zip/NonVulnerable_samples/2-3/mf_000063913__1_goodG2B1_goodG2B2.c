void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  char source__5[100] ;
  char source__6[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 1: 
    tmp__2 = __builtin_alloca(50UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    memset((void *)(*((char (*)[100])(source__5))), 'C', (size_t )99);
    (*((char (*)[100])(source__5)))[99] = (char )'\000';
    memmove((void *)data__0, (void const   *)(*((char (*)[100])(source__5))), 100UL * sizeof(char ));
    *(data__0 + 99) = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(char ));
    *((char **)(& tmp___0__4)) = (char *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(char ));
    *((char **)(source__5)) = (char *)*((void **)(& dataBadBuffer__1));
    *((char **)(& tmp__2)) = *((char **)(source__5));
    *(*((char **)(& tmp__2)) + 0) = (char )'\000';
    memset((void *)(*((char (*)[100])(source__6))), 'C', (size_t )99);
    (*((char (*)[100])(source__6)))[99] = (char )'\000';
    memmove((void *)*((char **)(& tmp__2)), (void const   *)(*((char (*)[100])(source__6))),
            100UL * sizeof(char ));
    *(*((char **)(& tmp__2)) + 99) = (char )'\000';
    printLine((char const   *)*((char **)(& tmp__2)));
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
