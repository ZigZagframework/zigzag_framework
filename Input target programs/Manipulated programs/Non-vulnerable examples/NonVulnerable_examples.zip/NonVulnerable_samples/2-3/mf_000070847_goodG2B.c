static void goodG2B(void) 
{ 
  char *data ;
  void *tmp ;
  char source[11] ;
  size_t tmp___0 ;

  {
  data = (char *)((void *)0);
  while (1) {
    tmp = malloc(11UL * sizeof(char ));
    data = (char *)tmp;
    break;
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  tmp___0 = strlen((char const   *)(source));
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         (tmp___0 + 1UL) * sizeof(char ));
  printLine((char const   *)data);
  free((void *)data);
  return;
}
}
