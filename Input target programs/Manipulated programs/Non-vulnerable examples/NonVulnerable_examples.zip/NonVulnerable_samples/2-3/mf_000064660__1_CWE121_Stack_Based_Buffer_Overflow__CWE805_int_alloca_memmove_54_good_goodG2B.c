void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_int_alloca_memmove_54_good_goodG2B(void *tigressRetVal ,
                                                                                      int whichBlock__5 ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern void free(void *ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
