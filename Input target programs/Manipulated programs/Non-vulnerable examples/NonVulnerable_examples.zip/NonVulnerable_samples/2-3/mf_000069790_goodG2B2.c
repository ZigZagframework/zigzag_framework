static void goodG2B2(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;
  size_t i ;

  {
  data = (int *)((void *)0);
  switch (6) {
  case 6: 
  tmp = malloc(10UL * sizeof(int ));
  data = (int *)tmp;
  break;
  default: 
  printLine("Benign, fixed string");
  break;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  i = (size_t )0;
  while (i < 10UL) {
    *(data + i) = source[i];
    i ++;
  }
  printIntLine(*(data + 0));
  free((void *)data);
  return;
}
}
