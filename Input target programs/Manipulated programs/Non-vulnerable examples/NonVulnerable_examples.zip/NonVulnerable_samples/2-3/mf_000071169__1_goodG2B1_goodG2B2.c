void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__4 ) 
{ 
  wchar_t *data__0 ;
  void *tmp__1 ;
  wchar_t source__2[11] ;
  size_t tmp___0__3 ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 1: 
    data__0 = (wchar_t *)((void *)0);
    tmp__1 = malloc(11UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__1;
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    tmp___0__3 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    wcsncpy((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__2))),
            tmp___0__3 + 1UL);
    printWLine((wchar_t const   *)data__0);
    free((void *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    data__0 = (wchar_t *)((void *)0);
    tmp__1 = malloc(11UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__1;
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    tmp___0__3 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    wcsncpy((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__2))),
            tmp___0__3 + 1UL);
    printWLine((wchar_t const   *)data__0);
    free((void *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
