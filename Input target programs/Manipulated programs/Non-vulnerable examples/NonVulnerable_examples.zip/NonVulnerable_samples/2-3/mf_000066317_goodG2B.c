static void goodG2B(void) 
{ 
  wchar_t *data ;
  void (*funcPtr)(wchar_t * ) ;
  wchar_t *dataBuffer ;
  void *tmp ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_ncpy_65b_goodG2BSink;
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  wmemset(data, 65, (size_t )49);
  *(data + 49) = 0;
  (*funcPtr)(data);
  return;
}
}
