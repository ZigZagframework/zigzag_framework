void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_02_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                               int whichBlock__4 ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
void CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_02_bad(void) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cat_02_bad(void) 
{ 
  wchar_t *data ;
  wchar_t dataBadBuffer[50] ;
  wchar_t source[100] ;

  {
  test_insert();
  data = dataBadBuffer;
  test_insert();
  *(data + 0) = 0;
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  test_insert();
  wcscat((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source));
  test_insert();
  printWLine((wchar_t const   *)data);
  return;
}
}
