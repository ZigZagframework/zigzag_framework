static void goodB2G(void) 
{ 
  int data ;
  int i ;
  int *buffer ;
  void *tmp ;

  {
  data = -1;
  data = CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_61b_goodB2GSource(data);
  tmp = malloc(10UL * sizeof(int ));
  buffer = (int *)tmp;
  i = 0;
  while (i < 10) {
    *(buffer + i) = 0;
    i ++;
  }
  if (data >= 0) {
    if (data < 10) {
      *(buffer + data) = 1;
      i = 0;
      while (i < 10) {
        printIntLine(*(buffer + i));
        i ++;
      }
    } else {
      printLine("ERROR: Array index is out-of-bounds");
    }
  } else {
    printLine("ERROR: Array index is out-of-bounds");
  }
  free((void *)buffer);
  return;
}
}
