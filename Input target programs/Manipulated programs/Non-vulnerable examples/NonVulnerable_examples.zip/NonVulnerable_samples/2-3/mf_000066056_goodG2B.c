static void goodG2B(void) 
{ 
  int h ;
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  h = 0;
  while (h < 1) {
    memset((void *)data, 'A', (size_t )49);
    *(data + 49) = (char )'\000';
    h ++;
  }
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = strlen((char const   *)data);
  snprintf((char */* __restrict  */)(dest), tmp___0, (char const   */* __restrict  */)"%s",
           data);
  printLine((char const   *)data);
  return;
}
}
