static void goodG2B1(void) 
{ 
  wchar_t *data ;
  wchar_t dataGoodBuffer[100] ;
  wchar_t source[100] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = 0;
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  wcsncat((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          (size_t )100);
  printWLine((wchar_t const   *)data);
  return;
}
}
