static void goodG2B(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memcpy_52b_goodG2BSink(data);
  return;
}
}
