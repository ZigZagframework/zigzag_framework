void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_54_good_goodG2B(void *tigressRetVal ,
                                                                             int whichBlock__2 ) ;
extern int rand() ;
extern int strcmp(char const   *a , char const   *b ) ;
extern unsigned long strtoul(char const   *str , char const   *endptr , int base ) ;
extern int getpagesize() ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_54b_badSink(char *data ) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_54b_goodG2BSink(char *data ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern int printf(char const   *format  , ...) ;
extern double log(double x ) ;
void main(void) ;
void megaInit(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern unsigned long strlen(char const   *s ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern void free(void *ptr ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
