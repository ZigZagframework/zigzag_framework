void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBuffer__1 ;
  void *tmp__2 ;
  wchar_t dest__3[50] ;
  unsigned int tmp___0__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 12: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataBuffer__1 = (wchar_t *)tmp__2;
    data__0 = dataBuffer__1;
    {
    next = 11;
    }
    break;
    case 11: ;
    switch (5) {
    case 6: 
    {
    next = 10;
    }
    break;
    default: 
    {
    next = 8;
    }
    break;
    }
    break;
    case 10: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 8: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 6;
    }
    break;
    case 6: 
    (*((wchar_t (*)[50])(dest__3)))[0] = 0;
    tmp___0__4 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((wchar_t (*)[50])(dest__3)))[tmp___0__4] = 0;
    tmp___0__4 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    wcscpy((wchar_t */* __restrict  */)(*((wchar_t (*)[50])(dest__3))), (wchar_t const   */* __restrict  */)data__0);
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 25: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataBuffer__1 = (wchar_t *)tmp__2;
    data__0 = dataBuffer__1;
    {
    next = 24;
    }
    break;
    case 24: ;
    switch (6) {
    case 6: 
    {
    next = 23;
    }
    break;
    default: 
    {
    next = 21;
    }
    break;
    }
    break;
    case 23: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 19;
    }
    break;
    case 21: 
    printLine("Benign, fixed string");
    {
    next = 19;
    }
    break;
    case 19: 
    (*((wchar_t (*)[50])(dest__3)))[0] = 0;
    tmp___0__4 = 1U;
    {
    next = 17;
    }
    break;
    case 17: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 14;
      }
    } else {
      {
      next = 15;
      }
    }
    break;
    case 15: 
    (*((wchar_t (*)[50])(dest__3)))[tmp___0__4] = 0;
    tmp___0__4 ++;
    {
    next = 17;
    }
    break;
    case 14: 
    wcscpy((wchar_t */* __restrict  */)(*((wchar_t (*)[50])(dest__3))), (wchar_t const   */* __restrict  */)data__0);
    printWLine((wchar_t const   *)data__0);
    {
    next = 13;
    }
    break;
    case 13: ;
    return;
    break;
    }
  }
}
}
