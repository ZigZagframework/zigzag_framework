void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_loop_15_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__8 ) ;
void main(void) ;
void megaInit(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern unsigned long strlen(char const   *s ) ;
extern void free(void *ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
void test_insert(void) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
