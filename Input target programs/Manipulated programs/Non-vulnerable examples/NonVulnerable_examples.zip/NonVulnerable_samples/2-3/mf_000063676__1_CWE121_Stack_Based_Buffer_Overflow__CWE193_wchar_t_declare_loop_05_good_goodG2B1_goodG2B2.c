void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_05_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                  int whichBlock__5 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_05_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                  int whichBlock__5 ) 
{ 
  wchar_t *data__0 ;
  wchar_t dataGoodBuffer__1[11] ;
  wchar_t source__2[11] ;
  size_t i__3 ;
  size_t sourceLen__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_05_good_goodG2B1_goodG2B2(0,
                                                                                                 11);
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_wchar_t_declare_loop_05_good_goodG2B1_goodG2B2(0,
                                                                                                 20);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 11: ;
    if (staticFalse) {
      {
      next = 10;
      }
    } else {
      {
      next = 9;
      }
    }
    break;
    case 10: 
    printLine("Benign, fixed string");
    {
    next = 8;
    }
    break;
    case 9: 
    data__0 = *((wchar_t (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = 0;
    {
    next = 8;
    }
    break;
    case 8: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    i__3 = (size_t )0;
    {
    next = 6;
    }
    break;
    case 6: ;
    if (i__3 < sourceLen__4 + 1UL) {
      {
      next = 4;
      }
    } else {
      {
      next = 3;
      }
    }
    break;
    case 4: 
    *(data__0 + i__3) = (*((wchar_t (*)[11])(source__2)))[i__3];
    i__3 ++;
    {
    next = 6;
    }
    break;
    case 3: 
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 20: ;
    if (staticTrue) {
      {
      next = 19;
      }
    } else {
      {
      next = 18;
      }
    }
    break;
    case 19: 
    *((wchar_t **)(& i__3)) = *((wchar_t (*)[11])(dataGoodBuffer__1));
    *(*((wchar_t **)(& i__3)) + 0) = 0;
    {
    next = 18;
    }
    break;
    case 18: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    *((size_t *)(& data__0)) = (size_t )0;
    {
    next = 16;
    }
    break;
    case 16: ;
    if (*((size_t *)(& data__0)) < sourceLen__4 + 1UL) {
      {
      next = 14;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 14: 
    *(*((wchar_t **)(& i__3)) + *((size_t *)(& data__0))) = (*((wchar_t (*)[11])(source__2)))[*((size_t *)(& data__0))];
    (*((size_t *)(& data__0))) ++;
    {
    next = 16;
    }
    break;
    case 13: 
    printWLine((wchar_t const   *)*((wchar_t **)(& i__3)));
    {
    next = 12;
    }
    break;
    case 12: ;
    return;
    break;
    }
  }
}
}
