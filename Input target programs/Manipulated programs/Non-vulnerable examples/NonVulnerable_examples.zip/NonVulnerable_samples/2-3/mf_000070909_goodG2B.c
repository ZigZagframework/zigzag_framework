static void goodG2B(void) 
{ 
  char *data ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(11UL * sizeof(char ));
  data = (char *)tmp;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_51b_goodG2BSink(data);
  return;
}
}
