static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  wmemset(data, 65, (size_t )49);
  *(data + 49) = 0;
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  wcscat((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  printWLine((wchar_t const   *)data);
  return;
}
}
