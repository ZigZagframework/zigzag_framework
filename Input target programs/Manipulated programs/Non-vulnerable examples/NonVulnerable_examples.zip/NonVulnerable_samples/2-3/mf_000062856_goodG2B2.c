static void goodG2B2(void) 
{ 
  int *data ;
  void *tmp ;
  int source[10] ;
  unsigned int tmp___0 ;

  {
  data = (int *)((void *)0);
  if (staticTrue) {
    tmp = __builtin_alloca(10UL * sizeof(int ));
    data = (int *)tmp;
  }
  source[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 10U)) {
    source[tmp___0] = 0;
    tmp___0 ++;
  }
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         10UL * sizeof(int ));
  printIntLine(*(data + 0));
  return;
}
}
