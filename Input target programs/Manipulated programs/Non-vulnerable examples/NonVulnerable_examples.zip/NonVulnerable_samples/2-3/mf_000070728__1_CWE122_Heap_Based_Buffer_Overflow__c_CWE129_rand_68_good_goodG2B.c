void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68_good_goodG2B(void *tigressRetVal ,
                                                                         int whichBlock__1 ) ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68b_goodB2GSink() ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68b_badSink() ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68b_goodG2BSink() ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void main(void) 
{ 


  {
  megaInit();
}
}
