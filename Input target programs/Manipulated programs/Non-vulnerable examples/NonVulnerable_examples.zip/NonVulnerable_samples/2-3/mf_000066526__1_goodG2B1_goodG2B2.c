void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  wchar_t *data__0 ;
  wchar_t dataBuffer__1[100] ;
  wchar_t dest__2[50] ;
  unsigned int tmp__3 ;
  size_t tmp___0__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 10: 
    data__0 = *((wchar_t (*)[100])(dataBuffer__1));
    {
    next = 9;
    }
    break;
    case 9: ;
    if (staticFive != 5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 6;
    }
    break;
    case 6: 
    (*((wchar_t (*)[50])(dest__2)))[0] = 0;
    tmp__3 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp__3 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((wchar_t (*)[50])(dest__2)))[tmp__3] = 0;
    tmp__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    tmp___0__4 = wcslen((wchar_t const   *)data__0);
    wcsncat((wchar_t */* __restrict  */)(*((wchar_t (*)[50])(dest__2))), (wchar_t const   */* __restrict  */)data__0,
            tmp___0__4);
    (*((wchar_t (*)[50])(dest__2)))[49] = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    data__0 = *((wchar_t (*)[100])(dataBuffer__1));
    {
    next = 19;
    }
    break;
    case 19: ;
    if (staticFive == 5) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 17;
    }
    break;
    case 17: 
    (*((wchar_t (*)[50])(dest__2)))[0] = 0;
    tmp__3 = 1U;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (tmp__3 >= 50U) {
      {
      next = 12;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 13: 
    (*((wchar_t (*)[50])(dest__2)))[tmp__3] = 0;
    tmp__3 ++;
    {
    next = 15;
    }
    break;
    case 12: 
    tmp___0__4 = wcslen((wchar_t const   *)data__0);
    wcsncat((wchar_t */* __restrict  */)(*((wchar_t (*)[50])(dest__2))), (wchar_t const   */* __restrict  */)data__0,
            tmp___0__4);
    (*((wchar_t (*)[50])(dest__2)))[49] = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
