void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_53_good_goodG2B(void *tigressRetVal ,
                                                                         int whichBlock__1 ) ;
extern int getpagesize() ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int printf(char const   *format  , ...) ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_53b_goodB2GSink(int data ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern double log(double x ) ;
void main(void) ;
void megaInit(void) ;
extern unsigned long strlen(char const   *s ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern void free(void *ptr ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
static void goodB2G(void) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
