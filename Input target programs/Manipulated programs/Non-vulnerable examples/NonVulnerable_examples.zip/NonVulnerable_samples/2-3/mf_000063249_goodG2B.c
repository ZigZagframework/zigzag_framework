static void goodG2B(void) 
{ 
  char *data ;
  char dataGoodBuffer[11] ;
  char source[11] ;

  {
  goto source;
  source: 
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  strcpy((char */* __restrict  */)data, (char const   */* __restrict  */)(source));
  printLine((char const   *)data);
  return;
}
}
