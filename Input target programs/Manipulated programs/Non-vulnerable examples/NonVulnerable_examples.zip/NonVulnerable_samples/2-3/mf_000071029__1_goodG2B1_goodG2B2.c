void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  wchar_t *data__0 ;
  void *tmp__1 ;
  wchar_t source__2[11] ;
  size_t i__3 ;
  size_t sourceLen__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 10: 
    data__0 = (wchar_t *)((void *)0);
    {
    next = 9;
    }
    break;
    case 9: ;
    if (STATIC_CONST_FIVE != 5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    tmp__1 = malloc(11UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__1;
    {
    next = 6;
    }
    break;
    case 6: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    i__3 = (size_t )0;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (i__3 < sourceLen__4 + 1UL) {
      {
      next = 2;
      }
    } else {
      {
      next = 1;
      }
    }
    break;
    case 2: 
    *(data__0 + i__3) = (*((wchar_t (*)[11])(source__2)))[i__3];
    i__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    printWLine((wchar_t const   *)data__0);
    free((void *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    *((wchar_t **)(& i__3)) = (wchar_t *)((void *)0);
    {
    next = 19;
    }
    break;
    case 19: ;
    if (STATIC_CONST_FIVE == 5) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    *((void **)(& data__0)) = malloc(11UL * sizeof(wchar_t ));
    *((wchar_t **)(& i__3)) = (wchar_t *)*((void **)(& data__0));
    {
    next = 17;
    }
    break;
    case 17: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    *((size_t *)(& tmp__1)) = (size_t )0;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (*((size_t *)(& tmp__1)) < sourceLen__4 + 1UL) {
      {
      next = 13;
      }
    } else {
      {
      next = 12;
      }
    }
    break;
    case 13: 
    *(*((wchar_t **)(& i__3)) + *((size_t *)(& tmp__1))) = (*((wchar_t (*)[11])(source__2)))[*((size_t *)(& tmp__1))];
    (*((size_t *)(& tmp__1))) ++;
    {
    next = 15;
    }
    break;
    case 12: 
    printWLine((wchar_t const   *)*((wchar_t **)(& i__3)));
    free((void *)*((wchar_t **)(& i__3)));
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
