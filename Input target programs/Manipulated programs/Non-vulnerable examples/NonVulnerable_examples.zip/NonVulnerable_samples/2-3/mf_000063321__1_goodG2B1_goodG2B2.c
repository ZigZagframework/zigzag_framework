void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__4 ) 
{ 
  char *data__0 ;
  char dataGoodBuffer__1[11] ;
  char source__2[11] ;
  size_t tmp__3 ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 4: ;
    if (globalFalse) {
      {
      next = 3;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 3: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 2: 
    data__0 = *((char (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    {
    next = 1;
    }
    break;
    case 1: 
    (*((char (*)[11])(source__2)))[0] = (char )'A';
    (*((char (*)[11])(source__2)))[1] = (char )'A';
    (*((char (*)[11])(source__2)))[2] = (char )'A';
    (*((char (*)[11])(source__2)))[3] = (char )'A';
    (*((char (*)[11])(source__2)))[4] = (char )'A';
    (*((char (*)[11])(source__2)))[5] = (char )'A';
    (*((char (*)[11])(source__2)))[6] = (char )'A';
    (*((char (*)[11])(source__2)))[7] = (char )'A';
    (*((char (*)[11])(source__2)))[8] = (char )'A';
    (*((char (*)[11])(source__2)))[9] = (char )'A';
    (*((char (*)[11])(source__2)))[10] = (char )'\000';
    tmp__3 = strlen((char const   *)(*((char (*)[11])(source__2))));
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((char (*)[11])(source__2))),
           (tmp__3 + 1UL) * sizeof(char ));
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 8: ;
    if (globalTrue) {
      {
      next = 7;
      }
    } else {
      {
      next = 6;
      }
    }
    break;
    case 7: 
    data__0 = *((char (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = (char )'\000';
    {
    next = 6;
    }
    break;
    case 6: 
    (*((char (*)[11])(source__2)))[0] = (char )'A';
    (*((char (*)[11])(source__2)))[1] = (char )'A';
    (*((char (*)[11])(source__2)))[2] = (char )'A';
    (*((char (*)[11])(source__2)))[3] = (char )'A';
    (*((char (*)[11])(source__2)))[4] = (char )'A';
    (*((char (*)[11])(source__2)))[5] = (char )'A';
    (*((char (*)[11])(source__2)))[6] = (char )'A';
    (*((char (*)[11])(source__2)))[7] = (char )'A';
    (*((char (*)[11])(source__2)))[8] = (char )'A';
    (*((char (*)[11])(source__2)))[9] = (char )'A';
    (*((char (*)[11])(source__2)))[10] = (char )'\000';
    tmp__3 = strlen((char const   *)(*((char (*)[11])(source__2))));
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((char (*)[11])(source__2))),
           (tmp__3 + 1UL) * sizeof(char ));
    printLine((char const   *)data__0);
    {
    next = 5;
    }
    break;
    case 5: ;
    return;
    break;
    }
  }
}
}
