void _1_CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_09_good_goodG2B2(void *tigressRetVal ,
                                                                                  int whichBlock__6 ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__dest_char_alloca_cat_09_bad(void) ;
static void goodG2B1(void) 
{ 
  char *data ;
  char *dataBadBuffer ;
  void *tmp ;
  char *dataGoodBuffer ;
  void *tmp___0 ;
  char source[100] ;

  {
  tmp = __builtin_alloca(50UL * sizeof(char ));
  dataBadBuffer = (char *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(char ));
  dataGoodBuffer = (char *)tmp___0;
  if (GLOBAL_CONST_FALSE) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  strcat((char */* __restrict  */)data, (char const   */* __restrict  */)(source));
  printLine((char const   *)data);
  return;
}
}
