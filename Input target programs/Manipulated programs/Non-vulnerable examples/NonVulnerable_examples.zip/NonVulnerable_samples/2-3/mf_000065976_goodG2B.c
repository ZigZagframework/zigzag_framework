static void goodG2B(void) 
{ 
  char *data ;
  char dataBuffer[100] ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_54b_goodG2BSink(data);
  return;
}
}
