void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_07_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                           int whichBlock__4 ) ;
void staticFive_i$nit(void) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
static int staticFive ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_07_bad(void) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_07_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                           int whichBlock__4 ) 
{ 
  wchar_t *data__0 ;
  void *tmp__1 ;
  wchar_t source__2[11] ;
  size_t tmp___0__3 ;
  unsigned long next ;

  {
  {
  next = whichBlock__4;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_07_good_goodG2B1_goodG2B2(0,
                                                                                          7);
    _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_ncpy_07_good_goodG2B1_goodG2B2(0,
                                                                                          12);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 7: 
    data__0 = (wchar_t *)((void *)0);
    {
    next = 6;
    }
    break;
    case 6: ;
    if (staticFive != 5) {
      {
      next = 5;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 5: 
    printLine("Benign, fixed string");
    {
    next = 3;
    }
    break;
    case 4: 
    tmp__1 = malloc(11UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__1;
    {
    next = 3;
    }
    break;
    case 3: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    tmp___0__3 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    wcsncpy((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__2))),
            tmp___0__3 + 1UL);
    printWLine((wchar_t const   *)data__0);
    free((void *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 12: 
    data__0 = (wchar_t *)((void *)0);
    {
    next = 11;
    }
    break;
    case 11: ;
    if (staticFive == 5) {
      {
      next = 10;
      }
    } else {
      {
      next = 9;
      }
    }
    break;
    case 10: 
    tmp__1 = malloc(11UL * sizeof(wchar_t ));
    data__0 = (wchar_t *)tmp__1;
    {
    next = 9;
    }
    break;
    case 9: 
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    tmp___0__3 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    wcsncpy((wchar_t */* __restrict  */)data__0, (wchar_t const   */* __restrict  */)(*((wchar_t (*)[11])(source__2))),
            tmp___0__3 + 1UL);
    printWLine((wchar_t const   *)data__0);
    free((void *)data__0);
    {
    next = 8;
    }
    break;
    case 8: ;
    return;
    break;
    }
  }
}
}
