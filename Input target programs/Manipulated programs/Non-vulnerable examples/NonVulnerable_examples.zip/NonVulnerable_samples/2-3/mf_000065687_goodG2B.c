static void goodG2B(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_53b_goodG2BSink(data);
  return;
}
}
