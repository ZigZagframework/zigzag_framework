void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_04_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                               int whichBlock__5 ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
void STATIC_CONST_TRUE_i$nit(void) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
void STATIC_CONST_FALSE_i$nit(void) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void STATIC_CONST_FALSE_i$nit(void) 
{ 


  {
  STATIC_CONST_FALSE = (int const   )0;
}
}
