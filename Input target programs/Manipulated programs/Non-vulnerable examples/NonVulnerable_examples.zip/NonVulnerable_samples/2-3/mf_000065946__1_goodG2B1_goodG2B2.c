void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  char *data__0 ;
  char dataBuffer__1[100] ;
  char dest__2[50] ;
  unsigned int tmp__3 ;
  size_t tmp___0__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 6: 
    data__0 = *((char (*)[100])(dataBuffer__1));
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    (*((char (*)[50])(dest__2)))[0] = (char )'\000';
    tmp__3 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp__3 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((char (*)[50])(dest__2)))[tmp__3] = (char)0;
    tmp__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    tmp___0__4 = strlen((char const   *)data__0);
    strncat((char */* __restrict  */)(*((char (*)[50])(dest__2))), (char const   */* __restrict  */)data__0,
            tmp___0__4);
    (*((char (*)[50])(dest__2)))[49] = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 13: 
    data__0 = *((char (*)[100])(dataBuffer__1));
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    (*((char (*)[50])(dest__2)))[0] = (char )'\000';
    tmp__3 = 1U;
    {
    next = 11;
    }
    break;
    case 11: ;
    if (tmp__3 >= 50U) {
      {
      next = 8;
      }
    } else {
      {
      next = 9;
      }
    }
    break;
    case 9: 
    (*((char (*)[50])(dest__2)))[tmp__3] = (char)0;
    tmp__3 ++;
    {
    next = 11;
    }
    break;
    case 8: 
    tmp___0__4 = strlen((char const   *)data__0);
    strncat((char */* __restrict  */)(*((char (*)[50])(dest__2))), (char const   */* __restrict  */)data__0,
            tmp___0__4);
    (*((char (*)[50])(dest__2)))[49] = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 7;
    }
    break;
    case 7: ;
    return;
    break;
    }
  }
}
}
