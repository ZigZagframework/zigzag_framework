void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memmove_14_good_goodG2B2(void *tigressRetVal ,
                                                                                        int whichBlock__6 ) ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int scanf(char const   *format  , ...) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memmove_14_bad(void) ;
extern long time(long *tloc ) ;
extern int globalFive ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memmove)(void *__dest ,
                                                                                                  void const   *__src ,
                                                                                                  size_t __n ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memmove_14_good_goodG2B2(void *tigressRetVal ,
                                                                                        int whichBlock__6 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  char source__5[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__6;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memmove_14_good_goodG2B2(0,
                                                                                       6);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 6: 
    tmp__2 = __builtin_alloca(50UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    {
    next = 5;
    }
    break;
    case 5: ;
    if (globalFive == 5) {
      {
      next = 4;
      }
    } else {
      {
      next = 3;
      }
    }
    break;
    case 4: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    {
    next = 3;
    }
    break;
    case 3: 
    memset((void *)(*((char (*)[100])(source__5))), 'C', (size_t )99);
    (*((char (*)[100])(source__5)))[99] = (char )'\000';
    memmove((void *)data__0, (void const   *)(*((char (*)[100])(source__5))), 100UL * sizeof(char ));
    *(data__0 + 99) = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
