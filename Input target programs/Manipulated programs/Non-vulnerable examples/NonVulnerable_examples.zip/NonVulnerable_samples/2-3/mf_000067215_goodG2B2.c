static void goodG2B2(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  int tmp ;
  char dest[50] ;
  unsigned int tmp___0 ;

  {
  data = dataBuffer;
  _1_CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_08_bad_goodG2B1_staticReturnsFalse_staticReturnsTrue(& tmp,
                                                                                                                   22);
  if (tmp) {
    memset((void *)data, 'A', (size_t )49);
    *(data + 49) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = (char)0;
    tmp___0 ++;
  }
  strcpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  printLine((char const   *)data);
  return;
}
}
