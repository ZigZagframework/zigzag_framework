static void goodB2G(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68_goodB2GData = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68b_goodB2GSink();
  return;
}
}
