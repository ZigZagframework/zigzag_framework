void _1_CWE122_Heap_Based_Buffer_Overflow__CWE135_22_good_goodB2G1_goodB2G2(void *tigressRetVal ,
                                                                            int whichBlock__3 ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_badGlobal_i$nit(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodB2G1Sink(void *data ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodB2G2Global_i$nit(void) ;
typedef struct _IO_FILE FILE;
extern void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BSink(void *data ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
int CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BGlobal ;
int CWE122_Heap_Based_Buffer_Overflow__CWE135_22_badGlobal ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern double log(double x ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BGlobal_i$nit(void) ;
int CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodB2G1Global ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BGlobal_i$nit(void) 
{ 


  {
  CWE122_Heap_Based_Buffer_Overflow__CWE135_22_goodG2BGlobal = 0;
}
}
