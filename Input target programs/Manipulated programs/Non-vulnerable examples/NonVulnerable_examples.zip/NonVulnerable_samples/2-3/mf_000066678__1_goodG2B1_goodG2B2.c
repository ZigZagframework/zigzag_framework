void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  char source__5[100] ;
  char source__6[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 7: 
    tmp__2 = __builtin_alloca(50UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(100UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    {
    next = 6;
    }
    break;
    case 6: ;
    switch (5) {
    case 6: 
    {
    next = 5;
    }
    break;
    default: 
    {
    next = 3;
    }
    break;
    }
    break;
    case 5: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 3: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    {
    next = 1;
    }
    break;
    case 1: 
    memset((void *)(*((char (*)[100])(source__5))), 'C', (size_t )99);
    (*((char (*)[100])(source__5)))[99] = (char )'\000';
    strcat((char */* __restrict  */)data__0, (char const   */* __restrict  */)(*((char (*)[100])(source__5))));
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 15: 
    *((void **)(& data__0)) = __builtin_alloca(50UL * sizeof(char ));
    *((char **)(& tmp___0__4)) = (char *)*((void **)(& data__0));
    *((void **)(& dataBadBuffer__1)) = __builtin_alloca(100UL * sizeof(char ));
    *((char **)(source__5)) = (char *)*((void **)(& dataBadBuffer__1));
    {
    next = 14;
    }
    break;
    case 14: ;
    switch (6) {
    case 6: 
    {
    next = 13;
    }
    break;
    default: 
    {
    next = 11;
    }
    break;
    }
    break;
    case 13: 
    *((char **)(& tmp__2)) = *((char **)(source__5));
    *(*((char **)(& tmp__2)) + 0) = (char )'\000';
    {
    next = 9;
    }
    break;
    case 11: 
    printLine("Benign, fixed string");
    {
    next = 9;
    }
    break;
    case 9: 
    memset((void *)(*((char (*)[100])(source__6))), 'C', (size_t )99);
    (*((char (*)[100])(source__6)))[99] = (char )'\000';
    strcat((char */* __restrict  */)*((char **)(& tmp__2)), (char const   */* __restrict  */)(*((char (*)[100])(source__6))));
    printLine((char const   *)*((char **)(& tmp__2)));
    {
    next = 8;
    }
    break;
    case 8: ;
    return;
    break;
    }
  }
}
}
