void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_ncpy_42_good(void) 
{ 


  {
  _1_goodG2B_goodG2BSource(0, 0, 1);
  return;
}
}
