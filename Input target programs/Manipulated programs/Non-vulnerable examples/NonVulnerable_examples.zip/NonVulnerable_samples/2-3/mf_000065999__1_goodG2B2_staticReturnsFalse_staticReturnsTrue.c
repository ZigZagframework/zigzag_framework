void _1_goodG2B2_staticReturnsFalse_staticReturnsTrue(void *tigressRetVal , int whichBlock__6 ) 
{ 
  char *data__0 ;
  char dataBuffer__1[100] ;
  int tmp__2 ;
  char dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  unsigned long next ;

  {
  {
  next = whichBlock__6;
  }
  while (1) {
    switch (next) {
    case 9: 
    data__0 = *((char (*)[100])(dataBuffer__1));
    _1_goodG2B2_staticReturnsFalse_staticReturnsTrue(& tmp__2, 11);
    {
    next = 8;
    }
    break;
    case 8: ;
    if (tmp__2) {
      {
      next = 7;
      }
    } else {
      {
      next = 6;
      }
    }
    break;
    case 7: 
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    {
    next = 6;
    }
    break;
    case 6: 
    (*((char (*)[50])(dest__3)))[0] = (char )'\000';
    tmp___0__4 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((char (*)[50])(dest__3)))[tmp___0__4] = (char)0;
    tmp___0__4 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    tmp___1__5 = strlen((char const   *)data__0);
    strncpy((char */* __restrict  */)(*((char (*)[50])(dest__3))), (char const   */* __restrict  */)data__0,
            tmp___1__5);
    (*((char (*)[50])(dest__3)))[49] = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 10: ;
    {
    *((int *)tigressRetVal) = 0;
    return;
    }
    break;
    case 11: ;
    {
    *((int *)tigressRetVal) = 1;
    return;
    }
    break;
    }
  }
}
}
