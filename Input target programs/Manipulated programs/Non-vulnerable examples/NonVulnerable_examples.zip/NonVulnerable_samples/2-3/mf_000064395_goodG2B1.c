static void goodG2B1(void) 
{ 
  int64_t *data ;
  int64_t *dataBadBuffer ;
  void *tmp ;
  int64_t *dataGoodBuffer ;
  void *tmp___0 ;
  int64_t source[100] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int64_t ));
  dataBadBuffer = (int64_t *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int64_t ));
  dataGoodBuffer = (int64_t *)tmp___0;
  if (STATIC_CONST_FALSE) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
  }
  source[0] = (int64_t )0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 100U)) {
    source[tmp___1] = 0L;
    tmp___1 ++;
  }
  memmove((void *)data, (void const   *)(source), 100UL * sizeof(int64_t ));
  printLongLongLine(*(data + 0));
  return;
}
}
