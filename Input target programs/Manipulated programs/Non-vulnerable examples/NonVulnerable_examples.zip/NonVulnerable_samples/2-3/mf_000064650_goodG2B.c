static void goodG2B(void) 
{ 
  int *data ;
  int *dataBadBuffer ;
  void *tmp ;
  int *dataGoodBuffer ;
  void *tmp___0 ;
  int *dataCopy ;
  int *data___0 ;
  int source[100] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(50UL * sizeof(int ));
  dataBadBuffer = (int *)tmp;
  tmp___0 = __builtin_alloca(100UL * sizeof(int ));
  dataGoodBuffer = (int *)tmp___0;
  data = dataGoodBuffer;
  dataCopy = data;
  data___0 = dataCopy;
  source[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 100U)) {
    source[tmp___1] = 0;
    tmp___1 ++;
  }
  memmove((void *)data___0, (void const   *)(source), 100UL * sizeof(int ));
  printIntLine(*(data___0 + 0));
  return;
}
}
