static void goodG2B(void) 
{ 
  char *data ;
  char *dataArray[5] ;
  char dataGoodBuffer[11] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  dataArray[2] = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE193_char_declare_loop_66b_goodG2BSink(dataArray);
  return;
}
}
