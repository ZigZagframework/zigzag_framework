void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  wchar_t *data__0 ;
  wchar_t dataGoodBuffer__1[11] ;
  wchar_t source__2[11] ;
  size_t i__3 ;
  size_t sourceLen__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 6: 
    data__0 = *((wchar_t (*)[11])(dataGoodBuffer__1));
    *(data__0 + 0) = 0;
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    i__3 = (size_t )0;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (i__3 < sourceLen__4 + 1UL) {
      {
      next = 2;
      }
    } else {
      {
      next = 1;
      }
    }
    break;
    case 2: 
    *(data__0 + i__3) = (*((wchar_t (*)[11])(source__2)))[i__3];
    i__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    printWLine((wchar_t const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 13: 
    *((wchar_t **)(& i__3)) = *((wchar_t (*)[11])(dataGoodBuffer__1));
    *(*((wchar_t **)(& i__3)) + 0) = 0;
    (*((wchar_t (*)[11])(source__2)))[0] = 65;
    (*((wchar_t (*)[11])(source__2)))[1] = 65;
    (*((wchar_t (*)[11])(source__2)))[2] = 65;
    (*((wchar_t (*)[11])(source__2)))[3] = 65;
    (*((wchar_t (*)[11])(source__2)))[4] = 65;
    (*((wchar_t (*)[11])(source__2)))[5] = 65;
    (*((wchar_t (*)[11])(source__2)))[6] = 65;
    (*((wchar_t (*)[11])(source__2)))[7] = 65;
    (*((wchar_t (*)[11])(source__2)))[8] = 65;
    (*((wchar_t (*)[11])(source__2)))[9] = 65;
    (*((wchar_t (*)[11])(source__2)))[10] = 0;
    sourceLen__4 = wcslen((wchar_t const   *)(*((wchar_t (*)[11])(source__2))));
    *((size_t *)(& data__0)) = (size_t )0;
    {
    next = 11;
    }
    break;
    case 11: ;
    if (*((size_t *)(& data__0)) < sourceLen__4 + 1UL) {
      {
      next = 9;
      }
    } else {
      {
      next = 8;
      }
    }
    break;
    case 9: 
    *(*((wchar_t **)(& i__3)) + *((size_t *)(& data__0))) = (*((wchar_t (*)[11])(source__2)))[*((size_t *)(& data__0))];
    (*((size_t *)(& data__0))) ++;
    {
    next = 11;
    }
    break;
    case 8: 
    printWLine((wchar_t const   *)*((wchar_t **)(& i__3)));
    {
    next = 7;
    }
    break;
    case 7: ;
    return;
    break;
    }
  }
}
}
