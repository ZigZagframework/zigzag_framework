void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_64_good_goodG2B(void *tigressRetVal ,
                                                                          int whichBlock__1 ) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_64_bad(void) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fgets_64b_badSink(void *dataVoidPtr ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
