static void goodG2B(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_67_structType myStruct ;
  char dataBuffer[100] ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncat_67b_goodG2BSink(myStruct);
  return;
}
}
