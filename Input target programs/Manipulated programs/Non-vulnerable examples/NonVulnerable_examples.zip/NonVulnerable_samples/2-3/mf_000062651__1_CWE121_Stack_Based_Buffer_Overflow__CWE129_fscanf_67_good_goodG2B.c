void _1_CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_good_goodG2B(void *tigressRetVal ,
                                                                          int whichBlock__2 ) ;
extern struct _IO_FILE *stdin ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67b_badSink(CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_structType myStruct ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
typedef struct _IO_FILE FILE;
extern int fscanf(FILE * __restrict  __stream , char const   * __restrict  __format 
                  , ...)  __asm__("__isoc99_fscanf")  ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_67_bad(void) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
