static void goodG2B(void) 
{ 
  wchar_t *data ;
  wchar_t dataBuffer[100] ;
  wchar_t dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  while (1) {
    wmemset(data, 65, (size_t )49);
    *(data + 49) = 0;
    break;
  }
  dest[0] = 0;
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = 0;
    tmp ++;
  }
  wcscpy((wchar_t */* __restrict  */)(dest), (wchar_t const   */* __restrict  */)data);
  printWLine((wchar_t const   *)data);
  return;
}
}
