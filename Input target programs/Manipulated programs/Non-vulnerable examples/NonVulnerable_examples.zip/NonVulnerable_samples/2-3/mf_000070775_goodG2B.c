static void goodG2B(void) 
{ 
  char *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_67_structType myStruct ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(11UL * sizeof(char ));
  data = (char *)tmp;
  myStruct.structFirst = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_cpy_67b_goodG2BSink(myStruct);
  return;
}
}
