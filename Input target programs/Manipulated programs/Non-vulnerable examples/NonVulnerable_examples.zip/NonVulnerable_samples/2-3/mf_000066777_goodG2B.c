static void goodG2B(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_67_structType myStruct ;
  char dataGoodBuffer[100] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = (char )'\000';
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__dest_char_declare_cat_67b_goodG2BSink(myStruct);
  return;
}
}
