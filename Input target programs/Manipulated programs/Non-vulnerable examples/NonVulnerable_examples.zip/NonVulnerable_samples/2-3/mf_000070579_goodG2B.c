static void goodG2B(void) 
{ 
  int data ;

  {
  data = -1;
  data = 7;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_63b_goodG2BSink(& data);
  return;
}
}
