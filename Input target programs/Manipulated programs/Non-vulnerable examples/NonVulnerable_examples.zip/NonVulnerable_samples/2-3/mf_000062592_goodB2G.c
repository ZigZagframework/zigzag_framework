static void goodB2G(void) 
{ 
  int data ;
  char inputBuffer[3UL * sizeof(data) + 2UL] ;
  unsigned int tmp ;
  char *tmp___0 ;

  {
  data = -1;
  inputBuffer[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 14U)) {
    inputBuffer[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = fgets((char */* __restrict  */)(inputBuffer), (int )(3UL * sizeof(data) + 2UL),
                  (FILE */* __restrict  */)stdin);
  if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
    data = atoi((char const   *)(inputBuffer));
  } else {
    printLine("fgets() failed.");
  }
  CWE121_Stack_Based_Buffer_Overflow__CWE129_fgets_45_goodB2GData = data;
  goodB2GSink();
  return;
}
}
