void _1_CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cat_11_good_goodG2B2(void *tigressRetVal ,
                                                                                 int whichBlock__6 ) ;
extern int atoi(char const   *s ) ;
extern void *malloc(unsigned long size ) ;
extern int getpagesize() ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern void printLine(char const   *line ) ;
void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cat_11_bad(void) ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern int globalReturnsFalse() ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern int globalReturnsTrue() ;
extern long time(long *tloc ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2), __leaf__)) strcat)(char * __restrict  __dest ,
                                                                                                 char const   * __restrict  __src ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern double log(double x ) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cat_11_bad(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  int tmp___0 ;
  char dest[50] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  tmp___0 = globalReturnsTrue();
  if (tmp___0) {
    memset((void *)data, 'A', (size_t )99);
    *(data + 99) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___1 = 1U;
  while (! (tmp___1 >= 50U)) {
    dest[tmp___1] = (char)0;
    tmp___1 ++;
  }
  test_insert();
  strcat((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  test_insert();
  printLine((char const   *)data);
  return;
}
}
