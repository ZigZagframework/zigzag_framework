void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_snprintf_42_good(void) 
{ 


  {
  _1_goodG2B_goodG2BSource(0, 0, 6);
  return;
}
}
