void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cpy_04_good_goodG2B2(void *tigressRetVal ,
                                                                                     int whichBlock__6 ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void STATIC_CONST_TRUE_i$nit(void) 
{ 


  {
  STATIC_CONST_TRUE = (int const   )1;
}
}
