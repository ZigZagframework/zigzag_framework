void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__9 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  int tmp___1__5 ;
  char source__6[11] ;
  size_t tmp___2__7 ;
  char source__8[11] ;
  unsigned long next ;

  {
  {
  next = whichBlock__9;
  }
  while (1) {
    switch (next) {
    case 5: 
    tmp__2 = __builtin_alloca(10UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(11UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    tmp___1__5 = globalReturnsFalse();
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___1__5) {
      {
      next = 3;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 3: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 2: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    {
    next = 1;
    }
    break;
    case 1: 
    (*((char (*)[11])(source__6)))[0] = (char )'A';
    (*((char (*)[11])(source__6)))[1] = (char )'A';
    (*((char (*)[11])(source__6)))[2] = (char )'A';
    (*((char (*)[11])(source__6)))[3] = (char )'A';
    (*((char (*)[11])(source__6)))[4] = (char )'A';
    (*((char (*)[11])(source__6)))[5] = (char )'A';
    (*((char (*)[11])(source__6)))[6] = (char )'A';
    (*((char (*)[11])(source__6)))[7] = (char )'A';
    (*((char (*)[11])(source__6)))[8] = (char )'A';
    (*((char (*)[11])(source__6)))[9] = (char )'A';
    (*((char (*)[11])(source__6)))[10] = (char )'\000';
    tmp___2__7 = strlen((char const   *)(*((char (*)[11])(source__6))));
    memmove((void *)data__0, (void const   *)(*((char (*)[11])(source__6))), (tmp___2__7 + 1UL) * sizeof(char ));
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 10: 
    tmp___0__4 = __builtin_alloca(10UL * sizeof(char ));
    data__0 = (char *)tmp___0__4;
    *((void **)(& tmp___2__7)) = __builtin_alloca(11UL * sizeof(char ));
    *((char **)(source__6)) = (char *)*((void **)(& tmp___2__7));
    *((int *)(& dataBadBuffer__1)) = globalReturnsTrue();
    {
    next = 9;
    }
    break;
    case 9: ;
    if (*((int *)(& dataBadBuffer__1))) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    dataGoodBuffer__3 = *((char **)(source__6));
    *(dataGoodBuffer__3 + 0) = (char )'\000';
    {
    next = 7;
    }
    break;
    case 7: 
    (*((char (*)[11])(source__8)))[0] = (char )'A';
    (*((char (*)[11])(source__8)))[1] = (char )'A';
    (*((char (*)[11])(source__8)))[2] = (char )'A';
    (*((char (*)[11])(source__8)))[3] = (char )'A';
    (*((char (*)[11])(source__8)))[4] = (char )'A';
    (*((char (*)[11])(source__8)))[5] = (char )'A';
    (*((char (*)[11])(source__8)))[6] = (char )'A';
    (*((char (*)[11])(source__8)))[7] = (char )'A';
    (*((char (*)[11])(source__8)))[8] = (char )'A';
    (*((char (*)[11])(source__8)))[9] = (char )'A';
    (*((char (*)[11])(source__8)))[10] = (char )'\000';
    *((size_t *)(& tmp__2)) = strlen((char const   *)(*((char (*)[11])(source__8))));
    memmove((void *)dataGoodBuffer__3, (void const   *)(*((char (*)[11])(source__8))),
            (*((size_t *)(& tmp__2)) + 1UL) * sizeof(char ));
    printLine((char const   *)dataGoodBuffer__3);
    {
    next = 6;
    }
    break;
    case 6: ;
    return;
    break;
    }
  }
}
}
