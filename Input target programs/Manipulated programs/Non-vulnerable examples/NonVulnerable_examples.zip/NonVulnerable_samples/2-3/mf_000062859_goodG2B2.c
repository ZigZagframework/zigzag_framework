static void goodG2B2(void) 
{ 
  int *data ;
  void *tmp ;
  int tmp___0 ;
  int source[10] ;
  unsigned int tmp___1 ;

  {
  data = (int *)((void *)0);
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE131_memcpy_08_good_goodG2B1_staticReturnsFalse_staticReturnsTrue(& tmp___0,
                                                                                                             14);
  if (tmp___0) {
    tmp = __builtin_alloca(10UL * sizeof(int ));
    data = (int *)tmp;
  }
  source[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 10U)) {
    source[tmp___1] = 0;
    tmp___1 ++;
  }
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         10UL * sizeof(int ));
  printIntLine(*(data + 0));
  return;
}
}
