static void goodG2B(void) 
{ 
  int *data ;
  int **dataPtr1 ;
  int **dataPtr2 ;
  int dataGoodBuffer[100] ;
  int *data___0 ;
  int *data___1 ;
  int source[100] ;
  unsigned int tmp ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  data___0 = *dataPtr1;
  data___0 = dataGoodBuffer;
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  source[0] = 0;
  tmp = 1U;
  while (! (tmp >= 100U)) {
    source[tmp] = 0;
    tmp ++;
  }
  memcpy((void */* __restrict  */)data___1, (void const   */* __restrict  */)(source),
         100UL * sizeof(int ));
  printIntLine(*(data___1 + 0));
  return;
}
}
