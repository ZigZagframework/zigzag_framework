static void goodG2B1(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  goodG2B1Static = 0;
  data = goodG2B1Source(data);
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  tmp___1 = wcslen((wchar_t const   *)data);
  memmove((void *)(dest), (void const   *)data, tmp___1 * sizeof(wchar_t ));
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
