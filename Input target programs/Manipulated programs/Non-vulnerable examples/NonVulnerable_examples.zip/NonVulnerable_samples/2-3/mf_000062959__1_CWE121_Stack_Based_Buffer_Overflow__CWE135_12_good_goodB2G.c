void _1_CWE121_Stack_Based_Buffer_Overflow__CWE135_12_good_goodB2G(void *tigressRetVal ,
                                                                   int whichBlock__11 ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern int globalReturnsTrueOrFalse() ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void test_insert(void) 
{ 


  {
  return;
}
}
