void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                           int whichBlock__3 ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern char *CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_goodG2B1Source(char *data ) ;
extern void signal(int sig , void *func ) ;
extern double difftime(long tv1 , long tv0 ) ;
int CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_goodG2B1Global ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern char *CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_badSource(char *data ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
int CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_badGlobal ;
void CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memmove_22_goodG2B2Global_i$nit(void) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memmove)(void *__dest ,
                                                                                                  void const   *__src ,
                                                                                                  size_t __n ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void main(void) 
{ 


  {
  megaInit();
}
}
