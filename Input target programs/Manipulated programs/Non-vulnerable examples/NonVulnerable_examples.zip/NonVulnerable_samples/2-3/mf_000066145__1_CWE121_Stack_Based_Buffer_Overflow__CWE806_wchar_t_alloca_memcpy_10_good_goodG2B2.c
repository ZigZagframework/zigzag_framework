void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_10_good_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__6 ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_10_bad(void) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int globalFalse ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_10_good_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__6 ) 
{ 
  wchar_t *data__0 ;
  wchar_t *dataBuffer__1 ;
  void *tmp__2 ;
  wchar_t dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  unsigned long next ;

  {
  {
  next = whichBlock__6;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_10_good_goodG2B2(0,
                                                                                         11);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 11: 
    tmp__2 = __builtin_alloca(100UL * sizeof(wchar_t ));
    dataBuffer__1 = (wchar_t *)tmp__2;
    data__0 = dataBuffer__1;
    {
    next = 10;
    }
    break;
    case 10: ;
    if (globalTrue) {
      {
      next = 9;
      }
    } else {
      {
      next = 8;
      }
    }
    break;
    case 9: 
    wmemset(data__0, 65, (size_t )49);
    *(data__0 + 49) = 0;
    {
    next = 8;
    }
    break;
    case 8: 
    (*((wchar_t (*)[50])(dest__3)))[0] = 0;
    tmp___0__4 = 1U;
    {
    next = 6;
    }
    break;
    case 6: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 3;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 4: 
    (*((wchar_t (*)[50])(dest__3)))[tmp___0__4] = 0;
    tmp___0__4 ++;
    {
    next = 6;
    }
    break;
    case 3: 
    tmp___1__5 = wcslen((wchar_t const   *)data__0);
    memcpy((void */* __restrict  */)(*((wchar_t (*)[50])(dest__3))), (void const   */* __restrict  */)data__0,
           tmp___1__5 * sizeof(wchar_t ));
    (*((wchar_t (*)[50])(dest__3)))[49] = 0;
    printWLine((wchar_t const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
