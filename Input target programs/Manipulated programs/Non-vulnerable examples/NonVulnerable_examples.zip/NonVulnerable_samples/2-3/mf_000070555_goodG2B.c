static void goodG2B(void) 
{ 
  int data ;
  int tmp ;
  int i ;
  int *buffer ;
  void *tmp___0 ;
  int i___0 ;
  int *buffer___0 ;
  void *tmp___1 ;
  int tmp___2 ;

  {
  data = -1;
  tmp = globalReturnsTrueOrFalse();
  if (tmp) {
    data = 7;
  } else {
    data = 7;
  }
  tmp___2 = globalReturnsTrueOrFalse();
  if (tmp___2) {
    tmp___0 = malloc(10UL * sizeof(int ));
    buffer = (int *)tmp___0;
    i = 0;
    while (i < 10) {
      *(buffer + i) = 0;
      i ++;
    }
    if (data >= 0) {
      *(buffer + data) = 1;
      i = 0;
      while (i < 10) {
        printIntLine(*(buffer + i));
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer);
  } else {
    tmp___1 = malloc(10UL * sizeof(int ));
    buffer___0 = (int *)tmp___1;
    i___0 = 0;
    while (i___0 < 10) {
      *(buffer___0 + i___0) = 0;
      i___0 ++;
    }
    if (data >= 0) {
      *(buffer___0 + data) = 1;
      i___0 = 0;
      while (i___0 < 10) {
        printIntLine(*(buffer___0 + i___0));
        i___0 ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer___0);
  }
  return;
}
}
