static void goodG2B(void) 
{ 
  char *data ;
  char dataBuffer[100] ;
  char dest[50] ;
  unsigned int tmp ;

  {
  data = dataBuffer;
  goto source;
  source: 
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  strcat((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  printLine((char const   *)data);
  return;
}
}
