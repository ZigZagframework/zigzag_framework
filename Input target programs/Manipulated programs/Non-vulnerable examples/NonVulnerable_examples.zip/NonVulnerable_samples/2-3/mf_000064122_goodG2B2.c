static void goodG2B2(void) 
{ 
  char *data ;
  char dataGoodBuffer[100] ;
  int tmp ;
  char source[100] ;

  {
  tmp = globalReturnsTrue();
  if (tmp) {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  memcpy((void */* __restrict  */)data, (void const   */* __restrict  */)(source),
         100UL * sizeof(char ));
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
