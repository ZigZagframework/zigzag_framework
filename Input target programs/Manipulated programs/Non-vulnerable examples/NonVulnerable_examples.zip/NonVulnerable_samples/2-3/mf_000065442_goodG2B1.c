static void goodG2B1(void) 
{ 
  wchar_t *data ;
  wchar_t dataGoodBuffer[100] ;
  int tmp ;
  wchar_t source[100] ;

  {
  tmp = globalReturnsFalse();
  if (tmp) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
    *(data + 0) = 0;
  }
  wmemset(source, 67, (size_t )99);
  source[99] = 0;
  wcsncpy((wchar_t */* __restrict  */)data, (wchar_t const   */* __restrict  */)(source),
          (size_t )99);
  *(data + 99) = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
