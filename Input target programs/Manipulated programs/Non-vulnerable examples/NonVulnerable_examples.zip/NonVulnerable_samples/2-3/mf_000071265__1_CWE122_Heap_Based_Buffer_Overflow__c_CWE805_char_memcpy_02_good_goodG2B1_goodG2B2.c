void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_memcpy_02_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__4 ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern void exit(int status ) ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern int raise(int sig ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int unlink(char const   *filename ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern int rand() ;
extern unsigned long strtoul(char const   *str , char const   *endptr , int base ) ;
extern int getpagesize() ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern int printf(char const   *format  , ...) ;
extern double log(double x ) ;
void main(void) ;
extern unsigned long strlen(char const   *s ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
void test_insert(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
