static void goodG2B(void) 
{ 
  void *data ;
  int tmp ;
  size_t dataLen ;
  size_t tmp___0 ;
  void *dest ;
  void *tmp___1 ;
  size_t dataLen___0 ;
  size_t tmp___2 ;
  void *dest___0 ;
  void *tmp___3 ;
  int tmp___4 ;

  {
  data = (void *)0;
  tmp = globalReturnsTrueOrFalse();
  if (tmp) {
    data = (void *)"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  } else {
    data = (void *)"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  }
  tmp___4 = globalReturnsTrueOrFalse();
  if (tmp___4) {
    tmp___0 = strlen((char const   *)((char *)data));
    dataLen = tmp___0;
    tmp___1 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___1;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
  } else {
    tmp___2 = strlen((char const   *)((char *)data));
    dataLen___0 = tmp___2;
    tmp___3 = calloc(dataLen___0 + 1UL, (size_t )1);
    dest___0 = tmp___3;
    memcpy((void */* __restrict  */)dest___0, (void const   */* __restrict  */)data,
           dataLen___0 + 1UL);
    printLine((char const   *)((char *)dest___0));
    free(dest___0);
  }
  return;
}
}
