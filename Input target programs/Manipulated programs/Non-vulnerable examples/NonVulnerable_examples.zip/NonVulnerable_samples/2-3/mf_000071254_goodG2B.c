static void goodG2B(void) 
{ 
  char *data ;
  char *dataArray[5] ;
  void *tmp ;

  {
  data = (char *)((void *)0);
  tmp = malloc(100UL * sizeof(char ));
  data = (char *)tmp;
  *(data + 0) = (char )'\000';
  dataArray[2] = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE805_char_loop_66b_goodG2BSink(dataArray);
  return;
}
}
