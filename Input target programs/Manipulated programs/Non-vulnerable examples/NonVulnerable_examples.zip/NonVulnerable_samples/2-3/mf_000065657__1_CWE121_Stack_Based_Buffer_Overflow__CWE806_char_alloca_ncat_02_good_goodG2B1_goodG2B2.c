void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_02_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__7 ) ;
extern int atoi(char const   *s ) ;
extern void *malloc(unsigned long size ) ;
extern int getpagesize() ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern void printLine(char const   *line ) ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1), __leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
void main(void) ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
void megaInit(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_02_bad(void) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
void test_insert(void) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1), __leaf__)) memset)(void *__s ,
                                                                                               int __c ,
                                                                                               size_t __n ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2), __leaf__)) strncat)(char * __restrict  __dest ,
                                                                                                  char const   * __restrict  __src ,
                                                                                                  size_t __n ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_02_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__7 ) 
{ 
  char *data__0 ;
  char *dataBuffer__1 ;
  void *tmp__2 ;
  char dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  char dest__6[50] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_02_good_goodG2B1_goodG2B2(0,
                                                                                             8);
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_02_good_goodG2B1_goodG2B2(0,
                                                                                             15);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 8: 
    tmp__2 = __builtin_alloca(100UL * sizeof(char ));
    dataBuffer__1 = (char *)tmp__2;
    data__0 = dataBuffer__1;
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    (*((char (*)[50])(dest__3)))[0] = (char )'\000';
    tmp___0__4 = 1U;
    {
    next = 6;
    }
    break;
    case 6: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 3;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 4: 
    (*((char (*)[50])(dest__3)))[tmp___0__4] = (char)0;
    tmp___0__4 ++;
    {
    next = 6;
    }
    break;
    case 3: 
    tmp___1__5 = strlen((char const   *)data__0);
    strncat((char */* __restrict  */)(*((char (*)[50])(dest__3))), (char const   */* __restrict  */)data__0,
            tmp___1__5);
    (*((char (*)[50])(dest__3)))[49] = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 15: 
    tmp__2 = __builtin_alloca(100UL * sizeof(char ));
    data__0 = (char *)tmp__2;
    *((char **)(dest__3)) = data__0;
    memset((void *)*((char **)(dest__3)), 'A', (size_t )49);
    *(*((char **)(dest__3)) + 49) = (char )'\000';
    (*((char (*)[50])(dest__6)))[0] = (char )'\000';
    *((unsigned int *)(& tmp___1__5)) = 1U;
    {
    next = 13;
    }
    break;
    case 13: ;
    if (*((unsigned int *)(& tmp___1__5)) >= 50U) {
      {
      next = 10;
      }
    } else {
      {
      next = 11;
      }
    }
    break;
    case 11: 
    (*((char (*)[50])(dest__6)))[*((unsigned int *)(& tmp___1__5))] = (char)0;
    (*((unsigned int *)(& tmp___1__5))) ++;
    {
    next = 13;
    }
    break;
    case 10: 
    *((size_t *)(& dataBuffer__1)) = strlen((char const   *)*((char **)(dest__3)));
    strncat((char */* __restrict  */)(*((char (*)[50])(dest__6))), (char const   */* __restrict  */)*((char **)(dest__3)),
            *((size_t *)(& dataBuffer__1)));
    (*((char (*)[50])(dest__6)))[49] = (char )'\000';
    printLine((char const   *)*((char **)(dest__3)));
    {
    next = 9;
    }
    break;
    case 9: ;
    return;
    break;
    }
  }
}
}
