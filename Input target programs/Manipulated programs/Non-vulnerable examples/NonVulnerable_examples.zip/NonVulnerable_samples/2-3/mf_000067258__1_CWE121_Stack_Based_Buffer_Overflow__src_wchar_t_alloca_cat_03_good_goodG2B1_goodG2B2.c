void _1_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_03_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                             int whichBlock__5 ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
extern void printWLine(wchar_t const   *line ) ;
void test_insert(void) ;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__leaf__)) wmemset)(wchar_t *__s ,
                                                                                   wchar_t __c ,
                                                                                   size_t __n ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern void *fopen(char const   *filename , char const   *mode ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_03_bad(void) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void main(void) 
{ 


  {
  megaInit();
}
}
