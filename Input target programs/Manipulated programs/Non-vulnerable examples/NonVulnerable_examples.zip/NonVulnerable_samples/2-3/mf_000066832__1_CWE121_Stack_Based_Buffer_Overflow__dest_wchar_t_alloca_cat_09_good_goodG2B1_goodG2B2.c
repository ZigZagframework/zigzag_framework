void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_alloca_cat_09_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__7 ) ;
extern int fseek(struct _IO_FILE *stream , long offs , int whence ) ;
extern int fclose(void *stream ) ;
extern int close(int filedes ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
typedef int wchar_t;
extern  __attribute__((__nothrow__)) wchar_t *( __attribute__((__nonnull__(1,2), __leaf__)) wcscat)(wchar_t * __restrict  __dest ,
                                                                                                    wchar_t const   * __restrict  __src ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern int unlink(char const   *filename ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
