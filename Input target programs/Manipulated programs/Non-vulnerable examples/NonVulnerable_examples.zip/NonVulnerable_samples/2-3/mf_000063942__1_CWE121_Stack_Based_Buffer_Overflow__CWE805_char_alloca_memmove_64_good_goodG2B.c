void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_alloca_memmove_64_good_goodG2B(void *tigressRetVal ,
                                                                                       int whichBlock__5 ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern long clock(void) ;
extern void exit(int status ) ;
extern int raise(int sig ) ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern int unlink(char const   *filename ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern int rand() ;
extern unsigned long strtoul(char const   *str , char const   *endptr , int base ) ;
extern int getpagesize() ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int printf(char const   *format  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern double log(double x ) ;
void main(void) ;
extern unsigned long strlen(char const   *s ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern void free(void *ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
