void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__7 ) 
{ 
  char *data__0 ;
  char *dataBuffer__1 ;
  void *tmp__2 ;
  char dest__3[50] ;
  unsigned int tmp___0__4 ;
  size_t tmp___1__5 ;
  char dest__6[50] ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 10: 
    tmp__2 = __builtin_alloca(100UL * sizeof(char ));
    dataBuffer__1 = (char *)tmp__2;
    data__0 = dataBuffer__1;
    {
    next = 9;
    }
    break;
    case 9: ;
    if (GLOBAL_CONST_FIVE != 5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    {
    next = 6;
    }
    break;
    case 6: 
    (*((char (*)[50])(dest__3)))[0] = (char )'\000';
    tmp___0__4 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp___0__4 >= 50U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((char (*)[50])(dest__3)))[tmp___0__4] = (char)0;
    tmp___0__4 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    tmp___1__5 = strlen((char const   *)data__0);
    snprintf((char */* __restrict  */)(*((char (*)[50])(dest__3))), tmp___1__5, (char const   */* __restrict  */)"%s",
             data__0);
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 20: 
    tmp__2 = __builtin_alloca(100UL * sizeof(char ));
    data__0 = (char *)tmp__2;
    *((char **)(dest__3)) = data__0;
    {
    next = 19;
    }
    break;
    case 19: ;
    if (GLOBAL_CONST_FIVE == 5) {
      {
      next = 18;
      }
    } else {
      {
      next = 17;
      }
    }
    break;
    case 18: 
    memset((void *)*((char **)(dest__3)), 'A', (size_t )49);
    *(*((char **)(dest__3)) + 49) = (char )'\000';
    {
    next = 17;
    }
    break;
    case 17: 
    (*((char (*)[50])(dest__6)))[0] = (char )'\000';
    *((unsigned int *)(& tmp___1__5)) = 1U;
    {
    next = 15;
    }
    break;
    case 15: ;
    if (*((unsigned int *)(& tmp___1__5)) >= 50U) {
      {
      next = 12;
      }
    } else {
      {
      next = 13;
      }
    }
    break;
    case 13: 
    (*((char (*)[50])(dest__6)))[*((unsigned int *)(& tmp___1__5))] = (char)0;
    (*((unsigned int *)(& tmp___1__5))) ++;
    {
    next = 15;
    }
    break;
    case 12: 
    *((size_t *)(& dataBuffer__1)) = strlen((char const   *)*((char **)(dest__3)));
    snprintf((char */* __restrict  */)(*((char (*)[50])(dest__6))), *((size_t *)(& dataBuffer__1)),
             (char const   */* __restrict  */)"%s", *((char **)(dest__3)));
    printLine((char const   *)*((char **)(dest__3)));
    {
    next = 11;
    }
    break;
    case 11: ;
    return;
    break;
    }
  }
}
}
