static void goodG2B2(void) 
{ 
  char *data ;
  char dataGoodBuffer[11] ;
  char source[11] ;
  size_t i ;
  size_t sourceLen ;

  {
  if (globalFive == 5) {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  sourceLen = strlen((char const   *)(source));
  i = (size_t )0;
  while (i < sourceLen + 1UL) {
    *(data + i) = source[i];
    i ++;
  }
  printLine((char const   *)data);
  return;
}
}
