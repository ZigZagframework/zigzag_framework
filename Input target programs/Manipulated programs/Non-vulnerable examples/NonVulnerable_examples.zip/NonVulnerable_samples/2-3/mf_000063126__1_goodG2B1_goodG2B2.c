void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__8 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  char source__5[11] ;
  size_t tmp___1__6 ;
  char source__7[11] ;
  unsigned long next ;

  {
  {
  next = whichBlock__8;
  }
  while (1) {
    switch (next) {
    case 7: 
    tmp__2 = __builtin_alloca(10UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(11UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    {
    next = 6;
    }
    break;
    case 6: ;
    switch (5) {
    case 6: 
    {
    next = 5;
    }
    break;
    default: 
    {
    next = 3;
    }
    break;
    }
    break;
    case 5: 
    printLine("Benign, fixed string");
    {
    next = 1;
    }
    break;
    case 3: 
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    {
    next = 1;
    }
    break;
    case 1: 
    (*((char (*)[11])(source__5)))[0] = (char )'A';
    (*((char (*)[11])(source__5)))[1] = (char )'A';
    (*((char (*)[11])(source__5)))[2] = (char )'A';
    (*((char (*)[11])(source__5)))[3] = (char )'A';
    (*((char (*)[11])(source__5)))[4] = (char )'A';
    (*((char (*)[11])(source__5)))[5] = (char )'A';
    (*((char (*)[11])(source__5)))[6] = (char )'A';
    (*((char (*)[11])(source__5)))[7] = (char )'A';
    (*((char (*)[11])(source__5)))[8] = (char )'A';
    (*((char (*)[11])(source__5)))[9] = (char )'A';
    (*((char (*)[11])(source__5)))[10] = (char )'\000';
    tmp___1__6 = strlen((char const   *)(*((char (*)[11])(source__5))));
    memcpy((void */* __restrict  */)data__0, (void const   */* __restrict  */)(*((char (*)[11])(source__5))),
           (tmp___1__6 + 1UL) * sizeof(char ));
    printLine((char const   *)data__0);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 15: 
    tmp___0__4 = __builtin_alloca(10UL * sizeof(char ));
    data__0 = (char *)tmp___0__4;
    *((void **)(& tmp___1__6)) = __builtin_alloca(11UL * sizeof(char ));
    *((char **)(source__5)) = (char *)*((void **)(& tmp___1__6));
    {
    next = 14;
    }
    break;
    case 14: ;
    switch (6) {
    case 6: 
    {
    next = 13;
    }
    break;
    default: 
    {
    next = 11;
    }
    break;
    }
    break;
    case 13: 
    dataGoodBuffer__3 = *((char **)(source__5));
    *(dataGoodBuffer__3 + 0) = (char )'\000';
    {
    next = 9;
    }
    break;
    case 11: 
    printLine("Benign, fixed string");
    {
    next = 9;
    }
    break;
    case 9: 
    (*((char (*)[11])(source__7)))[0] = (char )'A';
    (*((char (*)[11])(source__7)))[1] = (char )'A';
    (*((char (*)[11])(source__7)))[2] = (char )'A';
    (*((char (*)[11])(source__7)))[3] = (char )'A';
    (*((char (*)[11])(source__7)))[4] = (char )'A';
    (*((char (*)[11])(source__7)))[5] = (char )'A';
    (*((char (*)[11])(source__7)))[6] = (char )'A';
    (*((char (*)[11])(source__7)))[7] = (char )'A';
    (*((char (*)[11])(source__7)))[8] = (char )'A';
    (*((char (*)[11])(source__7)))[9] = (char )'A';
    (*((char (*)[11])(source__7)))[10] = (char )'\000';
    *((size_t *)(& tmp__2)) = strlen((char const   *)(*((char (*)[11])(source__7))));
    memcpy((void */* __restrict  */)dataGoodBuffer__3, (void const   */* __restrict  */)(*((char (*)[11])(source__7))),
           (*((size_t *)(& tmp__2)) + 1UL) * sizeof(char ));
    printLine((char const   *)dataGoodBuffer__3);
    {
    next = 8;
    }
    break;
    case 8: ;
    return;
    break;
    }
  }
}
}
