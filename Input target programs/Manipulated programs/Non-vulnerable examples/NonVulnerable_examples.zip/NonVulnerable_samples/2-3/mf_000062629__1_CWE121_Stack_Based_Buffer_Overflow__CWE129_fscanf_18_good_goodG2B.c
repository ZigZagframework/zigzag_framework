void _1_CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_18_good_goodG2B(void *tigressRetVal ,
                                                                          int whichBlock__4 ) ;
extern int close(int filedes ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
typedef long __off_t;
extern int unlink(char const   *filename ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
