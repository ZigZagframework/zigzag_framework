void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_good_goodG2B(void *tigressRetVal ,
                                                                                    int whichBlock__5 ) ;
extern long time(long *tloc ) ;
typedef struct _IO_FILE FILE;
extern void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68b_badSink() ;
void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_goodG2BData_i$nit(void) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
char *CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_goodG2BData ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_good_goodG2B(void *tigressRetVal ,
                                                                                    int whichBlock__5 ) 
{ 
  char *data__0 ;
  char *dataBadBuffer__1 ;
  void *tmp__2 ;
  char *dataGoodBuffer__3 ;
  void *tmp___0__4 ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_good_goodG2B(0,
                                                                                   3);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    tmp__2 = __builtin_alloca(10UL * sizeof(char ));
    dataBadBuffer__1 = (char *)tmp__2;
    tmp___0__4 = __builtin_alloca(11UL * sizeof(char ));
    dataGoodBuffer__3 = (char *)tmp___0__4;
    data__0 = dataGoodBuffer__3;
    *(data__0 + 0) = (char )'\000';
    CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68_goodG2BData = data__0;
    CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_68b_goodG2BSink();
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
