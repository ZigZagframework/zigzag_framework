void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cpy_52_good_goodG2B(void *tigressRetVal ,
                                                                                     int whichBlock__2 ) ;
extern int scanf(char const   *format  , ...) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cpy_52_good_goodG2B(void *tigressRetVal ,
                                                                                     int whichBlock__2 ) 
{ 
  wchar_t *data__0 ;
  wchar_t dataGoodBuffer__1[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__2;
  }
  while (1) {
    switch (next) {
    case 1: 
    _1_CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cpy_52_good_goodG2B(0,
                                                                                    3);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 3: 
    data__0 = *((wchar_t (*)[100])(dataGoodBuffer__1));
    *(data__0 + 0) = 0;
    CWE121_Stack_Based_Buffer_Overflow__dest_wchar_t_declare_cpy_52b_goodG2BSink(data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    }
  }
}
}
