static void goodG2B2(void) 
{ 
  int data ;
  int tmp ;
  int i ;
  int *buffer ;
  void *tmp___0 ;
  int tmp___1 ;

  {
  data = -1;
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_08_good_goodB2G2_goodG2B1_staticReturnsFalse_staticReturnsTrue(& tmp,
                                                                                                                      44);
  if (tmp) {
    data = 7;
  }
  _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_08_good_goodB2G2_goodG2B1_staticReturnsFalse_staticReturnsTrue(& tmp___1,
                                                                                                                      44);
  if (tmp___1) {
    tmp___0 = malloc(10UL * sizeof(int ));
    buffer = (int *)tmp___0;
    i = 0;
    while (i < 10) {
      *(buffer + i) = 0;
      i ++;
    }
    if (data >= 0) {
      *(buffer + data) = 1;
      i = 0;
      while (i < 10) {
        printIntLine(*(buffer + i));
        i ++;
      }
    } else {
      printLine("ERROR: Array index is negative.");
    }
    free((void *)buffer);
  }
  return;
}
}
