static void goodG2B(void) 
{ 
  int *data ;
  int *dataArray[5] ;
  int dataGoodBuffer[100] ;

  {
  data = dataGoodBuffer;
  dataArray[2] = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_int_declare_memcpy_66b_goodG2BSink(dataArray);
  return;
}
}
