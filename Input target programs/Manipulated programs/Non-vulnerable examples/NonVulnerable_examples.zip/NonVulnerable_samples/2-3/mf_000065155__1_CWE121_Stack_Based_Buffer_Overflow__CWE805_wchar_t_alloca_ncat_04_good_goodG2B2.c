void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_alloca_ncat_04_good_goodG2B2(void *tigressRetVal ,
                                                                                        int whichBlock__6 ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
