void _1_CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_22_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                             int whichBlock__5 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_22_badGlobal_i$nit(void) 
{ 


  {
  CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_22_badGlobal = 0;
}
}
