void _1_goodG2B1_goodG2B2(void *tigressRetVal , int whichBlock__5 ) 
{ 
  int *data__0 ;
  int dataGoodBuffer__1[100] ;
  int source__2[100] ;
  unsigned int tmp__3 ;
  int source__4[100] ;
  unsigned long next ;

  {
  {
  next = whichBlock__5;
  }
  while (1) {
    switch (next) {
    case 9: ;
    if (STATIC_CONST_FIVE != 5) {
      {
      next = 8;
      }
    } else {
      {
      next = 7;
      }
    }
    break;
    case 8: 
    printLine("Benign, fixed string");
    {
    next = 6;
    }
    break;
    case 7: 
    data__0 = *((int (*)[100])(dataGoodBuffer__1));
    {
    next = 6;
    }
    break;
    case 6: 
    (*((int (*)[100])(source__2)))[0] = 0;
    tmp__3 = 1U;
    {
    next = 4;
    }
    break;
    case 4: ;
    if (tmp__3 >= 100U) {
      {
      next = 1;
      }
    } else {
      {
      next = 2;
      }
    }
    break;
    case 2: 
    (*((int (*)[100])(source__2)))[tmp__3] = 0;
    tmp__3 ++;
    {
    next = 4;
    }
    break;
    case 1: 
    memmove((void *)data__0, (void const   *)(*((int (*)[100])(source__2))), 100UL * sizeof(int ));
    printIntLine(*(data__0 + 0));
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 18: ;
    if (STATIC_CONST_FIVE == 5) {
      {
      next = 17;
      }
    } else {
      {
      next = 16;
      }
    }
    break;
    case 17: 
    *((int **)(source__2)) = *((int (*)[100])(dataGoodBuffer__1));
    {
    next = 16;
    }
    break;
    case 16: 
    (*((int (*)[100])(source__4)))[0] = 0;
    *((unsigned int *)(& data__0)) = 1U;
    {
    next = 14;
    }
    break;
    case 14: ;
    if (*((unsigned int *)(& data__0)) >= 100U) {
      {
      next = 11;
      }
    } else {
      {
      next = 12;
      }
    }
    break;
    case 12: 
    (*((int (*)[100])(source__4)))[*((unsigned int *)(& data__0))] = 0;
    (*((unsigned int *)(& data__0))) ++;
    {
    next = 14;
    }
    break;
    case 11: 
    memmove((void *)*((int **)(source__2)), (void const   *)(*((int (*)[100])(source__4))),
            100UL * sizeof(int ));
    printIntLine(*(*((int **)(source__2)) + 0));
    {
    next = 10;
    }
    break;
    case 10: ;
    return;
    break;
    }
  }
}
}
