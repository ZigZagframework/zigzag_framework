static void goodG2B(void) 
{ 
  wchar_t *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_loop_67_structType myStruct ;
  wchar_t dataBuffer[100] ;

  {
  data = dataBuffer;
  wmemset(data, 65, (size_t )49);
  *(data + 49) = 0;
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_declare_loop_67b_goodG2BSink(myStruct);
  return;
}
}
