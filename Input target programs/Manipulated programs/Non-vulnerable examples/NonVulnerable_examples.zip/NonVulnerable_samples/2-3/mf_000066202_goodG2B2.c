static void goodG2B2(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  goodG2B2Static = 1;
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_21_bad_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memmove_21_good_badSource_goodG2B2Source(& data,
                                                                                                                                                                                 data,
                                                                                                                                                                                 14);
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  tmp___1 = wcslen((wchar_t const   *)data);
  memmove((void *)(dest), (void const   *)data, tmp___1 * sizeof(wchar_t ));
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
