static void goodG2B(void) 
{ 
  wchar_t *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memcpy_67_structType myStruct ;
  wchar_t dataGoodBuffer[100] ;

  {
  data = dataGoodBuffer;
  *(data + 0) = 0;
  myStruct.structFirst = data;
  CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memcpy_67b_goodG2BSink(myStruct);
  return;
}
}
