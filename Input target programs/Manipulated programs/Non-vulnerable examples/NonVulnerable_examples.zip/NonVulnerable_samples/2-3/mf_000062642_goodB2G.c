static void goodB2G(void) 
{ 
  int data ;

  {
  data = -1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data);
  CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_52b_goodB2GSink(data);
  return;
}
}
