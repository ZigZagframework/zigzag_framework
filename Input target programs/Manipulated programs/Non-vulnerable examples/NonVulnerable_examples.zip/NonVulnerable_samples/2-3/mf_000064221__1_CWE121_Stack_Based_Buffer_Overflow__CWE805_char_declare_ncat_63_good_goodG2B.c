void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_ncat_63_good_goodG2B(void *tigressRetVal ,
                                                                                     int whichBlock__2 ) ;
extern int printf(char const   *format  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern double log(double x ) ;
void main(void) ;
extern unsigned long strlen(char const   *s ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
void megaInit(void) ;
extern void free(void *ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
