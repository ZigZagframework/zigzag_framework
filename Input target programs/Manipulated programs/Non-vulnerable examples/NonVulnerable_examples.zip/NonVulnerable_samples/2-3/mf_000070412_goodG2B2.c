static void goodG2B2(void) 
{ 
  void *data ;
  char *dataGoodBuffer ;
  void *tmp ;
  size_t dataLen ;
  size_t tmp___0 ;
  void *dest ;
  void *tmp___1 ;

  {
  data = (void *)0;
  if (GLOBAL_CONST_FIVE == 5) {
    tmp = malloc(50UL * sizeof(char ));
    dataGoodBuffer = (char *)tmp;
    memset((void *)dataGoodBuffer, 'A', (size_t )49);
    *(dataGoodBuffer + 49) = (char )'\000';
    data = (void *)dataGoodBuffer;
  }
  if (GLOBAL_CONST_FIVE == 5) {
    tmp___0 = strlen((char const   *)((char *)data));
    dataLen = tmp___0;
    tmp___1 = calloc(dataLen + 1UL, (size_t )1);
    dest = tmp___1;
    memcpy((void */* __restrict  */)dest, (void const   */* __restrict  */)data, dataLen + 1UL);
    printLine((char const   *)((char *)dest));
    free(dest);
  }
  return;
}
}
