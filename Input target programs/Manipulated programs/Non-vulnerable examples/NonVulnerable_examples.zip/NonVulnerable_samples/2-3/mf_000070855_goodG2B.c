static void goodG2B(void) 
{ 
  char *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_char_memcpy_34_unionType myUnion ;
  void *tmp ;
  char *data___0 ;
  char source[11] ;
  size_t tmp___0 ;

  {
  data = (char *)((void *)0);
  tmp = malloc(11UL * sizeof(char ));
  data = (char *)tmp;
  myUnion.unionFirst = data;
  data___0 = myUnion.unionSecond;
  source[0] = (char )'A';
  source[1] = (char )'A';
  source[2] = (char )'A';
  source[3] = (char )'A';
  source[4] = (char )'A';
  source[5] = (char )'A';
  source[6] = (char )'A';
  source[7] = (char )'A';
  source[8] = (char )'A';
  source[9] = (char )'A';
  source[10] = (char )'\000';
  tmp___0 = strlen((char const   *)(source));
  memcpy((void */* __restrict  */)data___0, (void const   */* __restrict  */)(source),
         (tmp___0 + 1UL) * sizeof(char ));
  printLine((char const   *)data___0);
  free((void *)data___0);
  return;
}
}
