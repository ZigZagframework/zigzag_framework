static void goodB2G(void) 
{ 
  void *data ;

  {
  data = (void *)0;
  data = (void *)L"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
  CWE121_Stack_Based_Buffer_Overflow__CWE135_45_goodB2GData = data;
  goodB2GSink();
  return;
}
}
