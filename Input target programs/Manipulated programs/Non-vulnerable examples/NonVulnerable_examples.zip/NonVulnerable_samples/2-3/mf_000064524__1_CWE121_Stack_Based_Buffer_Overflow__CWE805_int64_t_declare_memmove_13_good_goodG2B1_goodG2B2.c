void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_int64_t_declare_memmove_13_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                                     int whichBlock__5 ) ;
extern int fseek(struct _IO_FILE *stream , long offs , int whence ) ;
extern int fclose(void *stream ) ;
extern int close(int filedes ) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern int unlink(char const   *filename ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
