void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_loop_14_good_goodG2B1_goodG2B2(void *tigressRetVal ,
                                                                                              int whichBlock__8 ) ;
extern void exit(int status ) ;
extern long clock(void) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern int raise(int sig ) ;
extern int unlink(char const   *filename ) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int rand() ;
extern unsigned long strtoul(char const   *str , char const   *endptr , int base ) ;
extern int strcmp(char const   *a , char const   *b ) ;
extern int getpagesize() ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int printf(char const   *format  , ...) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern double log(double x ) ;
void main(void) ;
extern int pthread_create(void *thread , void *attr , void *start_routine , void *arg ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1), __leaf__)) strlen)(char const   *__s )  __attribute__((__pure__)) ;
void megaInit(void) ;
extern int globalFive ;
extern void free(void *ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
void test_insert(void) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
