void _1_CWE121_Stack_Based_Buffer_Overflow__CWE805_char_declare_memcpy_67_good_goodG2B(void *tigressRetVal ,
                                                                                       int whichBlock__3 ) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
