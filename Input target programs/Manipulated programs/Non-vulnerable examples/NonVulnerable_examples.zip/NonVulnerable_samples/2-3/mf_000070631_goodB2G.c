static void goodB2G(void) 
{ 
  int data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_67_structType myStruct ;

  {
  data = -1;
  data = 10;
  myStruct.structFirst = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_67b_goodB2GSink(myStruct);
  return;
}
}
