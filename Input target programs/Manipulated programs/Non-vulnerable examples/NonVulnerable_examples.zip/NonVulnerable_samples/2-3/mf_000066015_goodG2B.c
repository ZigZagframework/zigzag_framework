static void goodG2B(void) 
{ 
  char *data ;
  CWE121_Stack_Based_Buffer_Overflow__CWE806_char_declare_ncpy_34_unionType myUnion ;
  char dataBuffer[100] ;
  char *data___0 ;
  char dest[50] ;
  unsigned int tmp ;
  size_t tmp___0 ;

  {
  data = dataBuffer;
  memset((void *)data, 'A', (size_t )49);
  *(data + 49) = (char )'\000';
  myUnion.unionFirst = data;
  data___0 = myUnion.unionSecond;
  dest[0] = (char )'\000';
  tmp = 1U;
  while (! (tmp >= 50U)) {
    dest[tmp] = (char)0;
    tmp ++;
  }
  tmp___0 = strlen((char const   *)data___0);
  strncpy((char */* __restrict  */)(dest), (char const   */* __restrict  */)data___0,
          tmp___0);
  dest[49] = (char )'\000';
  printLine((char const   *)data___0);
  return;
}
}
