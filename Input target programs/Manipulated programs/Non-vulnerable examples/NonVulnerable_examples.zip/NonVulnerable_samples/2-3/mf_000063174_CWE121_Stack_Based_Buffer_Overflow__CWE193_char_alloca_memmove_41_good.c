void CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_41_good(void) 
{ 


  {
  _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_memmove_41_badSink_goodG2B(0,
                                                                                       0,
                                                                                       3);
  return;
}
}
