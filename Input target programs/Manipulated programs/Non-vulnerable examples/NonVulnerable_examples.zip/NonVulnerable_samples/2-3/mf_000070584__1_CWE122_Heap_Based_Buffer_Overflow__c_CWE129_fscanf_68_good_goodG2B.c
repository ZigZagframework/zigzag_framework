void _1_CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68_good_goodG2B(void *tigressRetVal ,
                                                                           int whichBlock__1 ) ;
extern int raise(int sig ) ;
extern void abort() ;
extern int atoi(char const   *s ) ;
extern void *malloc(unsigned long size ) ;
static void goodB2G(void) ;
void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68_goodG2BData_i$nit(void) ;
extern int getpagesize() ;
extern int posix_memalign(void **memptr , unsigned long alignment , unsigned long size ) ;
extern void CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68b_goodB2GSink() ;
extern int pthread_join(void *thread , void **value_ptr ) ;
extern int rand() ;
extern void free(void *ptr ) ;
int CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68_goodB2GData ;
extern struct _IO_FILE *stdin ;
extern unsigned long strlen(char const   *s ) ;
void main(void) ;
int CWE122_Heap_Based_Buffer_Overflow__c_CWE129_fscanf_68_goodG2BData ;
extern int write(int filedes , void *buf , int nbyte ) ;
extern int gettimeofday(struct timeval *tv , void *tz ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
void megaInit(void) ;
extern int printf(char const   *format  , ...) ;
typedef struct _IO_FILE FILE;
extern int fscanf(FILE * __restrict  __stream , char const   * __restrict  __format 
                  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   *format  , ...) ;
extern long clock(void) ;
extern void perror(char const   *str ) ;
extern int read(int filedes , void *buf , int nbyte ) ;
extern int gethostname(char *name , unsigned long namelen  , ...) ;
extern float strtof(char const   *str , char const   *endptr ) ;
extern void qsort(void *base , unsigned long nel , unsigned long width , int (*compar)(void *a ,
                                                                                       void *b ) ) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern double strtod(char const   *str , char const   *endptr ) ;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
