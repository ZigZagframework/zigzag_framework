void _1_CWE121_Stack_Based_Buffer_Overflow__CWE193_char_alloca_ncpy_65_good_goodG2B(void *tigressRetVal ,
                                                                                    int whichBlock__6 ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
