static void goodG2B1(void) 
{ 
  char *data ;
  char *dataBuffer ;
  void *tmp ;
  int tmp___0 ;
  char dest[50] ;
  unsigned int tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(char ));
  dataBuffer = (char *)tmp;
  data = dataBuffer;
  tmp___0 = globalReturnsFalse();
  if (tmp___0) {
    printLine("Benign, fixed string");
  } else {
    memset((void *)data, 'A', (size_t )49);
    *(data + 49) = (char )'\000';
  }
  dest[0] = (char )'\000';
  tmp___1 = 1U;
  while (! (tmp___1 >= 50U)) {
    dest[tmp___1] = (char)0;
    tmp___1 ++;
  }
  strcat((char */* __restrict  */)(dest), (char const   */* __restrict  */)data);
  printLine((char const   *)data);
  return;
}
}
