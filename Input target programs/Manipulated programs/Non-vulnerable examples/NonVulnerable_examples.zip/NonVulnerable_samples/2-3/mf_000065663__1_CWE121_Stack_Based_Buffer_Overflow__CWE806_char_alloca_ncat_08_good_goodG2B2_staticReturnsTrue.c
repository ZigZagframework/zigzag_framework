void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_good_goodG2B2_staticReturnsTrue(void *tigressRetVal ,
                                                                                                       int whichBlock__7 ) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2), __leaf__)) strncat)(char * __restrict  __dest ,
                                                                                                  char const   * __restrict  __src ,
                                                                                                  size_t __n ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_good_goodG2B2_staticReturnsTrue(void *tigressRetVal ,
                                                                                                       int whichBlock__7 ) 
{ 
  char *data__0 ;
  char *dataBuffer__1 ;
  void *tmp__2 ;
  int tmp___0__3 ;
  char dest__4[50] ;
  unsigned int tmp___1__5 ;
  size_t tmp___2__6 ;
  unsigned long next ;

  {
  {
  next = whichBlock__7;
  }
  while (1) {
    switch (next) {
    case 1: 
    goodG2B1();
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_good_goodG2B2_staticReturnsTrue(0,
                                                                                                      11);
    {
    next = 0;
    }
    break;
    case 0: ;
    return;
    break;
    case 11: 
    tmp__2 = __builtin_alloca(100UL * sizeof(char ));
    dataBuffer__1 = (char *)tmp__2;
    data__0 = dataBuffer__1;
    _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_char_alloca_ncat_08_good_goodG2B2_staticReturnsTrue(& tmp___0__3,
                                                                                                      12);
    {
    next = 10;
    }
    break;
    case 10: ;
    if (tmp___0__3) {
      {
      next = 9;
      }
    } else {
      {
      next = 8;
      }
    }
    break;
    case 9: 
    memset((void *)data__0, 'A', (size_t )49);
    *(data__0 + 49) = (char )'\000';
    {
    next = 8;
    }
    break;
    case 8: 
    (*((char (*)[50])(dest__4)))[0] = (char )'\000';
    tmp___1__5 = 1U;
    {
    next = 6;
    }
    break;
    case 6: ;
    if (tmp___1__5 >= 50U) {
      {
      next = 3;
      }
    } else {
      {
      next = 4;
      }
    }
    break;
    case 4: 
    (*((char (*)[50])(dest__4)))[tmp___1__5] = (char)0;
    tmp___1__5 ++;
    {
    next = 6;
    }
    break;
    case 3: 
    tmp___2__6 = strlen((char const   *)data__0);
    strncat((char */* __restrict  */)(*((char (*)[50])(dest__4))), (char const   */* __restrict  */)data__0,
            tmp___2__6);
    (*((char (*)[50])(dest__4)))[49] = (char )'\000';
    printLine((char const   *)data__0);
    {
    next = 2;
    }
    break;
    case 2: ;
    return;
    break;
    case 12: ;
    {
    *((int *)tigressRetVal) = 1;
    return;
    }
    break;
    }
  }
}
}
