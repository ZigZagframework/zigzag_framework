static void goodG2B(void) 
{ 
  wchar_t *data ;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_loop_67_structType myStruct ;
  void *tmp ;

  {
  data = (wchar_t *)((void *)0);
  tmp = malloc(11UL * sizeof(wchar_t ));
  data = (wchar_t *)tmp;
  myStruct.structFirst = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE193_wchar_t_loop_67b_goodG2BSink(myStruct);
  return;
}
}
