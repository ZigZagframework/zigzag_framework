static void goodB2G(void) 
{ 
  int data ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  data = -1;
  tmp = rand();
  tmp___0 = rand();
  tmp___1 = rand();
  data = ((tmp << 30) ^ (tmp___0 << 15)) ^ tmp___1;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68_goodB2GData = data;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_rand_68b_goodB2GSink();
  return;
}
}
