static void goodB2G(void) 
{ 
  int data ;
  int *dataPtr1 ;
  int *dataPtr2 ;
  int data___0 ;
  int data___1 ;
  int i ;
  int buffer[10] ;
  unsigned int tmp ;

  {
  dataPtr1 = & data;
  dataPtr2 = & data;
  data = -1;
  data___0 = *dataPtr1;
  fscanf((FILE */* __restrict  */)stdin, (char const   */* __restrict  */)"%d", & data___0);
  *dataPtr1 = data___0;
  data___1 = *dataPtr2;
  buffer[0] = 0;
  tmp = 1U;
  while (! (tmp >= 10U)) {
    buffer[tmp] = 0;
    tmp ++;
  }
  if (data___1 >= 0) {
    if (data___1 < 10) {
      buffer[data___1] = 1;
      i = 0;
      while (i < 10) {
        printIntLine(buffer[i]);
        i ++;
      }
    } else {
      printLine("ERROR: Array index is out-of-bounds");
    }
  } else {
    printLine("ERROR: Array index is out-of-bounds");
  }
  return;
}
}
