void _1_CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_14_good_goodG2B2(void *tigressRetVal ,
                                                                                          int whichBlock__6 ) ;
extern double difftime(long tv1 , long tv0 ) ;
extern void signal(int sig , void *func ) ;
void CWE121_Stack_Based_Buffer_Overflow__CWE806_wchar_t_alloca_memcpy_14_bad(void) ;
extern long time(long *tloc ) ;
extern int globalFive ;
typedef struct _IO_FILE FILE;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__leaf__)) wcslen)(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern int fprintf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int strncmp(char const   *s1 , char const   *s2 , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern double sqrt(double x ) ;
extern double log(double x ) ;
extern int snprintf(char *str , unsigned long size , char const   *format  , ...) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2), __leaf__)) memcpy)(void * __restrict  __dest ,
                                                                                                 void const   * __restrict  __src ,
                                                                                                 size_t __n ) ;
static void goodG2B1(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  wchar_t dest[50] ;
  unsigned int tmp___0 ;
  size_t tmp___1 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  if (globalFive != 5) {
    printLine("Benign, fixed string");
  } else {
    wmemset(data, 65, (size_t )49);
    *(data + 49) = 0;
  }
  dest[0] = 0;
  tmp___0 = 1U;
  while (! (tmp___0 >= 50U)) {
    dest[tmp___0] = 0;
    tmp___0 ++;
  }
  tmp___1 = wcslen((wchar_t const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___1 * sizeof(wchar_t ));
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
