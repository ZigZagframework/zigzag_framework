static void goodB2G(void) 
{ 
  int data ;

  {
  data = -1;
  data = 10;
  CWE122_Heap_Based_Buffer_Overflow__c_CWE129_large_52b_goodB2GSink(data);
  return;
}
}
