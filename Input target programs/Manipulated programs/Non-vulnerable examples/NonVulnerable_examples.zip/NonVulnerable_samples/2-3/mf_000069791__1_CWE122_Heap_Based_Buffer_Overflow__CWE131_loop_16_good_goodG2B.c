void _1_CWE122_Heap_Based_Buffer_Overflow__CWE131_loop_16_good_goodG2B(void *tigressRetVal ,
                                                                       int whichBlock__5 ) ;
extern void printIntLine(int intNumber ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__leaf__)) free)(void *__ptr ) ;
extern long strtol(char const   *str , char const   *endptr , int base ) ;
extern int fscanf(struct _IO_FILE *stream , char const   *format  , ...) ;
extern int fcntl(int filedes , int cmd  , ...) ;
void test_insert(void) ;
extern unsigned long strnlen(char const   *s , unsigned long maxlen ) ;
extern int open(char const   *filename , int oflag  , ...) ;
extern void *memcpy(void *s1 , void const   *s2 , unsigned long size ) ;
struct timeval {
   long tv_sec ;
   long tv_usec ;
};
