static void goodG2B1(void) 
{ 
  char *data ;
  char dataGoodBuffer[100] ;
  char source[100] ;

  {
  if (globalFive != 5) {
    printLine("Benign, fixed string");
  } else {
    data = dataGoodBuffer;
    *(data + 0) = (char )'\000';
  }
  memset((void *)(source), 'C', (size_t )99);
  source[99] = (char )'\000';
  strncpy((char */* __restrict  */)data, (char const   */* __restrict  */)(source),
          (size_t )99);
  *(data + 99) = (char )'\000';
  printLine((char const   *)data);
  return;
}
}
