static void goodG2B2(void) 
{ 
  wchar_t *data ;
  wchar_t *dataBuffer ;
  void *tmp ;
  int tmp___0 ;
  wchar_t dest[50] ;
  unsigned int tmp___1 ;
  size_t tmp___2 ;

  {
  tmp = __builtin_alloca(100UL * sizeof(wchar_t ));
  dataBuffer = (wchar_t *)tmp;
  data = dataBuffer;
  tmp___0 = staticReturnsTrue();
  if (tmp___0) {
    wmemset(data, 65, (size_t )49);
    *(data + 49) = 0;
  }
  dest[0] = 0;
  tmp___1 = 1U;
  while (! (tmp___1 >= 50U)) {
    dest[tmp___1] = 0;
    tmp___1 ++;
  }
  tmp___2 = wcslen((wchar_t const   *)data);
  memcpy((void */* __restrict  */)(dest), (void const   */* __restrict  */)data, tmp___2 * sizeof(wchar_t ));
  dest[49] = 0;
  printWLine((wchar_t const   *)data);
  return;
}
}
