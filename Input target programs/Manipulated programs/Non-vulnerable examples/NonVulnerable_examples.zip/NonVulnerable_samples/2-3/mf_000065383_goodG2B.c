static void goodG2B(void) 
{ 
  wchar_t *data ;
  void (*funcPtr)(wchar_t * ) ;
  wchar_t dataGoodBuffer[100] ;

  {
  funcPtr = & CWE121_Stack_Based_Buffer_Overflow__CWE805_wchar_t_declare_memmove_65b_goodG2BSink;
  data = dataGoodBuffer;
  *(data + 0) = 0;
  (*funcPtr)(data);
  return;
}
}
