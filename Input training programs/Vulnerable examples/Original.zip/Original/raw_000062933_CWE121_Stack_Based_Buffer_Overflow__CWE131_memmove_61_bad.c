void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_61_bad()
{
    int * data;
    data = NULL;
    data = CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_61b_badSource(data);
    {
        int source[10] = {0};
        /* POTENTIAL FLAW: Possible buffer overflow if data was not allocated correctly in the source */
        memmove(data, source, 10*sizeof(int));
        printIntLine(data[0]);
    }
}
