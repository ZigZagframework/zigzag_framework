void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_22_bad()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Set data to a random value */
    data = RAND32();
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_22_badGlobal = 1; /* true */
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_22_badSink(data);
}
