void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_21_bad()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    badStatic = 1; /* true */
    badSink(data);
}
