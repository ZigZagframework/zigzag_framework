void CWE121_Stack_Based_Buffer_Overflow__CWE129_large_67_bad()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_67_structType myStruct;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_large_67b_badSink(myStruct);
}
