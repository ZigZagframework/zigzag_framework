void CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_22_bad()
{
    int * data;
    data = NULL;
    CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_22_badGlobal = 1; /* true */
    data = CWE121_Stack_Based_Buffer_Overflow__CWE131_memmove_22_badSource(data);
    {
        int source[10] = {0};
        /* POTENTIAL FLAW: Possible buffer overflow if data was not allocated correctly in the source */
        memmove(data, source, 10*sizeof(int));
        printIntLine(data[0]);
    }
}
