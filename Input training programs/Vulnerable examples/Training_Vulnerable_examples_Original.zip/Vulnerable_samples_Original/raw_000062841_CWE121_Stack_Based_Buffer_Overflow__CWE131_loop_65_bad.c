void CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_65_bad()
{
    int * data;
    /* define a function pointer */
    void (*funcPtr) (int *) = CWE121_Stack_Based_Buffer_Overflow__CWE131_loop_65b_badSink;
    data = NULL;
    /* FLAW: Allocate memory without using sizeof(int) */
    data = (int *)ALLOCA(10);
    /* use the function pointer */
    funcPtr(data);
}
