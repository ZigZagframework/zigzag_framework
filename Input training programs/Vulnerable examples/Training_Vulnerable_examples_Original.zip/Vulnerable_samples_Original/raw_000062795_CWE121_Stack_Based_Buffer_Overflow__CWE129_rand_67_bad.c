void CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67_bad()
{
    int data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67_structType myStruct;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Set data to a random value */
    data = RAND32();
    myStruct.structFirst = data;
    CWE121_Stack_Based_Buffer_Overflow__CWE129_rand_67b_badSink(myStruct);
}
