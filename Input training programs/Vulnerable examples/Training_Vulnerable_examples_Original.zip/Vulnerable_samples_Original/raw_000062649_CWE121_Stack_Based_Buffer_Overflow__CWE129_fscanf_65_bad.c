void CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_65_bad()
{
    int data;
    /* define a function pointer */
    void (*funcPtr) (int) = CWE121_Stack_Based_Buffer_Overflow__CWE129_fscanf_65b_badSink;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Read data from the console using fscanf() */
    fscanf(stdin, "%d", &data);
    /* use the function pointer */
    funcPtr(data);
}
