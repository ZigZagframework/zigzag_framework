void CWE121_Stack_Based_Buffer_Overflow__CWE135_61_bad()
{
    void * data;
    data = NULL;
    data = CWE121_Stack_Based_Buffer_Overflow__CWE135_61b_badSource(data);
    {
        /* POTENTIAL FLAW: treating pointer as a char* when it may point to a wide string */
        size_t dataLen = strlen((char *)data);
        void * dest = (void *)calloc(dataLen+1, 1);
        memcpy(dest, data, (dataLen+1));
        printLine((char *)dest);
        free(dest);
    }
}
