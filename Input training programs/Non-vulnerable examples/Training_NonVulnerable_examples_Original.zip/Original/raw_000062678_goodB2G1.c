static void goodB2G1()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Use an invalid index */
    data = 10;
    goodB2G1Static = 0; /* false */
    goodB2G1Sink(data);
}
