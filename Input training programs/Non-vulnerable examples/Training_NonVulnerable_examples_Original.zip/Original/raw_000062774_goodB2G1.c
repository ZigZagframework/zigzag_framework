static void goodB2G1()
{
    int data;
    /* Initialize data */
    data = -1;
    /* POTENTIAL FLAW: Set data to a random value */
    data = RAND32();
    goodB2G1Static = 0; /* false */
    goodB2G1Sink(data);
}
